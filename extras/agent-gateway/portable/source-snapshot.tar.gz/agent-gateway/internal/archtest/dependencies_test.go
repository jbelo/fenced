// Package archtest verifies production dependency boundaries without test-assembly restrictions.
package archtest

import (
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// TestDependencies protects DOMAIN R6 and the inward dependency rule in DESIGN.
func TestDependencies(t *testing.T) {
	root := filepath.Join("..", "..")
	err := filepath.WalkDir(filepath.Join(root, "internal"), func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() || !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
			return nil
		}
		rel, err := filepath.Rel(root, filepath.Dir(path))
		if err != nil {
			return err
		}
		pkg := filepath.ToSlash(rel)
		file, err := parser.ParseFile(token.NewFileSet(), path, nil, parser.ImportsOnly)
		if err != nil {
			return err
		}
		for _, spec := range file.Imports {
			checkImport(t, pkg, spec)
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
}

func checkImport(t *testing.T, pkg string, spec *ast.ImportSpec) {
	t.Helper()
	imported, err := strconv.Unquote(spec.Path.Value)
	if err != nil {
		t.Fatal(err)
	}
	local := strings.TrimPrefix(imported, "agent-gateway/")
	if pkg == "internal/access" {
		if strings.HasPrefix(local, "internal/") && local != "internal/limits" {
			t.Errorf("access imports %s", imported)
		}
		for _, forbidden := range []string{"encoding/json", "net/http", "os", "log"} {
			if imported == forbidden || strings.HasPrefix(imported, forbidden+"/") {
				t.Errorf("access imports %s", imported)
			}
		}
	}
	if strings.HasPrefix(pkg, "internal/providers/") {
		if local == "internal/httpapi" || local == "internal/gateway" {
			t.Errorf("%s imports inbound adapter %s", pkg, imported)
		}
		own := strings.Split(pkg, "/")[2]
		if strings.HasPrefix(local, "internal/providers/") && strings.Split(local, "/")[2] != own {
			t.Errorf("%s imports unrelated integration %s", pkg, imported)
		}
	}
	if pkg == "internal/cli" || strings.HasSuffix(pkg, "/contract") || strings.HasSuffix(pkg, "/commands") {
		if local == "internal/upstream" || local == "internal/runtimefile" || local == "internal/provider" || local == "internal/httpapi" || (strings.HasPrefix(local, "internal/providers/") && len(strings.Split(local, "/")) == 3) {
			t.Errorf("pure client/contract %s imports runtime %s", pkg, imported)
		}
	}
}
