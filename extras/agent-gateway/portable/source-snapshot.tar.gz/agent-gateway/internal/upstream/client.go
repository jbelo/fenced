// Package upstream supplies bounded, direct, read-only provider HTTP transport.
package upstream

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	"compress/gzip"
	"context"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

// Client binds trusted implementation code to one HTTPS origin and credentials.
type Client struct {
	origin  *url.URL
	client  *http.Client
	headers http.Header
}

// New constructs a fixed-origin client. A supplied transport is trusted fixture/test code.
func New(origin string, headers http.Header, transport http.RoundTripper) (*Client, error) {
	u, err := url.Parse(origin)
	if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.Port() != "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return nil, protocol.Fail(protocol.InternalError)
	}
	if transport == nil {
		t := http.DefaultTransport.(*http.Transport).Clone()
		t.Proxy = nil
		transport = t
	}
	return &Client{origin: u, headers: headers.Clone(), client: &http.Client{Transport: transport, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}}, nil
}

// Get charges the request scope, performs one GET and bounds decompressed response bytes.
func (c *Client) Get(ctx context.Context, scope *access.Budget, path string, query url.Values, accept string) ([]byte, http.Header, error) {
	if scope == nil {
		return nil, nil, protocol.Fail(protocol.InternalError)
	}
	if err := scope.Charge(); err != nil {
		return nil, nil, err
	}
	if !strings.HasPrefix(path, "/") || strings.HasPrefix(path, "//") || strings.ContainsAny(path, "?#\\") || strings.Contains(strings.ToLower(path), "%2f") || strings.Contains(path, "/../") {
		return nil, nil, protocol.Fail(protocol.InternalError)
	}
	u := *c.origin
	u.Path = path
	u.RawPath = ""
	u.RawQuery = query.Encode()
	ctx, cancel := context.WithTimeout(ctx, limits.FetchTimeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return nil, nil, protocol.Fail(protocol.InternalError)
	}
	req.Header = c.headers.Clone()
	if accept != "" {
		req.Header.Set("Accept", accept)
	}
	response, err := c.client.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return nil, nil, protocol.Fail(protocol.Timeout)
		}
		return nil, nil, protocol.Fail(protocol.UpstreamUnavailable)
	}
	defer func() { _ = response.Body.Close() }()
	scope.RecordStatus(response.StatusCode)
	if response.StatusCode != http.StatusOK {
		return nil, nil, statusError(response)
	}
	var reader io.Reader = response.Body
	if strings.EqualFold(response.Header.Get("Content-Encoding"), "gzip") {
		compressed, err := gzip.NewReader(response.Body)
		if err != nil {
			return nil, nil, protocol.Fail(protocol.UpstreamUnavailable)
		}
		defer func() { _ = compressed.Close() }()
		reader = compressed
	} else if encoding := response.Header.Get("Content-Encoding"); encoding != "" && encoding != "identity" {
		return nil, nil, protocol.Fail(protocol.UpstreamUnavailable)
	}
	data, err := io.ReadAll(io.LimitReader(reader, limits.UpstreamBytes+1))
	if err != nil {
		if ctx.Err() != nil {
			return nil, nil, protocol.Fail(protocol.Timeout)
		}
		return nil, nil, protocol.Fail(protocol.UpstreamUnavailable)
	}
	if len(data) > limits.UpstreamBytes {
		return nil, nil, protocol.Fail(protocol.LimitExceeded)
	}
	if ctx.Err() != nil {
		return nil, nil, protocol.Fail(protocol.Timeout)
	}
	return data, response.Header.Clone(), nil
}

func statusError(r *http.Response) error {
	code := protocol.UpstreamUnavailable
	switch r.StatusCode {
	case 401:
		code = protocol.UpstreamAuthentication
	case 403:
		code = protocol.UpstreamAuthorization
	case 404:
		code = protocol.NotFound
	case 429:
		code = protocol.RateLimited
	}
	if r.StatusCode == 403 && (r.Header.Get("Retry-After") != "" || r.Header.Get("X-RateLimit-Remaining") == "0") {
		code = protocol.RateLimited
	}
	e := &protocol.RequestError{Code: code}
	if seconds, err := strconv.Atoi(r.Header.Get("Retry-After")); err == nil && code == protocol.RateLimited && seconds >= 0 {
		e.RetryAfterSeconds = &seconds
	}
	return e
}
