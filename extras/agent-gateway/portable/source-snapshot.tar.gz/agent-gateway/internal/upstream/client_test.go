package upstream

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	"bytes"
	"compress/gzip"
	"context"
	"io"
	"net/http"
	"strings"
	"testing"
)

type roundTrip func(*http.Request) (*http.Response, error)

func (f roundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestReadBoundary(t *testing.T) {
	calls := 0
	c, err := New("https://provider.example", http.Header{"Authorization": {"fixture-secret"}}, roundTrip(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.Method != "GET" || r.URL.Host != "provider.example" || r.Header.Get("Authorization") != "fixture-secret" {
			t.Fatal("request escaped transport boundary")
		}
		if _, ok := r.Context().Deadline(); !ok {
			t.Fatal("missing deadline")
		}
		return &http.Response{StatusCode: 200, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(`{}`)), Request: r}, nil
	}))
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = c.Get(context.Background(), nil, "/items", nil, ""); protocol.ErrorCode(err) != protocol.InternalError {
		t.Fatal(err)
	}
	scope := access.NewBudget(context.Background())
	for range limits.Fetches {
		if _, _, err = c.Get(context.Background(), scope, "/items", nil, ""); err != nil {
			t.Fatal(err)
		}
	}
	if _, _, err = c.Get(context.Background(), scope, "/items", nil, ""); protocol.ErrorCode(err) != protocol.LimitExceeded || calls != limits.Fetches {
		t.Fatalf("budget: calls=%d error=%v", calls, err)
	}
	if status := scope.UpstreamStatus(); status == nil || *status != 200 {
		t.Fatal("missing audit status")
	}
}

func TestResponseBoundary(t *testing.T) {
	var zipped bytes.Buffer
	z := gzip.NewWriter(&zipped)
	if _, err := z.Write(bytes.Repeat([]byte("x"), limits.UpstreamBytes+1)); err != nil {
		t.Fatal(err)
	}
	if err := z.Close(); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name   string
		status int
		header http.Header
		body   string
		code   protocol.Code
	}{
		{"redirect", 302, http.Header{"Location": {"https://elsewhere.example"}}, "secret", protocol.UpstreamUnavailable},
		{"authentication", 401, nil, "secret", protocol.UpstreamAuthentication},
		{"authorization", 403, nil, "secret", protocol.UpstreamAuthorization},
		{"rate", 403, http.Header{"X-Ratelimit-Remaining": {"0"}, "Retry-After": {"3"}}, "secret", protocol.RateLimited},
		{"gzip expansion", 200, http.Header{"Content-Encoding": {"gzip"}}, zipped.String(), protocol.LimitExceeded},
	} {
		t.Run(tc.name, func(t *testing.T) {
			calls := 0
			c, err := New("https://provider.example", nil, roundTrip(func(r *http.Request) (*http.Response, error) {
				calls++
				return &http.Response{StatusCode: tc.status, Header: tc.header, Body: io.NopCloser(strings.NewReader(tc.body)), Request: r}, nil
			}))
			if err != nil {
				t.Fatal(err)
			}
			_, _, err = c.Get(context.Background(), access.NewBudget(context.Background()), "/items", nil, "")
			if protocol.ErrorCode(err) != tc.code || calls != 1 || strings.Contains(err.Error(), "secret") {
				t.Fatalf("calls=%d error=%v", calls, err)
			}
			if tc.name == "rate" {
				e := protocol.ErrorPayload(err)
				if e.RetryAfterSeconds == nil || *e.RetryAfterSeconds != 3 {
					t.Fatal("lost retry hint")
				}
			}
		})
	}
}

func TestDirectTLSAndCancellation(t *testing.T) {
	for _, origin := range []string{"http://provider.example", "https://user@provider.example", "https://provider.example:443", "https://provider.example/path"} {
		if _, err := New(origin, nil, nil); err == nil {
			t.Fatalf("accepted %s", origin)
		}
	}
	c, err := New("https://provider.example", nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	tr, ok := c.client.Transport.(*http.Transport)
	if !ok || tr.Proxy != nil || (tr.TLSClientConfig != nil && tr.TLSClientConfig.InsecureSkipVerify) {
		t.Fatal("unsafe default transport")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, _, err = c.Get(ctx, access.NewBudget(ctx), "/items", nil, ""); protocol.ErrorCode(err) != protocol.Timeout {
		t.Fatal(err)
	}
}
