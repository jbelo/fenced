package access

// ResourceScope is a canonical identity. Equality includes both provider and resource kind.
type ResourceScope struct{ Provider, Kind, Key string }

// Valid reports whether all parts of the canonical identity are present.
func (t ResourceScope) Valid() bool { return t.Provider != "" && t.Kind != "" && t.Key != "" }
