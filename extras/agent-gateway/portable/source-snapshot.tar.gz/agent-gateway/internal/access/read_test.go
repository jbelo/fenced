package access_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"context"
	"sync/atomic"
	"testing"
)

type selection struct{ Number int }

var scope = access.ResourceScope{Provider: "example", Kind: "collection", Key: "manuals"}

func fixture(t *testing.T, execute func(context.Context, *access.Budget, access.AuthorizedRead) (access.Result, error)) *access.Reader {
	t.Helper()
	op := access.Operation{Name: "example.read", ScopeKind: "collection", Normalize: func(r access.Request) (access.Request, error) {
		a, ok := r.Args.(selection)
		if !ok || a.Number < 1 || r.Target.Provider != "example" || r.Target.Kind != "collection" {
			return r, access.Fail(access.InvalidInput)
		}
		r.AuditTarget = r.Target.Key
		return r, nil
	}, Execute: execute}
	r, err := access.New([]access.ResourceScope{scope}, []access.Operation{op})
	if err != nil {
		t.Fatal(err)
	}
	return r
}

func request() access.Request {
	return access.Request{Operation: "example.read", Target: scope, Args: selection{Number: 1}}
}
func fits(any) error { return nil }
func admit(ctx context.Context, t *testing.T, r *access.Reader) *access.Permit {
	t.Helper()
	p, err := r.Admit(ctx)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(p.Release)
	return p
}

// R1: typed callers cannot bypass semantic validation or policy.
func TestTypedValidationAndAuthorization(t *testing.T) {
	calls := 0
	r := fixture(t, func(_ context.Context, b *access.Budget, a access.AuthorizedRead) (access.Result, error) {
		calls++
		req, err := a.Request()
		if err != nil {
			t.Fatal(err)
		}
		if req.Args.(selection).Number != 1 {
			t.Fatal("unvalidated arguments")
		}
		if err = b.Charge(); err != nil {
			t.Fatal(err)
		}
		b.RecordStatus(200)
		return access.Result{Data: "view"}, nil
	})
	for _, tc := range []struct {
		name   string
		change func(*access.Request)
		kind   access.Kind
	}{
		{"wrong type", func(r *access.Request) { r.Args = "1" }, access.InvalidInput},
		{"invalid identifier", func(r *access.Request) { r.Args = selection{} }, access.InvalidInput},
		{"wrong kind", func(r *access.Request) { r.Target.Kind = "repository" }, access.InvalidInput},
		{"denied scope", func(r *access.Request) { r.Target.Key = "private" }, access.PolicyDenied},
		{"unknown operation", func(r *access.Request) { r.Operation = "example.unknown" }, access.UnsupportedOperation},
	} {
		t.Run(tc.name, func(t *testing.T) {
			req := request()
			tc.change(&req)
			p := admit(context.Background(), t, r)
			_, record, err := r.Read(p, req, fits)
			if access.FailureKind(err) != tc.kind || calls != 0 || record.Target != nil {
				t.Fatalf("calls=%d record=%+v err=%v", calls, record, err)
			}
		})
	}
	p := admit(context.Background(), t, r)
	data, record, err := r.Read(p, request(), fits)
	if err != nil || data != "view" || calls != 1 || record.Target != "manuals" || record.UpstreamStatus == nil || *record.UpstreamStatus != 200 {
		t.Fatalf("data=%v record=%+v err=%v", data, record, err)
	}
	if _, err := (access.AuthorizedRead{}).Request(); access.FailureKind(err) != access.PolicyDenied {
		t.Fatal("zero authorization accepted")
	}
}

// R4: admission is single-use, reader-bound, bounded and held through publication.
func TestAdmissionLifecycle(t *testing.T) {
	r := fixture(t, func(context.Context, *access.Budget, access.AuthorizedRead) (access.Result, error) {
		return access.Result{}, nil
	})
	other := fixture(t, nil)
	p := admit(context.Background(), t, r)
	for _, bad := range []*access.Permit{nil, {}, admit(context.Background(), t, other)} {
		if _, _, err := r.Read(bad, request(), fits); access.FailureKind(err) != access.InvalidInput {
			t.Fatal("invalid permit accepted")
		}
	}
	if _, _, err := r.Read(p, request(), fits); err != nil {
		t.Fatal(err)
	}
	if _, _, err := r.Read(p, request(), fits); access.FailureKind(err) != access.InvalidInput {
		t.Fatal("replayed permit accepted")
	}
	for i := 1; i < limits.Concurrent; i++ {
		admit(context.Background(), t, r)
	}
	if _, err := r.Admit(context.Background()); access.FailureKind(err) != access.RateLimited {
		t.Fatal("slot released before delivery")
	}
	p.Release()
	p.Release()
	replacement := admit(context.Background(), t, r)
	replacement.Release()
	if _, _, err := r.Read(replacement, request(), fits); access.FailureKind(err) != access.InvalidInput {
		t.Fatal("released permit accepted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := r.Admit(ctx); access.FailureKind(err) != access.Timeout {
		t.Fatal("canceled attempt admitted")
	}
}

func TestFitFailureAndCancellation(t *testing.T) {
	r := fixture(t, func(context.Context, *access.Budget, access.AuthorizedRead) (access.Result, error) {
		return access.Result{Data: "candidate"}, nil
	})
	for _, kind := range []access.Kind{access.LimitExceeded, access.InternalError} {
		p := admit(context.Background(), t, r)
		data, _, err := r.Read(p, request(), func(any) error { return access.Fail(kind) })
		if data != nil || access.FailureKind(err) != kind {
			t.Fatalf("data=%v err=%v", data, err)
		}
		p.Release()
	}
	ctx, cancel := context.WithCancel(context.Background())
	p := admit(ctx, t, r)
	data, _, err := r.Read(p, request(), func(any) error { cancel(); return nil })
	if data != nil || access.FailureKind(err) != access.Timeout {
		t.Fatal("published after fit cancellation")
	}
	p.Release()
	func() {
		p := admit(context.Background(), t, r)
		defer p.Release()
		defer func() {
			if recover() == nil {
				t.Error("missing panic")
			}
		}()
		_, _, _ = r.Read(p, request(), func(any) error { panic("fixture panic") })
	}()
	for range limits.Concurrent {
		admit(context.Background(), t, r)
	}
}

func TestEarlyReleaseDoesNotOveradmitActiveWork(t *testing.T) {
	started, done := make(chan struct{}), make(chan struct{})
	var calls atomic.Int32
	r := fixture(t, func(context.Context, *access.Budget, access.AuthorizedRead) (access.Result, error) {
		calls.Add(1)
		close(started)
		<-done
		return access.Result{}, nil
	})
	p := admit(context.Background(), t, r)
	result := make(chan error, 1)
	go func() { _, _, err := r.Read(p, request(), fits); result <- err }()
	<-started
	for i := 1; i < limits.Concurrent; i++ {
		admit(context.Background(), t, r)
	}
	p.Release()
	if _, err := r.Admit(context.Background()); access.FailureKind(err) != access.RateLimited {
		t.Error("admitted over still-running work")
	}
	close(done)
	if err := <-result; access.FailureKind(err) != access.Timeout {
		t.Fatal(err)
	}
	admit(context.Background(), t, r)
	if calls.Load() != 1 {
		t.Fatal("unexpected execution")
	}
}

// R1: a permissive normalizer cannot authorize a resource kind outside the declaration.
func TestDeclaredScopeKind(t *testing.T) {
	calls := 0
	op := access.Operation{Name: "example.read", ScopeKind: "collection", Normalize: func(r access.Request) (access.Request, error) { return r, nil }, Execute: func(context.Context, *access.Budget, access.AuthorizedRead) (access.Result, error) {
		calls++
		return access.Result{}, nil
	}}
	missing := op
	missing.ScopeKind = ""
	if _, err := access.New(nil, []access.Operation{missing}); err == nil {
		t.Fatal("missing scope declaration accepted")
	}
	wrong := scope
	wrong.Kind = "repository"
	r, err := access.New([]access.ResourceScope{scope, wrong}, []access.Operation{op})
	if err != nil {
		t.Fatal(err)
	}
	p := admit(context.Background(), t, r)
	req := request()
	req.Target = wrong
	if _, _, err = r.Read(p, req, fits); access.FailureKind(err) != access.InvalidInput || calls != 0 {
		t.Fatalf("calls=%d err=%v", calls, err)
	}
}
