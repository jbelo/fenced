// Package access defines typed read execution and its enforcement contracts.
package access

import "errors"

// Kind classifies execution outcomes independently of their wire representation.
type Kind string

// Execution failure kinds.
const (
	InvalidInput           Kind = "invalid_input"
	InvalidCursor          Kind = "invalid_cursor"
	UnsupportedOperation   Kind = "unsupported_operation"
	PolicyDenied           Kind = "policy_denied"
	NotFound               Kind = "not_found"
	RateLimited            Kind = "rate_limited"
	UpstreamAuthentication Kind = "upstream_authentication"
	UpstreamAuthorization  Kind = "upstream_authorization"
	UpstreamUnavailable    Kind = "upstream_unavailable"
	Timeout                Kind = "timeout"
	LimitExceeded          Kind = "limit_exceeded"
	InternalError          Kind = "internal_error"
)

// Failure carries a safe execution kind and optional retry advice.
type Failure struct {
	Kind              Kind
	RetryAfterSeconds *int
}

func (f *Failure) Error() string { return string(f.Kind) }

// Fail constructs a classified execution failure.
func Fail(k Kind) error { return &Failure{Kind: k} }

// FailureKind hides unclassified internal diagnostics.
func FailureKind(err error) Kind {
	var f *Failure
	if errors.As(err, &f) {
		return f.Kind
	}
	return InternalError
}
