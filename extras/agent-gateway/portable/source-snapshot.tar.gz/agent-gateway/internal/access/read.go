package access

import (
	"agent-gateway/internal/limits"
	"context"
	"errors"
	"sync"
)

// Request supplies typed selection arguments and a canonical resource scope.
type (
	Request struct {
		Operation   string
		Target      ResourceScope
		Args        any
		AuditTarget any
	}
	// AuthorizedRead is created only after semantic validation and policy succeed.
	// Its zero value cannot be used as an authorized request.
	AuthorizedRead struct {
		request Request
		valid   bool
	}
)

// Request returns the validated request, or rejects an uninitialized value.
func (a AuthorizedRead) Request() (Request, error) {
	if !a.valid {
		return Request{}, Fail(PolicyDenied)
	}
	return a.request, nil
}

// Bounds reports result usage and requested page capacity.
type (
	Bounds struct{ Items, ItemLimit, Bytes int }
	// Result carries verified data and resource measurements.
	Result struct {
		Data     any
		Bounds   Bounds
		MaxBytes int
	}
	// Operation is a registered semantic contract, with no wire decoder.
	Operation struct {
		Name      string
		ScopeKind string
		Normalize func(Request) (Request, error)
		Execute   func(context.Context, *Budget, AuthorizedRead) (Result, error)
	}
)

// Record contains safe metadata from one read execution.
type (
	Record struct {
		Operation      *string
		Target         any
		UpstreamStatus *int
	}
	// Reader owns immutable operations, policy and shared admission capacity.
	Reader struct {
		operations     map[string]Operation
		policy         map[ResourceScope]struct{}
		slots          chan struct{}
		admissionMu    sync.Mutex
		draining       bool
		policyRevision string
	}
)

// New snapshots trusted operation registration and the target allowlist.
func New(policy []ResourceScope, operations []Operation) (*Reader, error) {
	r := &Reader{operations: map[string]Operation{}, policy: map[ResourceScope]struct{}{}, slots: make(chan struct{}, limits.Concurrent)}
	for _, op := range operations {
		if op.Name == "" || op.ScopeKind == "" || op.Normalize == nil {
			return nil, errors.New("incomplete operation")
		}
		if _, exists := r.operations[op.Name]; exists {
			return nil, errors.New("duplicate operation")
		}
		r.operations[op.Name] = op
	}
	for _, scope := range policy {
		if !scope.Valid() {
			return nil, errors.New("invalid policy scope")
		}
		r.policy[scope] = struct{}{}
	}
	r.policyRevision = Policy(policy).revision()
	return r, nil
}

// Read validates a typed request, authorizes it, executes it and checks publication.
// fits must validate the final representation without publishing or mutating it.
// The caller retains the permit until delivery and audit finish. Continuation
// publication must pass the same fit and deadline checks as single-page results.
func (r *Reader) Read(p *Permit, request Request, fits func(any) error) (data any, record Record, err error) {
	ctx, err := r.claim(p)
	if err != nil {
		return nil, record, err
	}
	defer p.finish()
	if fits == nil {
		return nil, record, Fail(InvalidInput)
	}
	budget := NewBudget(ctx)
	budget.policyRevision = r.policyRevision
	defer func() { record.UpstreamStatus = budget.UpstreamStatus() }()
	op, ok := r.operations[request.Operation]
	if !ok {
		return nil, record, Fail(UnsupportedOperation)
	}
	request, err = op.Normalize(request)
	if err != nil {
		return nil, record, err
	}
	if request.Operation != op.Name || !request.Target.Valid() || request.Target.Kind != op.ScopeKind {
		return nil, record, Fail(InvalidInput)
	}
	if _, ok := r.policy[request.Target]; !ok {
		return nil, record, Fail(PolicyDenied)
	}
	record.Operation = &request.Operation
	record.Target = request.AuditTarget
	if op.Execute == nil {
		return nil, record, Fail(PolicyDenied)
	}
	if ctx.Err() != nil {
		return nil, record, Fail(Timeout)
	}
	result, err := op.Execute(ctx, budget, AuthorizedRead{request: request, valid: true})
	if ctx.Err() != nil {
		return nil, record, Fail(Timeout)
	}
	if err != nil {
		return nil, record, err
	}
	if err = CheckBounds(result); err != nil {
		return nil, record, err
	}
	if err = fits(result.Data); err != nil {
		return nil, record, err
	}
	if ctx.Err() != nil {
		return nil, record, Fail(Timeout)
	}
	return result.Data, record, nil
}

// CheckBounds enforces result measurements before publication.
func CheckBounds(r Result) error {
	b := r.Bounds
	if b.Items < 0 || b.ItemLimit < 0 || b.Bytes < 0 || r.MaxBytes < 0 {
		return Fail(InternalError)
	}
	if b.Items > b.ItemLimit || b.Bytes > r.MaxBytes {
		return Fail(LimitExceeded)
	}
	return nil
}
