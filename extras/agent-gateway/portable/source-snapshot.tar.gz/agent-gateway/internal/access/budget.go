package access

import (
	"agent-gateway/internal/limits"
	"context"
	"sync"
)

// Budget owns per-request fetch accounting and sanitized upstream status.
type Budget struct {
	mu             sync.Mutex
	ctx            context.Context
	fetches        int
	status         *int
	policyRevision string
}

// NewBudget creates accounting for an already deadline-bound request.
func NewBudget(ctx context.Context) *Budget { return &Budget{ctx: ctx} }

// Charge reserves one provider fetch before any request can be sent.
func (s *Budget) Charge() error {
	if s == nil {
		return Fail(InternalError)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ctx.Err() != nil {
		return Fail(Timeout)
	}
	if s.fetches >= limits.Fetches {
		return Fail(LimitExceeded)
	}
	s.fetches++
	return nil
}

// RecordStatus retains only the last HTTP status for audit.
func (s *Budget) RecordStatus(status int) { s.mu.Lock(); defer s.mu.Unlock(); s.status = &status }

// UpstreamStatus snapshots the last status without sharing mutable state.
func (s *Budget) UpstreamStatus() *int {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.status == nil {
		return nil
	}
	v := *s.status
	return &v
}

// PolicyRevision identifies the immutable policy authorized by Read for this attempt.
func (s *Budget) PolicyRevision() string { return s.policyRevision }
