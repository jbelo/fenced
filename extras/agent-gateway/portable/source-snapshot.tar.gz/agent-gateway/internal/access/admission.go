package access

import (
	"agent-gateway/internal/limits"
	"context"
	"sync"
)

// Permit binds one attempt to its reader, deadline and concurrency slot.
type Permit struct {
	mu                     sync.Mutex
	owner                  *Reader
	ctx                    context.Context
	cancel                 context.CancelFunc
	used, released, active bool
}

// Admit reserves capacity immediately, before the boundary reads its input.
func (r *Reader) Admit(ctx context.Context) (*Permit, error) {
	r.admissionMu.Lock()
	defer r.admissionMu.Unlock()
	if r.draining {
		return nil, Fail(RateLimited)
	}
	if ctx.Err() != nil {
		return nil, Fail(Timeout)
	}
	select {
	case r.slots <- struct{}{}:
	default:
		return nil, Fail(RateLimited)
	}
	ctx, cancel := context.WithTimeout(ctx, limits.RequestTimeout)
	return &Permit{owner: r, ctx: ctx, cancel: cancel}, nil
}

// Context exposes the deadline shared by decoding and execution.
func (p *Permit) Context() context.Context { return p.ctx }

// Release relinquishes admission once; callers defer it through delivery and audit.
func (p *Permit) Release() {
	if p == nil {
		return
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.released {
		return
	}
	p.released = true
	if p.owner != nil {
		p.cancel()
		if !p.active {
			<-p.owner.slots
		}
	}
}

func (r *Reader) claim(p *Permit) (context.Context, error) {
	if p == nil {
		return nil, Fail(InvalidInput)
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.owner != r || p.used || p.released {
		return nil, Fail(InvalidInput)
	}
	if p.ctx.Err() != nil {
		return nil, Fail(Timeout)
	}
	p.used = true
	p.active = true
	return p.ctx, nil
}

func (p *Permit) finish() {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.active = false
	if p.released {
		<-p.owner.slots
	}
}

// Drain stops new admission without canceling already admitted requests.
func (r *Reader) Drain() { r.admissionMu.Lock(); defer r.admissionMu.Unlock(); r.draining = true }

// Ready reports whether the initialized reader accepts new work.
func (r *Reader) Ready() bool { r.admissionMu.Lock(); defer r.admissionMu.Unlock(); return !r.draining }
