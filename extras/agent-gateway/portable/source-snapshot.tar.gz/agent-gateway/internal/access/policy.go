package access

import (
	"crypto/sha256"
	"encoding/hex"
	"sort"
)

// Policy is the default-deny allowlist of complete canonical target identities.
type Policy []ResourceScope

// Allows compares the complete target identity against the allowlist.
func (p Policy) Allows(target ResourceScope) bool {
	if !target.Valid() {
		return false
	}
	for _, allowed := range p {
		if allowed == target {
			return true
		}
	}
	return false
}

// revision fingerprints the complete immutable allowlist in canonical order.
func (p Policy) revision() string {
	entries := make([]string, 0, len(p))
	for _, target := range p {
		digest := CursorBinding("", "", target, nil)
		entries = append(entries, string(digest[:]))
	}
	sort.Strings(entries)
	h := sha256.New()
	for _, entry := range entries {
		_, _ = h.Write([]byte(entry))
	}
	return hex.EncodeToString(h.Sum(nil))
}
