package access

import (
	"agent-gateway/internal/limits"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"time"
)

// CursorState is a sealed traversal position, not a cached result page.
// Position is provider-owned validated continuation data, never a forwarding URL.
type CursorState struct {
	Binding                  [32]byte
	ExpiresAt                int64
	Pages, Items, Candidates int
	Terminal                 bool
	Position                 []byte
}

// CursorCodec protects bounded traversal positions using runtime key material.
type CursorCodec interface {
	Seal(CursorState) (string, error)
	Open(string) (CursorState, error)
}

// CursorBinding binds canonical request components without ambiguous concatenation.
// arguments must be a canonical encoding of normalized arguments, excluding cursor.
func CursorBinding(policy, operation string, target ResourceScope, arguments []byte) [32]byte {
	h := sha256.New()
	for _, part := range [][]byte{[]byte(policy), []byte(operation), []byte(target.Provider), []byte(target.Kind), []byte(target.Key), arguments} {
		var size [8]byte
		binary.BigEndian.PutUint64(size[:], uint64(len(part)))
		_, _ = h.Write(size[:])
		_, _ = h.Write(part)
	}
	var digest [32]byte
	copy(digest[:], h.Sum(nil))
	return digest
}

// Continuations enforces expiry and logical traversal bounds independently of codecs.
// Callers must authorize every request before Resume, validate provider identity before
// releasing data, and apply response-fit/deadline checks after Next. It retains no pages.
type Continuations struct {
	codec CursorCodec
	now   func() time.Time
}

// NewContinuations requires a codec and clock; production assembly supplies time.Now.
func NewContinuations(codec CursorCodec, now func() time.Time) (*Continuations, error) {
	if codec == nil || now == nil {
		return nil, errors.New("cursor codec and clock required")
	}
	return &Continuations{codec: codec, now: now}, nil
}

// Resume opens a continuation or starts an independent traversal for an empty token.
// A terminal position fails before a caller needs to contact a provider.
func (c *Continuations) Resume(binding [32]byte, token string) (CursorState, error) {
	if token == "" {
		return CursorState{Binding: binding}, nil
	}
	state, err := c.codec.Open(token)
	if err != nil {
		return CursorState{}, err
	}
	if state.Binding != binding || !validState(state) || c.now().UnixNano() >= state.ExpiresAt {
		return CursorState{}, Fail(InvalidCursor)
	}
	if state.Terminal {
		return CursorState{}, Fail(LimitExceeded)
	}
	return state, nil
}

func validState(s CursorState) bool {
	return s.ExpiresAt > 0 && s.Pages > 0 && s.Pages <= limits.TraversalPages &&
		s.Items >= 0 && s.Items <= limits.TraversalItems && s.Candidates >= 0 && s.Candidates <= limits.TraversalCandidates &&
		(s.Terminal || (s.Pages < limits.TraversalPages && s.Items < limits.TraversalItems && s.Candidates < limits.TraversalCandidates))
}

// PageUsage counts this page's returned items and newly examined search candidates.
// Re-fetched prefixes are excluded from Candidates but still consume request budgets.
type PageUsage struct{ Items, Candidates int }

// Next seals a new position after a verified page, or returns nil on exhaustion.
// Cap and oversized-position cases return a compact terminal cursor, preserving data.
// The caller supplies the original state on retries; there is no mutable iterator.
func (c *Continuations) Next(prior CursorState, usage PageUsage, position []byte, more bool) (*string, error) {
	switch {
	case prior.Pages == 0:
		if prior.Items != 0 || prior.Candidates != 0 || prior.ExpiresAt != 0 || prior.Terminal {
			return nil, Fail(InternalError)
		}
		prior.ExpiresAt = c.now().Add(limits.CursorLifetime).UnixNano()
	case !validState(prior) || prior.Terminal:
		return nil, Fail(InvalidCursor)
	case c.now().UnixNano() >= prior.ExpiresAt:
		return nil, Fail(InvalidCursor)
	}
	if usage.Items < 0 || usage.Items > limits.PageItems || usage.Candidates < 0 ||
		usage.Items > limits.TraversalItems-prior.Items || usage.Candidates > limits.TraversalCandidates-prior.Candidates {
		return nil, Fail(LimitExceeded)
	}
	prior.Pages++
	prior.Items += usage.Items
	prior.Candidates += usage.Candidates
	if !more {
		return nil, nil
	}
	prior.Terminal = prior.Pages == limits.TraversalPages || prior.Items == limits.TraversalItems || prior.Candidates == limits.TraversalCandidates
	prior.Position = position
	if prior.Terminal {
		prior.Position = nil
	}
	token, err := c.codec.Seal(prior)
	if err != nil && FailureKind(err) == LimitExceeded && !prior.Terminal {
		prior.Terminal = true
		prior.Position = nil
		token, err = c.codec.Seal(prior)
	}
	if err != nil {
		return nil, err
	}
	return &token, nil
}
