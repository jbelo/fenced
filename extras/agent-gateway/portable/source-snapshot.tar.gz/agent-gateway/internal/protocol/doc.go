// Package protocol defines wire envelopes, strict JSON and public error mappings.
package protocol
