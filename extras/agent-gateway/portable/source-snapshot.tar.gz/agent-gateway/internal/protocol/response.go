package protocol

// ErrorBody is the sanitized failure payload returned to clients.
type ErrorBody struct {
	Code              Code   `json:"code"`
	Message           string `json:"message"`
	RetryAfterSeconds *int   `json:"retry_after_seconds"`
}

// Envelope wraps either operation data or a public error with protocol metadata.
type Envelope struct {
	Version   string     `json:"version"`
	RequestID *string    `json:"request_id"`
	Data      any        `json:"data,omitempty"`
	Error     *ErrorBody `json:"error,omitempty"`
}
