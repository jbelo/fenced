package protocol

import (
	"errors"
	"fmt"
	"testing"
)

func TestStrictEnvelope(t *testing.T) {
	for _, raw := range []string{`{"operation":"x","operation":"y","target":{},"args":{}}`, `{"operation":"x","target":{},"args":{},"extra":true}`, `{"operation":"x","target":{},"args":{}} {}`, `{"operation":"x","target":null,"args":{}}`} {
		if _, err := DecodeRequest([]byte(raw)); err == nil {
			t.Fatalf("accepted %s", raw)
		}
	}
}

func TestPublicErrorMappings(t *testing.T) {
	for _, tc := range []struct {
		code       Code
		http, exit int
	}{{InvalidInput, 400, 2}, {InvalidCursor, 400, 2}, {UnsupportedOperation, 400, 2}, {PolicyDenied, 403, 4}, {NotFound, 404, 5}, {RateLimited, 429, 6}, {UpstreamAuthentication, 502, 7}, {UpstreamAuthorization, 502, 7}, {UpstreamUnavailable, 502, 7}, {Timeout, 504, 8}, {LimitExceeded, 413, 9}, {InternalError, 500, 10}, {TransportError, 500, 11}, {ConfigurationError, 500, 12}, {Success, 200, 0}} {
		if HTTPStatus(tc.code) != tc.http || ExitCode(tc.code) != tc.exit {
			t.Errorf("mapping %s", tc.code)
		}
	}
	for _, err := range []error{errors.New("private diagnostic"), Fail("unregistered"), Fail(Success)} {
		if e := ErrorPayload(err); e.Code != InternalError || e.Message != "internal_error" {
			t.Fatal(e)
		}
	}
	if ErrorCode(fmt.Errorf("wrapped: %w", Fail(NotFound))) != NotFound {
		t.Fatal("lost wrapped code")
	}
}

func TestRetryAdviceOnlyForRateLimits(t *testing.T) {
	seconds := 3
	if body := ErrorPayload(&RequestError{Code: UpstreamUnavailable, RetryAfterSeconds: &seconds}); body.RetryAfterSeconds != nil {
		t.Fatal("retry advice on non-rate failure")
	}
}
