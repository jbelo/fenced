package protocol

// Page holds a bounded result list and its optional continuation handle.
type Page[T any] struct {
	Items      []T     `json:"items"`
	NextCursor *string `json:"next_cursor"`
}
