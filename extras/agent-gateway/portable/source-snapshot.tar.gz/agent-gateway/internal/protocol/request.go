package protocol

import (
	"agent-gateway/internal/limits"
	"encoding/json"
	"unicode"
)

// Request is the raw versioned read request before operation-specific decoding.
type Request struct {
	Operation string          `json:"operation"`
	Target    json.RawMessage `json:"target"`
	Args      json.RawMessage `json:"args"`
}

// DecodeRequest checks the body bound and strictly decodes the common request envelope.
func DecodeRequest(data []byte) (Request, error) {
	var r Request
	if len(data) > limits.RequestBytes {
		return r, Fail(LimitExceeded)
	}
	if DecodeStrict(data, &r) != nil || r.Operation == "" || len(r.Target) == 0 || len(r.Args) == 0 {
		return r, Fail(InvalidInput)
	}
	return r, nil
}

// ValidID reports whether an integer is positive and exactly representable in JSON consumers.
func ValidID(n int64) bool { return n > 0 && n <= 9007199254740991 }

// ValidatePage checks the common page-size and cursor-input bounds.
func ValidatePage(limit int, cursor string) error {
	if limit < 1 || limit > limits.PageItems {
		return Fail(InvalidInput)
	}
	if len(cursor) > limits.CursorBytes {
		return Fail(InvalidCursor)
	}
	for _, ch := range cursor {
		if unicode.IsControl(ch) {
			return Fail(InvalidInput)
		}
	}
	return nil
}
