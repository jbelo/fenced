package protocol

import (
	"agent-gateway/internal/access"
	"errors"
)

// Code is a stable public error or success identifier.
type Code string

// Public v1 outcome codes.
const (
	Success                Code = "success"
	InvalidInput           Code = "invalid_input"
	InvalidCursor          Code = "invalid_cursor"
	UnsupportedOperation   Code = "unsupported_operation"
	PolicyDenied           Code = "policy_denied"
	NotFound               Code = "not_found"
	RateLimited            Code = "rate_limited"
	UpstreamAuthentication Code = "upstream_authentication"
	UpstreamAuthorization  Code = "upstream_authorization"
	UpstreamUnavailable    Code = "upstream_unavailable"
	Timeout                Code = "timeout"
	LimitExceeded          Code = "limit_exceeded"
	InternalError          Code = "internal_error"
	TransportError         Code = "transport_error"
	ConfigurationError     Code = "configuration_error"
)

type errorDetails struct {
	httpStatus, exitCode int
	message              string
}

var errorCatalogue = map[Code]errorDetails{
	InvalidInput:           {400, 2, "invalid_input"},
	InvalidCursor:          {400, 2, "invalid_cursor"},
	UnsupportedOperation:   {400, 2, "unsupported_operation"},
	PolicyDenied:           {403, 4, "policy_denied"},
	NotFound:               {404, 5, "not_found"},
	RateLimited:            {429, 6, "rate_limited"},
	UpstreamAuthentication: {502, 7, "upstream_authentication"},
	UpstreamAuthorization:  {502, 7, "upstream_authorization"},
	UpstreamUnavailable:    {502, 7, "upstream_unavailable"},
	Timeout:                {504, 8, "timeout"},
	LimitExceeded:          {413, 9, "limit_exceeded"},
	InternalError:          {500, 10, "internal_error"},
	TransportError:         {500, 11, "transport_error"},
	ConfigurationError:     {500, 12, "configuration_error"},
	Success:                {200, 0, "success"},
}

func details(code Code) errorDetails {
	if d, ok := errorCatalogue[code]; ok {
		return d
	}
	return errorCatalogue[InternalError]
}

// HTTPStatus returns the HTTP status from the public error catalogue.
func HTTPStatus(code Code) int { return details(code).httpStatus }

// ExitCode returns the CLI status from the public error catalogue.
func ExitCode(code Code) int { return details(code).exitCode }

// Message returns a safe public message, never upstream error text.
func Message(code Code) string { return details(code).message }

// RequestError carries a public code and sanitized retry advice.
type RequestError struct {
	Code              Code
	RetryAfterSeconds *int
}

// Error returns only the safe public message.
func (e *RequestError) Error() string { return Message(e.Code) }

// Fail constructs a public failure without private diagnostic content.
func Fail(code Code) error { return &RequestError{Code: code} }

// ErrorCode classifies errors, hiding unknown or unregistered details.
func ErrorCode(err error) Code {
	var failure *access.Failure
	if errors.As(err, &failure) {
		return failureCode(failure.Kind)
	}
	var e *RequestError
	if errors.As(err, &e) {
		if _, ok := errorCatalogue[e.Code]; ok && e.Code != Success {
			return e.Code
		}
	}
	return InternalError
}

// ErrorPayload builds a sanitized error envelope payload.
func ErrorPayload(err error) *ErrorBody {
	code := ErrorCode(err)
	body := &ErrorBody{Code: code, Message: Message(code)}
	var f *access.Failure
	if code == RateLimited && errors.As(err, &f) && f.RetryAfterSeconds != nil && *f.RetryAfterSeconds >= 0 {
		v := *f.RetryAfterSeconds
		body.RetryAfterSeconds = &v
	}
	var e *RequestError
	if code == RateLimited && errors.As(err, &e) && e.RetryAfterSeconds != nil && *e.RetryAfterSeconds >= 0 {
		v := *e.RetryAfterSeconds
		body.RetryAfterSeconds = &v
	}
	return body
}

var failureCodes = map[access.Kind]Code{
	access.InvalidInput: InvalidInput, access.InvalidCursor: InvalidCursor,
	access.UnsupportedOperation: UnsupportedOperation, access.PolicyDenied: PolicyDenied,
	access.NotFound: NotFound, access.RateLimited: RateLimited,
	access.UpstreamAuthentication: UpstreamAuthentication, access.UpstreamAuthorization: UpstreamAuthorization,
	access.UpstreamUnavailable: UpstreamUnavailable, access.Timeout: Timeout,
	access.LimitExceeded: LimitExceeded, access.InternalError: InternalError,
}

func failureCode(kind access.Kind) Code {
	if code, ok := failureCodes[kind]; ok {
		return code
	}
	return InternalError
}

// ToFailure translates a boundary or adapter error into a safe execution failure.
func ToFailure(err error) error {
	if err == nil {
		return nil
	}
	body := ErrorPayload(err)
	for kind, code := range failureCodes {
		if code == body.Code {
			return &access.Failure{Kind: kind, RetryAfterSeconds: body.RetryAfterSeconds}
		}
	}
	return access.Fail(access.InternalError)
}
