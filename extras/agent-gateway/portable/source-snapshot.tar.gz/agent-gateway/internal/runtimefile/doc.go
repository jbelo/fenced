// Package runtimefile provides bounded runtime configuration and private secret-file reads.
package runtimefile
