package runtimefile

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSecretDescriptorSafeguards(t *testing.T) {
	for _, tc := range []struct {
		name, value string
		mode        os.FileMode
		wantError   bool
	}{
		{"valid", "synthetic-token", 0o400, false},
		{"writable", "synthetic-token", 0o600, true},
		{"readable by others", "synthetic-token", 0o444, true},
		{"oversized", strings.Repeat("x", 8193), 0o400, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "secret")
			if err := os.WriteFile(path, []byte(tc.value), 0o600); err != nil {
				t.Fatal(err)
			}
			if err := os.Chmod(path, tc.mode); err != nil {
				t.Fatal(err)
			}
			value, err := ReadSecret(path)
			if (err != nil) != tc.wantError {
				t.Fatalf("unexpected error: %v", err)
			}
			if err == nil && string(value) != tc.value {
				t.Fatal("secret changed")
			}
		})
	}
	if _, err := ReadSecret(t.TempDir()); err == nil {
		t.Fatal("directory accepted as secret")
	}
}
