package runtimefile

import (
	"agent-gateway/internal/limits"
	"errors"
	"io"
	"os"
)

// ReadBoundedFile reads a regular file without exceeding the supplied byte limit.
func ReadBoundedFile(path string, limit int64) ([]byte, error) {
	f, err := os.Open(path) // #nosec G304 -- Operator-selected local path; the opened file is checked for type and bounded before use.
	if err != nil {
		return nil, errors.New("cannot open runtime file")
	}
	// Closing a read-only descriptor cannot change the data or validation result.
	defer func() { _ = f.Close() }()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() {
		return nil, errors.New("runtime file must be regular")
	}
	data, err := io.ReadAll(io.LimitReader(f, limit+1))
	if err != nil || int64(len(data)) > limit {
		return nil, errors.New("runtime file exceeds bound or is unreadable")
	}
	return data, nil
}

// ReadSecret validates the same open descriptor used to read the bounded secret.
func ReadSecret(path string) ([]byte, error) {
	f, err := os.Open(path) // #nosec G304 -- Operator-selected local path; the opened file is checked for type and bounded before use.
	if err != nil {
		return nil, errors.New("secret file unavailable")
	}
	// Closing a read-only descriptor cannot change the data or validation result.
	defer func() { _ = f.Close() }()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Mode().Perm() != 0o400 {
		return nil, errors.New("secret permissions or type invalid")
	}
	data, err := io.ReadAll(io.LimitReader(f, limits.SecretBytes+1))
	if err != nil || len(data) > limits.SecretBytes {
		return nil, errors.New("secret exceeds bound or is unreadable")
	}
	return data, nil
}
