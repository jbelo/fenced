package cursor_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/limits"
	"encoding/base64"
	"reflect"
	"strings"
	"sync"
	"testing"
	"time"
)

func newCodec(t *testing.T) *cursor.Codec {
	t.Helper()
	c, err := cursor.New()
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestCodecAuthenticationAndBounds(t *testing.T) {
	c := newCodec(t)
	state := access.CursorState{ExpiresAt: 1, Pages: 1, Position: []byte("private provider token")}
	token, err := c.Seal(state)
	if err != nil {
		t.Fatal(err)
	}
	got, err := c.Open(token)
	if err != nil || !reflect.DeepEqual(state, got) {
		t.Fatalf("round trip: %v, %v", got, err)
	}
	second, err := c.Seal(state)
	if err != nil || second == token {
		t.Fatal("nonce reuse", err)
	}
	raw, err := base64.RawURLEncoding.DecodeString(token)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(raw), "private provider token") {
		t.Fatal("plaintext exposed")
	}
	for i := range raw {
		altered := append([]byte(nil), raw...)
		altered[i] ^= 1
		if _, err := c.Open(base64.RawURLEncoding.EncodeToString(altered)); access.FailureKind(err) != access.InvalidCursor {
			t.Fatalf("byte %d: %v", i, err)
		}
	}
	for _, bad := range []string{"", "!", token[:len(token)-1], token + "=", strings.Repeat("a", limits.CursorBytes+1)} {
		if _, err := c.Open(bad); access.FailureKind(err) != access.InvalidCursor {
			t.Fatalf("malformed accepted: %v", err)
		}
	}
	if _, err := newCodec(t).Open(token); access.FailureKind(err) != access.InvalidCursor {
		t.Fatal("restart accepted", err)
	}
	state.Position = make([]byte, limits.CursorBytes+1)
	if _, err := c.Seal(state); access.FailureKind(err) != access.LimitExceeded {
		t.Fatal(err)
	}
	// JSON/base64 expansion must also obey the encoded bound.
	state.Position = make([]byte, limits.CursorBytes)
	if _, err := c.Seal(state); access.FailureKind(err) != access.LimitExceeded {
		t.Fatal(err)
	}
}

func TestConcurrentCodec(t *testing.T) {
	c := newCodec(t)
	var wg sync.WaitGroup
	for range 32 {
		wg.Go(func() {
			s := access.CursorState{Pages: 1, Position: []byte("position")}
			token, err := c.Seal(s)
			if err != nil {
				t.Error(err)
				return
			}
			got, err := c.Open(token)
			if err != nil || !reflect.DeepEqual(s, got) {
				t.Error("concurrent roundtrip", err)
			}
		})
	}
	wg.Wait()
}

func TestContinuationRules(t *testing.T) {
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	c := newCodec(t)
	pages, err := access.NewContinuations(c, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	binding := access.CursorBinding("policy", "github.pr.list", access.ResourceScope{Provider: "github", Kind: "repository", Key: "company/project"}, []byte(`{"limit":50,"state":"open"}`))
	state, err := pages.Resume(binding, "")
	if err != nil {
		t.Fatal(err)
	}
	token, err := pages.Next(state, access.PageUsage{Items: 50}, []byte("page=2"), true)
	if err != nil {
		t.Fatal(err)
	}
	first, err := pages.Resume(binding, *token)
	if err != nil {
		t.Fatal(err)
	}
	now = now.Add(time.Minute)
	next, err := pages.Next(first, access.PageUsage{Items: 50}, []byte("page=3"), true)
	if err != nil {
		t.Fatal(err)
	}
	second, err := pages.Resume(binding, *next)
	if err != nil || second.ExpiresAt != first.ExpiresAt {
		t.Fatal("expiry extended", err)
	}
	replay, err := pages.Resume(binding, *token)
	if err != nil || !reflect.DeepEqual(first, replay) {
		t.Fatal("replay advanced position", err)
	}
	wrong := binding
	wrong[0] ^= 1
	if _, err := pages.Resume(wrong, *token); access.FailureKind(err) != access.InvalidCursor {
		t.Fatal("binding", err)
	}
	now = time.Unix(0, first.ExpiresAt)
	if _, err := pages.Resume(binding, *token); access.FailureKind(err) != access.InvalidCursor {
		t.Fatal("expiry", err)
	}
}

func TestTerminalAndExhaustion(t *testing.T) {
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	c := newCodec(t)
	pages, err := access.NewContinuations(c, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name     string
		prior    access.CursorState
		usage    access.PageUsage
		position []byte
	}{
		{"pages", access.CursorState{Pages: 9, ExpiresAt: now.Add(time.Minute).UnixNano()}, access.PageUsage{Items: 1}, []byte("next")},
		{"items", access.CursorState{Pages: 9, Items: 450, ExpiresAt: now.Add(time.Minute).UnixNano()}, access.PageUsage{Items: 50}, []byte("next")},
		{"candidates empty page", access.CursorState{Pages: 1, Candidates: 499, ExpiresAt: now.Add(time.Minute).UnixNano()}, access.PageUsage{Candidates: 1}, []byte("next")},
		{"oversized", access.CursorState{}, access.PageUsage{Items: 1}, make([]byte, limits.CursorBytes+1)},
	} {
		t.Run(tc.name, func(t *testing.T) {
			token, err := pages.Next(tc.prior, tc.usage, tc.position, true)
			if err != nil || token == nil || len(*token) > limits.CursorBytes {
				t.Fatal("terminal creation", err)
			}
			sealed, err := c.Open(*token)
			if err != nil || !sealed.Terminal || len(sealed.Position) != 0 {
				t.Fatal("terminal retains payload", err)
			}
			if _, err := pages.Resume(tc.prior.Binding, *token); access.FailureKind(err) != access.LimitExceeded {
				t.Fatal(err)
			}
			wrong := tc.prior.Binding
			wrong[0] ^= 1
			if _, err := pages.Resume(wrong, *token); access.FailureKind(err) != access.InvalidCursor {
				t.Fatal("terminal binding", err)
			}
			exhausted, err := pages.Next(tc.prior, tc.usage, tc.position, false)
			if err != nil || exhausted != nil {
				t.Fatal("false continuation", err)
			}
		})
	}
}

func TestCursorBindingSeparatesComponents(t *testing.T) {
	target := access.ResourceScope{Provider: "github", Kind: "repository", Key: "company/project"}
	original := access.CursorBinding("p", "ab", target, []byte("c"))
	if original == access.CursorBinding("p", "a", target, []byte("bc")) {
		t.Fatal("ambiguous binding")
	}
	for _, changed := range [][32]byte{
		access.CursorBinding("other policy", "ab", target, []byte("c")),
		access.CursorBinding("p", "other operation", target, []byte("c")),
		access.CursorBinding("p", "ab", access.ResourceScope{Provider: "shortcut", Kind: target.Kind, Key: target.Key}, []byte("c")),
		access.CursorBinding("p", "ab", access.ResourceScope{Provider: target.Provider, Kind: "other", Key: target.Key}, []byte("c")),
		access.CursorBinding("p", "ab", access.ResourceScope{Provider: target.Provider, Kind: target.Kind, Key: "other/repo"}, []byte("c")),
		access.CursorBinding("p", "ab", target, []byte("other args")),
	} {
		if original == changed {
			t.Fatal("binding omitted component")
		}
	}
}

func TestEmptyPageAndPositionalReplay(t *testing.T) {
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	c := newCodec(t)
	pages, err := access.NewContinuations(c, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	// The provider fixture filtered out every candidate on the first page.
	token, err := pages.Next(access.CursorState{}, access.PageUsage{Candidates: 20}, []byte("page-2-offset-0"), true)
	if err != nil || token == nil {
		t.Fatal("empty filtered page lost continuation", err)
	}
	original, err := pages.Resume([32]byte{}, *token)
	if err != nil || original.Items != 0 || original.Candidates != 20 || original.Pages != 1 {
		t.Fatal("wrong empty-page accounting", err)
	}
	// Independent evaluations can report different counts/positions when upstream
	// changes. The first response must not advance or cache the input cursor.
	first, err := pages.Next(original, access.PageUsage{Items: 2, Candidates: 2}, []byte("page-2-offset-2"), true)
	if err != nil {
		t.Fatal(err)
	}
	replay, err := pages.Resume([32]byte{}, *token)
	if err != nil || !reflect.DeepEqual(original, replay) {
		t.Fatal("mutable replay", err)
	}
	changed, err := pages.Next(replay, access.PageUsage{Items: 1, Candidates: 1}, []byte("page-2-offset-1"), true)
	if err != nil {
		t.Fatal(err)
	}
	before, err := c.Open(*first)
	if err != nil {
		t.Fatal(err)
	}
	after, err := c.Open(*changed)
	if err != nil {
		t.Fatal(err)
	}
	if before.Items != 2 || after.Items != 1 || before.Candidates != 22 || after.Candidates != 21 {
		t.Fatal("replay counters were cached or accumulated")
	}
}

func TestInvalidStateAndUsage(t *testing.T) {
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	c := newCodec(t)
	pages, err := access.NewContinuations(c, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	for _, state := range []access.CursorState{
		{Pages: -1},
		{Pages: 1, ExpiresAt: now.UnixNano()},
		{Pages: 11, ExpiresAt: now.Add(time.Minute).UnixNano()},
		{Pages: 1, Items: -1, ExpiresAt: now.Add(time.Minute).UnixNano()},
		{Pages: 1, Candidates: 501, ExpiresAt: now.Add(time.Minute).UnixNano()},
		{Pages: 10, ExpiresAt: now.Add(time.Minute).UnixNano()},
	} {
		token, err := c.Seal(state)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := pages.Resume([32]byte{}, token); access.FailureKind(err) != access.InvalidCursor {
			t.Fatalf("invalid state accepted: %+v, %v", state, err)
		}
	}
	for _, usage := range []access.PageUsage{{Items: -1}, {Items: 51}, {Candidates: -1}, {Candidates: 501}} {
		if _, err := pages.Next(access.CursorState{}, usage, nil, false); access.FailureKind(err) != access.LimitExceeded {
			t.Fatal("bad usage accepted", usage, err)
		}
	}
	if _, err := access.NewContinuations(nil, time.Now); err == nil {
		t.Fatal("nil codec accepted")
	}
	if _, err := access.NewContinuations(c, nil); err == nil {
		t.Fatal("nil clock accepted")
	}
}

func TestMaximumPositionSize(t *testing.T) {
	c := newCodec(t)
	state := access.CursorState{ExpiresAt: 9223372036854775807, Pages: 10, Items: 500, Candidates: 500}
	for i := range state.Binding {
		state.Binding[i] = 255
	}
	low, high := 0, limits.CursorBytes
	for low < high {
		mid := (low + high + 1) / 2
		state.Position = make([]byte, mid)
		_, err := c.Seal(state)
		if err == nil {
			low = mid
		} else {
			high = mid - 1
		}
	}
	t.Logf("maximum position under worst-case metadata: %d bytes", low)
	if low != 945 {
		t.Fatal("cursor capacity regression", low)
	}
	state.Position = make([]byte, low)
	token, err := c.Seal(state)
	if err != nil || len(token) > limits.CursorBytes {
		t.Fatal("boundary", err)
	}
	state.Position = make([]byte, low+1)
	if _, err := c.Seal(state); access.FailureKind(err) != access.LimitExceeded {
		t.Fatal("overflow", err)
	}
}
