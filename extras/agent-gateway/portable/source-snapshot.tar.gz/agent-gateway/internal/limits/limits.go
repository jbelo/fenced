// Package limits defines the fixed v1 resource bounds shared by all integrations.
package limits

import "time"

// Fixed v1 resource limits. These are not operator-configurable.
const (
	RequestBytes        = 16 << 10
	ResponseBytes       = 1 << 20
	ConfigBytes         = 1 << 20
	SecretBytes         = 8 << 10
	DiffBytes           = 512 << 10
	UpstreamBytes       = 4 << 20
	Fetches             = 5
	Concurrent          = 8
	PageItems           = 50
	DefaultPageItems    = 20
	CursorBytes         = 2048
	RequestTimeout      = 15 * time.Second
	FetchTimeout        = 10 * time.Second
	CursorLifetime      = 10 * time.Minute
	TraversalPages      = 10
	TraversalItems      = 500
	TraversalCandidates = 500
)
