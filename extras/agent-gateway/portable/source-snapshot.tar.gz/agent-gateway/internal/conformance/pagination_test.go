package conformance

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cli"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/providers/github/commands"
	"agent-gateway/internal/providers/github/contract"
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"testing"
	"time"
)

type paginationFixture struct {
	Name       string          `json:"name"`
	Request    json.RawMessage `json:"request"`
	Response   json.RawMessage `json:"response"`
	HTTPStatus *int            `json:"http_status"`
	ExitCode   int             `json:"exit_code"`
}

type fixtureTransport func(*http.Request) (*http.Response, error)

func (f fixtureTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// These executable examples cover the continuation boundary and actual CLI envelopes.
// Provider page fetching is supplied by fixtures, not by the unfinished REST traversal.
func TestPaginationExamples(t *testing.T) {
	data, err := os.ReadFile("../../docs/examples/pagination.json")
	if err != nil {
		t.Fatal(err)
	}
	var fixtures []paginationFixture
	if err := json.Unmarshal(data, &fixtures); err != nil {
		t.Fatal(err)
	}
	checkDocumentedFixtures(t, fixtures)
	for _, f := range fixtures {
		t.Run(f.Name, func(t *testing.T) { runPaginationFixture(t, f) })
	}
}

func runPaginationFixture(t *testing.T, f paginationFixture) {
	t.Helper()
	var expected protocol.Envelope
	if err := json.Unmarshal(f.Response, &expected); err != nil {
		t.Fatal(err)
	}
	runner, err := cli.New(commands.Commands())
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "config.json")
	if err := os.WriteFile(path, []byte(`{"gateway_url":"http://agent-gateway:8080"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	args := []string{"github", "pr", "list", "--repo", "company/project", "--state", "open", "--limit", "1"}
	var actual protocol.Envelope
	if f.HTTPStatus != nil {
		actual = exerciseContinuation(t, f, expected)
		var request protocol.Request
		if err := json.Unmarshal(f.Request, &request); err != nil {
			t.Fatal(err)
		}
		var input contract.PRListArgs
		if err := json.Unmarshal(request.Args, &input); err != nil {
			t.Fatal(err)
		}
		args[len(args)-1] = strconv.Itoa(input.Limit)
		if input.Cursor != "" {
			args = append(args, "--cursor", input.Cursor)
		}
	}
	transport := fixtureTransport(func(r *http.Request) (*http.Response, error) {
		if f.Name == "configuration" {
			t.Error("configuration failure contacted gateway")
		}
		if f.Name == "transport" {
			return nil, errors.New("fixture connection failure")
		}
		defer func() {
			if err := r.Body.Close(); err != nil {
				t.Error(err)
			}
		}()
		received, err := io.ReadAll(r.Body)
		if err != nil {
			return nil, err
		}
		var sent, wanted any
		if err := json.Unmarshal(received, &sent); err != nil {
			return nil, err
		}
		if err := json.Unmarshal(f.Request, &wanted); err != nil {
			return nil, err
		}
		if !reflect.DeepEqual(sent, wanted) {
			t.Errorf("CLI request mismatch: %s", received)
		}
		body, err := json.Marshal(actual)
		if err != nil {
			return nil, err
		}
		return &http.Response{StatusCode: *f.HTTPStatus, Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(body))}, nil
	})
	if f.Name == "configuration" {
		path = filepath.Join(t.TempDir(), "missing.json")
	}
	var output bytes.Buffer
	exit := runner.RunWithClient(args, path, &output, &http.Client{Transport: transport})
	if exit != f.ExitCode {
		t.Fatalf("exit %d, expected %d: %s", exit, f.ExitCode, output.String())
	}
	var got any
	if err := json.Unmarshal(output.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	var want any
	if err := json.Unmarshal(f.Response, &want); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("envelope mismatch:\n%s\nexpected:\n%s", output.String(), f.Response)
	}
}

func exerciseContinuation(t *testing.T, f paginationFixture, expected protocol.Envelope) protocol.Envelope {
	t.Helper()
	raw, err := protocol.DecodeRequest(f.Request)
	if err != nil {
		t.Fatal(err)
	}
	request, err := contract.PRList.Decode(raw)
	if err != nil {
		t.Fatal(err)
	}
	a, ok := request.Args.(contract.PRListArgs)
	if !ok {
		t.Fatal("wrong args")
	}
	a.Cursor = ""
	normalized, err := json.Marshal(a)
	if err != nil {
		t.Fatal(err)
	}
	binding := access.CursorBinding("fixture-policy", request.Operation, request.Target, normalized)
	codec, err := cursor.New()
	if err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	continuations, err := access.NewContinuations(codec, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	state := access.CursorState{Binding: binding}
	switch f.Name {
	case "last", "cap", "terminal", "expired", "mismatch":
		state.Pages = 1
		state.Items = 1
		state.ExpiresAt = now.Add(limits.CursorLifetime).UnixNano()
	}
	if f.Name == "cap" {
		state.Pages = 9
		state.Items = 9
	}
	if f.Name == "terminal" {
		state.Pages = 10
		state.Terminal = true
	}
	if f.Name == "mismatch" {
		issuedArgs := a
		issuedArgs.Limit = 1
		issued, err := json.Marshal(issuedArgs)
		if err != nil {
			t.Fatal(err)
		}
		state.Binding = access.CursorBinding("fixture-policy", request.Operation, request.Target, issued)
	}
	if f.Name == "expired" {
		state.ExpiresAt = now.UnixNano()
	}
	var outcome error
	if state.Pages > 0 {
		token, err := codec.Seal(state)
		if err != nil {
			t.Fatal(err)
		}
		state, outcome = continuations.Resume(binding, token)
	}
	actual := protocol.Envelope{Version: "v1", RequestID: expected.RequestID}
	if outcome == nil {
		payload, err := json.Marshal(expected.Data)
		if err != nil {
			t.Fatal(err)
		}
		var page protocol.Page[contract.PRSummary]
		if err := json.Unmarshal(payload, &page); err != nil {
			t.Fatal(err)
		}
		position := []byte("validated-provider-page")
		if f.Name == "oversized" {
			position = make([]byte, limits.CursorBytes+1)
		}
		token, err := continuations.Next(state, access.PageUsage{Items: len(page.Items)}, position, page.NextCursor != nil)
		outcome = err
		if outcome == nil {
			if (token == nil) != (page.NextCursor == nil) {
				t.Fatal("wrong exhaustion")
			}
			if token != nil {
				_, err := continuations.Resume(binding, *token)
				terminal := f.Name == "cap" || f.Name == "oversized"
				if terminal && access.FailureKind(err) != access.LimitExceeded {
					t.Fatal("not terminal", err)
				}
				if !terminal && err != nil {
					t.Fatal(err)
				}
				// Replace fresh encrypted bytes with the documented opaque placeholder.
			}
			actual.Data = page
		}
	}
	code := protocol.Success
	if outcome != nil {
		actual.Error = protocol.ErrorPayload(outcome)
		code = actual.Error.Code
	}
	if protocol.HTTPStatus(code) != *f.HTTPStatus {
		t.Fatalf("HTTP status for %s: %s", f.Name, code)
	}
	return actual
}

// Keep the human-readable examples and executable fixture shapes synchronized.
func checkDocumentedFixtures(t *testing.T, fixtures []paginationFixture) {
	t.Helper()
	data, err := os.ReadFile("../../docs/examples/pagination.md")
	if err != nil {
		t.Fatal(err)
	}
	var expected []json.RawMessage
	for _, f := range fixtures {
		if string(f.Request) != "null" {
			expected = append(expected, f.Request)
		}
		expected = append(expected, f.Response)
	}
	chunks := strings.Split(string(data), "```json\n")[1:]
	if len(chunks) != len(expected) {
		t.Fatal("document/fixture block count differs")
	}
	for i, chunk := range chunks {
		body, _, ok := strings.Cut(chunk, "\n```")
		if !ok {
			t.Fatal("unclosed JSON block")
		}
		var got, want any
		if err := json.Unmarshal([]byte(body), &got); err != nil {
			t.Fatal(err)
		}
		if err := json.Unmarshal(expected[i], &want); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("document/fixture mismatch at block %d", i)
		}
	}
}
