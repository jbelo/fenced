package conformance_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	gh "agent-gateway/internal/providers/github"
	ghcontract "agent-gateway/internal/providers/github/contract"
	sc "agent-gateway/internal/providers/shortcut"
	sccontract "agent-gateway/internal/providers/shortcut/contract"
	"context"
	"testing"
)

// R1: the actual six operation contracts reject invalid typed values before execution,
// independently of wire decoding and CLI validation.
func TestTypedOperationValidation(t *testing.T) {
	bindings := append(gh.Operations(gh.FixtureReader()), sc.Operations(sc.FixtureReader())...)
	args := map[string]any{
		"github.pr.list":        ghcontract.PRListArgs{State: "open", Limit: 51},
		"github.pr.view":        ghcontract.PRViewArgs{Number: 0},
		"github.pr.diff":        ghcontract.PRDiffArgs{Number: 0},
		"github.pr.checks":      ghcontract.PRChecksArgs{Number: 1, Limit: 0},
		"github.pr.feedback":    ghcontract.PRFeedbackArgs{Number: 1, Limit: 0},
		"shortcut.story.get":    sccontract.StoryGetArgs{ID: 0},
		"shortcut.story.search": sccontract.StorySearchArgs{Text: "is:archived", Limit: 20},
	}
	for _, binding := range bindings {
		t.Run(binding.Name, func(t *testing.T) {
			target := operation.Target{Provider: "github", Kind: "repository", Key: "company/project"}
			if binding.Name == "shortcut.story.get" || binding.Name == "shortcut.story.search" {
				target = operation.Target{Provider: "shortcut", Kind: "workspace", Key: "engineering"}
			}
			calls := 0
			binding.Execute = func(context.Context, *access.Budget, operation.ValidatedRequest) (operation.Result, error) {
				calls++
				return operation.Result{}, nil
			}
			reader, err := access.New([]access.ResourceScope{target}, []access.Operation{binding.Core()})
			if err != nil {
				t.Fatal(err)
			}
			permit, err := reader.Admit(context.Background())
			if err != nil {
				t.Fatal(err)
			}
			defer permit.Release()
			_, _, err = reader.Read(permit, access.Request{Operation: binding.Name, Target: target, Args: args[binding.Name]}, func(any) error { return nil })
			if access.FailureKind(err) != access.InvalidInput || calls != 0 {
				t.Fatalf("calls=%d err=%v", calls, err)
			}
		})
	}
}
