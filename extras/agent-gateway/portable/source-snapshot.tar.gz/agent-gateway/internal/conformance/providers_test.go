package conformance_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/provider"
	"agent-gateway/internal/providers/github"
	"agent-gateway/internal/providers/shortcut"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

type providerTransport func(*http.Request) (*http.Response, error)

func (f providerTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestProviderCredentialAndDenialConformance(t *testing.T) {
	for _, tc := range []struct {
		p                                     provider.Provider
		config, policy, request, header, host string
	}{
		{github.New(), `{"enabled":true,"token_file":"/run/secrets/github_token"}`, `[{"repo":"company/project"}]`, `{"operation":"github.pr.view","target":{"repo":"company/project"},"args":{"number":1}}`, "Authorization", "api.github.com"},
		{github.New(), `{"enabled":true,"token_file":"/run/secrets/github_token"}`, `[{"repo":"company/project"}]`, `{"operation":"github.pr.feedback","target":{"repo":"company/project"},"args":{"number":1}}`, "Authorization", "api.github.com"},
		{shortcut.New(), `{"enabled":true,"workspaces":[{"alias":"engineering","workspace_id":"11111111-1111-1111-1111-111111111111","token_file":"/run/secrets/shortcut_engineering"}]}`, `[{"workspace":"engineering"}]`, `{"operation":"shortcut.story.get","target":{"workspace":"engineering"},"args":{"id":1}}`, "Shortcut-Token", "api.app.shortcut.com"},
	} {
		t.Run(tc.p.Name(), func(t *testing.T) {
			reads, calls := 0, 0
			codec, err := cursor.New()
			if err != nil {
				t.Fatal(err)
			}
			pages, err := access.NewContinuations(codec, time.Now)
			if err != nil {
				t.Fatal(err)
			}
			registry, err := provider.New([]provider.Provider{tc.p})
			if err != nil {
				t.Fatal(err)
			}
			configured, err := registry.Configure(map[string]json.RawMessage{tc.p.Name(): json.RawMessage(tc.config)}, func(provider.Provider) (provider.Runtime, error) {
				return provider.Runtime{
					Continuations: pages,
					ReadSecret:    func(string) ([]byte, error) { reads++; return []byte("synthetic-private-value"), nil },
					Transport: providerTransport(func(r *http.Request) (*http.Response, error) {
						calls++
						if r.Method != "GET" || r.URL.Host != tc.host || !strings.Contains(r.Header.Get(tc.header), "synthetic-private-value") {
							t.Fatal("incorrect credential or read boundary")
						}
						return &http.Response{StatusCode: 401, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("synthetic-private-value")), Request: r}, nil
					}),
				}, nil
			})
			if err != nil {
				t.Fatal(err)
			}
			policy, err := configured.Targets(map[string]json.RawMessage{tc.p.Name(): json.RawMessage(tc.policy)})
			if err != nil {
				t.Fatal(err)
			}
			for _, allowed := range []bool{false, true, true} {
				selected := policy
				if !allowed {
					selected = nil
				}
				pipeline, err := httpapi.NewPipeline(selected, configured.Operations())
				if err != nil {
					t.Fatal(err)
				}
				env, audit := pipeline.Do(context.Background(), []byte(tc.request))
				want := protocol.PolicyDenied
				if allowed {
					want = protocol.UpstreamAuthentication
				}
				if env.Error == nil || env.Error.Code != want {
					t.Fatalf("unexpected response: %+v", env)
				}
				data, err := json.Marshal(struct {
					Envelope protocol.Envelope
					Audit    httpapi.Audit
				}{env, audit})
				if err != nil {
					t.Fatal(err)
				}
				if strings.Contains(string(data), "synthetic-private-value") {
					t.Fatal("credential disclosed")
				}
				if !allowed && calls != 0 {
					t.Fatal("denied request fetched provider")
				}
				if allowed && (audit.UpstreamStatus == nil || *audit.UpstreamStatus != 401) {
					t.Fatal("missing sanitized status")
				}
			}
			if reads != 1 || calls != 2 {
				t.Fatalf("reads=%d calls=%d", reads, calls)
			}
		})
	}
}
