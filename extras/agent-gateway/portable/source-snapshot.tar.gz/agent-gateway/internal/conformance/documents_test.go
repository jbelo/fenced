// Package conformance exercises an independent domain without production registration.
package conformance

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cli"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

type documentArgs struct {
	Slug  string `json:"slug"`
	Lines int    `json:"lines"`
}
type document struct {
	Slug string `json:"slug"`
	Text string `json:"text"`
}
type collectionTarget struct {
	Collection string `json:"collection"`
}

var collectionPattern = regexp.MustCompile(`^[a-z0-9-]+$`)

func target(key string) (operation.Target, error) {
	key = strings.ToLower(key)
	if !collectionPattern.MatchString(key) {
		return operation.Target{}, &protocol.RequestError{Code: protocol.InvalidInput}
	}
	return operation.Target{Provider: "documents", Kind: "collection", Key: key}, nil
}

var readDocument = operation.Definition[documentArgs]{
	Name: "documents.collection.read", ScopeKind: "collection",
	NormalizeTarget: func(t operation.Target) (operation.Target, error) {
		if t.Provider != "documents" || t.Kind != "collection" {
			return t, protocol.Fail(protocol.InvalidInput)
		}
		return target(t.Key)
	},
	NormalizeArgs: func(a documentArgs) (documentArgs, error) {
		if a.Slug == "" || a.Lines < 1 || a.Lines > 3 {
			return a, protocol.Fail(protocol.InvalidInput)
		}
		return a, nil
	},
	Target: func(raw json.RawMessage) (operation.Target, error) {
		var t collectionTarget
		if protocol.DecodeStrict(raw, &t) != nil {
			return operation.Target{}, &protocol.RequestError{Code: protocol.InvalidInput}
		}
		return target(t.Collection)
	},
	Arguments: func(raw json.RawMessage) (documentArgs, error) {
		a := documentArgs{Lines: 1}
		if protocol.DecodeStrict(raw, &a) != nil || a.Slug == "" || a.Lines < 1 || a.Lines > 3 {
			return a, &protocol.RequestError{Code: protocol.InvalidInput}
		}
		return a, nil
	},
	Audit: func(t operation.Target) any { return collectionTarget{Collection: t.Key} },
}

// Configuration is owned by the synthetic integration, not by the httpapi.
type documentConfig struct {
	Collections []string `json:"collections"`
	Text        string   `json:"text"`
}

func (c documentConfig) policy() (httpapi.Policy, error) {
	if c.Collections == nil || c.Text == "" {
		return nil, errors.New("incomplete document config")
	}
	p := httpapi.Policy{}
	seen := map[operation.Target]bool{}
	for _, key := range c.Collections {
		t, err := target(key)
		if err != nil || seen[t] {
			return nil, errors.New("invalid or duplicate collection")
		}
		seen[t] = true
		p = append(p, t)
	}
	return p, nil
}

func (c documentConfig) operation(calls *int, wrongResult bool, upstreamError bool) operation.Binding {
	return operation.Bind(readDocument, operation.Handler[documentArgs, []document]{Execute: func(_ context.Context, _ *access.Budget, _ operation.Target, a documentArgs) ([]document, error) {
		*calls++
		if upstreamError {
			return nil, errors.New("SYNTHETIC_CREDENTIAL")
		}
		slug := a.Slug
		if wrongResult {
			slug = "different"
		}
		return []document{{Slug: slug, Text: c.Text}}, nil
	}, Validate: func(_ operation.Target, a documentArgs, results []document) error {
		for _, d := range results {
			if d.Slug != a.Slug {
				return &protocol.RequestError{Code: protocol.PolicyDenied}
			}
		}
		return nil
	}, Measure: func(a documentArgs, results []document) operation.Bounds {
		return operation.Bounds{Items: len(results), ItemLimit: a.Lines}
	}},
	)
}

func documentCommand() cli.Command {
	return cli.BindCommand([]string{"documents", "collection", "read"}, readDocument,
		cli.Flag{Name: "collection", Target: true}, cli.Flag{Name: "slug"}, cli.Flag{Name: "lines", Kind: cli.IntegerFlag})
}

type localTransport struct{ s *httpapi.Server }

func (t localTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	w := httptest.NewRecorder()
	t.s.ServeHTTP(w, r)
	return w.Result(), nil
}

func TestIndependentProviderFromConfigThroughCLI(t *testing.T) {
	var c documentConfig
	if err := protocol.DecodeStrict([]byte(`{"collections":["Guides"],"text":"fixture document"}`), &c); err != nil {
		t.Fatal(err)
	}
	policy, err := c.policy()
	if err != nil {
		t.Fatal(err)
	}
	calls := 0
	var audit bytes.Buffer
	s, err := httpapi.NewServer(policy, []operation.Binding{c.operation(&calls, false, false)}, &audit)
	if err != nil {
		t.Fatal(err)
	}
	runner, err := cli.New([]cli.Command{documentCommand()})
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "cli.json")
	if err := os.WriteFile(path, []byte(`{"gateway_url":"http://agent-gateway:8080"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	code := runner.RunWithClient([]string{"documents", "collection", "read", "--collection", "GUIDES", "--slug", "start"}, path, &out, &http.Client{Transport: localTransport{s}})
	if code != 0 || calls != 1 || !strings.Contains(out.String(), "fixture document") {
		t.Fatalf("exit=%d calls=%d output=%s", code, calls, &out)
	}
	if !strings.Contains(audit.String(), `"target":{"collection":"guides"}`) || strings.Contains(audit.String(), "fixture document") {
		t.Fatalf("audit: %s", &audit)
	}
}

func TestTargetNamespacesAndMandatoryValidation(t *testing.T) {
	c := documentConfig{Collections: []string{"guides"}, Text: "fixture document"}
	good := operation.Target{Provider: "documents", Kind: "collection", Key: "guides"}
	for _, tc := range []struct {
		name            string
		allowed         operation.Target
		wrong, upstream bool
		status, calls   int
	}{
		{"allowed", good, false, false, 200, 1},
		{"provider isolation", operation.Target{Provider: "another", Kind: "collection", Key: "guides"}, false, false, 403, 0},
		{"kind isolation", operation.Target{Provider: "documents", Kind: "repository", Key: "guides"}, false, false, 403, 0},
		{"key isolation", operation.Target{Provider: "documents", Kind: "collection", Key: "other"}, false, false, 403, 0},
		{"invalid result", good, true, false, 403, 1},
		{"safe upstream error", good, false, true, 500, 1},
	} {
		t.Run(tc.name, func(t *testing.T) {
			calls := 0
			var audit bytes.Buffer
			s, err := httpapi.NewServer(httpapi.Policy{tc.allowed}, []operation.Binding{c.operation(&calls, tc.wrong, tc.upstream)}, &audit)
			if err != nil {
				t.Fatal(err)
			}
			req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"documents.collection.read","target":{"collection":"guides"},"args":{"slug":"start"}}`))
			req.Header.Set("Content-Type", "application/json")
			w := httptest.NewRecorder()
			s.ServeHTTP(w, req)
			if w.Code != tc.status || calls != tc.calls {
				t.Fatalf("status=%d calls=%d output=%s", w.Code, calls, w.Body)
			}
			if tc.status != 200 && strings.Contains(w.Body.String(), "fixture document") {
				t.Fatal("invalid result published")
			}
			if strings.Contains(w.Body.String()+audit.String(), "SYNTHETIC_CREDENTIAL") {
				t.Fatal("internal error disclosed")
			}
		})
	}
}

func TestSyntheticConfigurationAndCommandsFailClosed(t *testing.T) {
	for _, raw := range []string{
		`{"collections":["guides"],"text":"ok","unknown":true}`,
		`{"collections":["Guides","guides"],"text":"ok"}`,
		`{"collections":["bad/key"],"text":"ok"}`,
	} {
		var c documentConfig
		err := protocol.DecodeStrict([]byte(raw), &c)
		if err == nil {
			_, err = c.policy()
		}
		if err == nil {
			t.Fatalf("accepted %s", raw)
		}
	}
	command := documentCommand()
	if _, err := cli.New([]cli.Command{command, command}); err == nil {
		t.Fatal("duplicate command accepted")
	}
	runner, err := cli.New([]cli.Command{command})
	if err != nil {
		t.Fatal(err)
	}
	// No config/client is needed: the provider-owned schema must reject these first.
	for _, args := range [][]string{
		{"documents", "collection", "read", "--collection", "guides", "--slug", "start", "--lines", "0"},
		{"documents", "collection", "read", "--collection", "guides", "--slug", "start", "--repo", "other"},
	} {
		if code := runner.RunWithClient(args, "", io.Discard, nil); code != 2 {
			t.Fatalf("exit=%d args=%v", code, args)
		}
	}
}

func TestIndependentProviderLimits(t *testing.T) {
	c := documentConfig{Collections: []string{"guides"}, Text: "fixture"}
	p, err := c.policy()
	if err != nil {
		t.Fatal(err)
	}
	op := operation.Bind(readDocument, operation.Handler[documentArgs, []document]{Execute: func(context.Context, *access.Budget, operation.Target, documentArgs) ([]document, error) {
		return []document{{Slug: "start"}, {Slug: "start"}}, nil
	}, Validate: func(operation.Target, documentArgs, []document) error { return nil }, Measure: func(a documentArgs, d []document) operation.Bounds {
		return operation.Bounds{Items: len(d), ItemLimit: a.Lines}
	}},
	)
	s, err := httpapi.NewServer(p, []operation.Binding{op}, nil)
	if err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"documents.collection.read","target":{"collection":"guides"},"args":{"slug":"start","lines":1}}`))
	r.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	s.ServeHTTP(w, r)
	if w.Code != 413 || strings.Contains(w.Body.String(), `"data"`) {
		t.Fatalf("oversized result published: %d %s", w.Code, w.Body)
	}
}
