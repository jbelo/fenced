package operation

import "agent-gateway/internal/access"

// Target is the wire-contract name for a canonical resource scope.
type Target = access.ResourceScope
