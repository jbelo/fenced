package operation

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/protocol"
	"encoding/json"
)

// ValidatedRequest holds normalized arguments, canonical identity and safe audit metadata.
type ValidatedRequest = access.Request

// Definition describes a typed, pure operation schema, shared with the CLI.
type Definition[A any] struct {
	Name            string
	ScopeKind       string
	NormalizeTarget func(Target) (Target, error)
	NormalizeArgs   func(A) (A, error)
	Target          func(json.RawMessage) (Target, error)
	Arguments       func(json.RawMessage) (A, error)
	Audit           func(Target) any
}

// Decode normalizes a request using this operation's target and argument schemas.
func (d Definition[A]) Decode(r protocol.Request) (ValidatedRequest, error) {
	out := ValidatedRequest{Operation: d.Name}
	if d.Target == nil || d.Arguments == nil || d.Audit == nil {
		return out, &protocol.RequestError{Code: protocol.InternalError}
	}
	var err error
	out.Target, err = d.Target(r.Target)
	if err != nil {
		return out, err
	}
	if !out.Target.Valid() {
		return out, &protocol.RequestError{Code: protocol.InvalidInput}
	}
	out.AuditTarget = d.Audit(out.Target)
	out.Args, err = d.Arguments(r.Args)
	if err != nil {
		return out, err
	}
	return d.Normalize(out)
}

// ParseRequest validates with an explicitly assembled operation catalogue.
func ParseRequest(data []byte, decoders map[string]func(protocol.Request) (ValidatedRequest, error)) (ValidatedRequest, error) {
	r, err := protocol.DecodeRequest(data)
	if err != nil {
		return ValidatedRequest{}, err
	}
	decode, ok := decoders[r.Operation]
	if !ok || decode == nil {
		return ValidatedRequest{}, &protocol.RequestError{Code: protocol.UnsupportedOperation}
	}
	return decode(r)
}

// Normalize validates typed arguments and canonical identity without decoding JSON.
func (d Definition[A]) Normalize(r ValidatedRequest) (ValidatedRequest, error) {
	if d.ScopeKind == "" || d.NormalizeTarget == nil || d.NormalizeArgs == nil || d.Audit == nil {
		return r, access.Fail(access.InternalError)
	}
	a, ok := r.Args.(A)
	if !ok {
		return r, access.Fail(access.InvalidInput)
	}
	target, err := d.NormalizeTarget(r.Target)
	if err != nil {
		return r, protocol.ToFailure(err)
	}
	if target.Kind != d.ScopeKind {
		return r, access.Fail(access.InvalidInput)
	}
	args, err := d.NormalizeArgs(a)
	if err != nil {
		return r, protocol.ToFailure(err)
	}
	return ValidatedRequest{Operation: d.Name, Target: target, Args: args, AuditTarget: d.Audit(target)}, nil
}
