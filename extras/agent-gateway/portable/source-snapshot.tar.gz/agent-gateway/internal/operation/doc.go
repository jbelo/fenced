// Package operation defines canonical targets and typed operation validation contracts.
package operation
