package operation

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/protocol"
	"context"
	"errors"
	"strings"
)

// Bounds reports measured values and the requested per-page bound.
type Bounds = access.Bounds

// Handler names the mandatory execution, validation and measurement stages.
type Handler[A, R any] struct {
	Execute  func(context.Context, *access.Budget, Target, A) (R, error)
	Validate func(Target, A, R) error
	Measure  func(A, R) Bounds
	MaxBytes int
	// View removes internal verification metadata after validation. Nil publishes the result itself.
	View func(R) any
}

// Result contains validated data and measurements for pipeline enforcement.
type Result = access.Result

// Descriptor is a pure operation schema, available even for disabled integrations.
type Descriptor struct {
	Name      string
	ScopeKind string
	Decode    func(protocol.Request) (ValidatedRequest, error)
	Normalize func(ValidatedRequest) (ValidatedRequest, error)
}

// Describe exposes a typed definition through the shared registry boundary.
func (d Definition[A]) Describe() Descriptor {
	return Descriptor{Name: d.Name, ScopeKind: d.ScopeKind, Decode: d.Decode, Normalize: d.Normalize}
}

// Binding combines a pure descriptor with an optional initialized executor.
type Binding struct {
	Descriptor
	Execute func(context.Context, *access.Budget, ValidatedRequest) (Result, error)
}

// Bind keeps type erasure at the registry boundary and requires all handler stages.
func Bind[A, R any](d Definition[A], h Handler[A, R]) Binding {
	b := Binding{Descriptor: d.Describe()}
	if d.ScopeKind == "" || d.NormalizeTarget == nil || d.NormalizeArgs == nil || d.Target == nil || d.Arguments == nil || d.Audit == nil || h.Execute == nil || h.Validate == nil || h.Measure == nil {
		b.Decode = nil
		return b
	}
	b.Execute = func(ctx context.Context, budget *access.Budget, r ValidatedRequest) (Result, error) {
		a, ok := r.Args.(A)
		if !ok {
			return Result{}, protocol.Fail(protocol.InternalError)
		}
		v, err := h.Execute(ctx, budget, r.Target, a)
		if err != nil {
			return Result{}, err
		}
		if err := h.Validate(r.Target, a, v); err != nil {
			return Result{}, err
		}
		var data any = v
		if h.View != nil {
			data = h.View(v)
		}
		return Result{Data: data, Bounds: h.Measure(a, v), MaxBytes: h.MaxBytes}, nil
	}
	return b
}

// Registry snapshots explicit bindings and rejects duplicate or incomplete schemas.
func Registry(bindings []Binding) (map[string]Binding, error) {
	out := map[string]Binding{}
	for _, b := range bindings {
		if b.Name == "" || b.ScopeKind == "" || b.Decode == nil || b.Normalize == nil {
			return nil, errors.New("incomplete operation binding")
		}
		if _, ok := out[b.Name]; ok {
			return nil, errors.New("duplicate operation binding")
		}
		out[b.Name] = b
	}
	return out, nil
}

// Namespaced verifies operation names and decoded target namespaces at registration.
func Namespaced(name string, b Binding) (Binding, error) {
	if name == "" || !strings.HasPrefix(b.Name, name+".") || b.Decode == nil || b.ScopeKind == "" {
		return Binding{}, errors.New("invalid provider operation namespace")
	}
	normalize := b.Normalize
	if normalize == nil {
		return Binding{}, errors.New("missing semantic validator")
	}
	b.Normalize = func(r ValidatedRequest) (ValidatedRequest, error) {
		v, err := normalize(r)
		if err == nil && v.Target.Kind != b.ScopeKind {
			return v, access.Fail(access.InvalidInput)
		}
		if err == nil && v.Target.Provider != name {
			return v, access.Fail(access.PolicyDenied)
		}
		return v, err
	}
	decode := b.Decode
	b.Decode = func(r protocol.Request) (ValidatedRequest, error) {
		v, err := decode(r)
		if err != nil {
			return v, err
		}
		if v.Target.Kind != b.ScopeKind {
			return v, protocol.Fail(protocol.InvalidInput)
		}
		if v.Target.Provider != name {
			return v, protocol.Fail(protocol.PolicyDenied)
		}
		return v, nil
	}
	return b, nil
}

// Core exposes a binding through the transport-independent execution port.
func (b Binding) Core() access.Operation {
	op := access.Operation{Name: b.Name, ScopeKind: b.ScopeKind, Normalize: b.Normalize}
	if b.Execute != nil {
		op.Execute = func(ctx context.Context, budget *access.Budget, authorized access.AuthorizedRead) (access.Result, error) {
			request, err := authorized.Request()
			if err != nil {
				return access.Result{}, err
			}
			result, err := b.Execute(ctx, budget, request)
			return result, protocol.ToFailure(err)
		}
	}
	return op
}
