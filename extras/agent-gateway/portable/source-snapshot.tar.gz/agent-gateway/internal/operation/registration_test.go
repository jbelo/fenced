package operation_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"testing"
)

func TestDeclaredKindEnforcedOnDecodingAndNormalization(t *testing.T) {
	wrong := operation.ValidatedRequest{Operation: "example.read", Target: operation.Target{Provider: "example", Kind: "repository", Key: "manuals"}}
	b := operation.Binding{Descriptor: operation.Descriptor{Name: "example.read", ScopeKind: "collection", Decode: func(protocol.Request) (operation.ValidatedRequest, error) { return wrong, nil }, Normalize: func(operation.ValidatedRequest) (operation.ValidatedRequest, error) { return wrong, nil }}}
	missing := b
	missing.ScopeKind = ""
	if _, err := operation.Registry([]operation.Binding{missing}); err == nil {
		t.Fatal("missing kind accepted")
	}
	registered, err := operation.Namespaced("example", b)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = registered.Decode(protocol.Request{}); protocol.ErrorCode(err) != protocol.InvalidInput {
		t.Fatal("wrong decoded kind accepted", err)
	}
	if _, err = registered.Normalize(wrong); access.FailureKind(err) != access.InvalidInput {
		t.Fatal("wrong normalized kind accepted", err)
	}
}
