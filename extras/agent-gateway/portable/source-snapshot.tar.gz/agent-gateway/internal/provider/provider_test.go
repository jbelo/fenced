package provider_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/provider"
	"context"
	"encoding/json"
	"testing"
)

type documents struct {
	configured int
	namespace  string
	enabled    bool
}

func (*documents) Name() string { return "documents" }

func (d *documents) Definitions() []operation.Descriptor {
	return []operation.Descriptor{{Name: "documents.read", ScopeKind: "collection", Normalize: func(r operation.ValidatedRequest) (operation.ValidatedRequest, error) {
		r.Operation = "documents.read"
		return r, nil
	}, Decode: func(protocol.Request) (operation.ValidatedRequest, error) {
		return operation.ValidatedRequest{Operation: "documents.read", Target: operation.Target{Provider: d.namespace, Kind: "collection", Key: "manuals"}}, nil
	}}}
}

func (d *documents) Configure(raw json.RawMessage, _ provider.Runtime) (provider.Instance, error) {
	d.configured++
	var config struct {
		Enabled bool `json:"enabled"`
	}
	if err := protocol.DecodeStrict(raw, &config); err != nil {
		return nil, err
	}
	d.enabled = config.Enabled
	return d, nil
}

func (d *documents) Targets(raw json.RawMessage) ([]operation.Target, error) {
	var names []string
	if err := protocol.DecodeStrict(raw, &names); err != nil {
		return nil, err
	}
	out := []operation.Target{}
	for _, name := range names {
		out = append(out, operation.Target{Provider: d.namespace, Kind: "collection", Key: name})
	}
	return out, nil
}

func (d *documents) Operations() []operation.Binding {
	if !d.enabled {
		return nil
	}
	return []operation.Binding{{Descriptor: d.Definitions()[0], Execute: func(context.Context, *access.Budget, operation.ValidatedRequest) (operation.Result, error) {
		return operation.Result{Data: "document"}, nil
	}}}
}

func TestProviderLifecycle(t *testing.T) {
	for _, enabled := range []bool{true, false} {
		d := &documents{namespace: "documents"}
		registry, err := provider.New([]provider.Provider{d})
		if err != nil {
			t.Fatal(err)
		}
		raw := json.RawMessage(`{"enabled":false}`)
		if enabled {
			raw = json.RawMessage(`{"enabled":true}`)
		}
		configured, err := registry.Configure(map[string]json.RawMessage{"documents": raw}, func(provider.Provider) (provider.Runtime, error) { return provider.Runtime{}, nil })
		if err != nil {
			t.Fatal(err)
		}
		targets, err := configured.Targets(map[string]json.RawMessage{"documents": json.RawMessage(`["manuals"]`)})
		if err != nil {
			t.Fatal(err)
		}
		pipeline, err := httpapi.NewPipeline(targets, configured.Operations())
		if err != nil {
			t.Fatal(err)
		}
		env, _ := pipeline.Do(context.Background(), []byte(`{"operation":"documents.read","target":{},"args":{}}`))
		if d.configured != 1 {
			t.Fatal("configuration repeated")
		}
		if enabled && env.Error != nil {
			t.Fatal(env.Error)
		}
		if !enabled && (env.Error == nil || env.Error.Code != protocol.PolicyDenied) {
			t.Fatal("disabled provider executed")
		}
	}
}

func TestNamespaceAndSectionRejection(t *testing.T) {
	d := &documents{namespace: "other"}
	registry, err := provider.New([]provider.Provider{d})
	if err != nil {
		t.Fatal(err)
	}
	runtime := func(provider.Provider) (provider.Runtime, error) { return provider.Runtime{}, nil }
	for _, sections := range []map[string]json.RawMessage{{}, {"unknown": json.RawMessage(`{}`)}, {"documents": json.RawMessage(`{"unknown":true}`)}} {
		if _, err = registry.Configure(sections, runtime); err == nil {
			t.Fatal("accepted bad configuration")
		}
	}
	configured, err := registry.Configure(map[string]json.RawMessage{"documents": json.RawMessage(`{"enabled":true}`)}, runtime)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = configured.Targets(map[string]json.RawMessage{"documents": json.RawMessage(`["manuals"]`)}); err == nil {
		t.Fatal("accepted foreign target")
	}
	if _, err = configured.Operations()[0].Decode(protocol.Request{}); protocol.ErrorCode(err) != protocol.PolicyDenied {
		t.Fatal("accepted foreign request target")
	}
	if _, err = provider.New([]provider.Provider{d, d}); err == nil {
		t.Fatal("accepted duplicate provider")
	}
}

type (
	changedKind     struct{ *documents }
	changedInstance struct{ provider.Instance }
)

func (c changedKind) Configure(raw json.RawMessage, rt provider.Runtime) (provider.Instance, error) {
	i, err := c.documents.Configure(raw, rt)
	return changedInstance{i}, err
}

func (c changedInstance) Operations() []operation.Binding {
	bindings := c.Instance.Operations()
	for i := range bindings {
		bindings[i].ScopeKind = "repository"
	}
	return bindings
}

func TestConfiguredBindingCannotChangeDeclaredKind(t *testing.T) {
	p := changedKind{&documents{namespace: "documents"}}
	registry, err := provider.New([]provider.Provider{p})
	if err != nil {
		t.Fatal(err)
	}
	_, err = registry.Configure(map[string]json.RawMessage{"documents": json.RawMessage(`{"enabled":true}`)}, func(provider.Provider) (provider.Runtime, error) { return provider.Runtime{}, nil })
	if err == nil {
		t.Fatal("configured binding changed declared kind")
	}
}
