// Package provider defines static provider registration and staged initialization.
package provider

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"encoding/json"
	"errors"
	"net/http"
)

// Runtime supplies transport and secret access selected by executable assembly.
// A nil ReadSecret means no credential files may be read (mock operation).
type Runtime struct {
	Continuations *access.Continuations
	Transport     http.RoundTripper
	ReadSecret    func(string) ([]byte, error)
}

// Provider declares its pure schemas and configures one runtime instance.
type Provider interface {
	Name() string
	Definitions() []operation.Descriptor
	Configure(json.RawMessage, Runtime) (Instance, error)
}

// Instance owns validated configuration, credentials and initialized operations.
type Instance interface {
	Targets(json.RawMessage) ([]operation.Target, error)
	Operations() []operation.Binding
}

// Registry validates namespaces and supplies generic configuration dispatch.
type Registry struct{ providers []Provider }

// New validates a fixed provider list; registration has no global side effects.
func New(providers []Provider) (*Registry, error) {
	seen := map[string]bool{}
	for _, p := range providers {
		if p == nil || p.Name() == "" || seen[p.Name()] {
			return nil, errors.New("invalid or duplicate provider")
		}
		seen[p.Name()] = true
		definitions := []operation.Binding{}
		for _, d := range p.Definitions() {
			b, err := operation.Namespaced(p.Name(), operation.Binding{Descriptor: d})
			if err != nil {
				return nil, err
			}
			definitions = append(definitions, b)
		}
		if _, err := operation.Registry(definitions); err != nil {
			return nil, err
		}
	}
	return &Registry{providers: append([]Provider(nil), providers...)}, nil
}

// Configured retains the validated instances and their pure schema registrations.
type Configured struct {
	instances map[string]Instance
	bindings  []operation.Binding
	kinds     map[string]map[string]bool
}

// Configure rejects unknown/missing sections and initializes each provider once.
func (r *Registry) Configure(sections map[string]json.RawMessage, runtime func(Provider) (Runtime, error)) (*Configured, error) {
	if len(sections) != len(r.providers) {
		return nil, errors.New("unknown or missing provider section")
	}
	out := &Configured{instances: map[string]Instance{}, kinds: map[string]map[string]bool{}}
	for _, p := range r.providers {
		raw, ok := sections[p.Name()]
		if !ok {
			return nil, errors.New("missing provider section")
		}
		rt, err := runtime(p)
		if err != nil {
			return nil, err
		}
		instance, err := p.Configure(raw, rt)
		if err != nil {
			return nil, err
		}
		if instance == nil {
			return nil, errors.New("missing provider instance")
		}
		out.instances[p.Name()] = instance
		out.kinds[p.Name()] = map[string]bool{}
		actual, err := operation.Registry(instance.Operations())
		if err != nil {
			return nil, err
		}
		for _, d := range p.Definitions() {
			out.kinds[p.Name()][d.ScopeKind] = true
			binding, ok := actual[d.Name]
			if ok && binding.ScopeKind != d.ScopeKind {
				return nil, errors.New("configured operation scope kind differs from definition")
			}
			if !ok {
				binding = operation.Binding{Descriptor: d}
			}
			delete(actual, d.Name)
			binding, err = operation.Namespaced(p.Name(), binding)
			if err != nil {
				return nil, err
			}
			out.bindings = append(out.bindings, binding)
		}
		if len(actual) != 0 {
			return nil, errors.New("operation missing from provider definitions")
		}
	}
	return out, nil
}

// Targets resolves every policy section and verifies full provider namespaces.
func (c *Configured) Targets(sections map[string]json.RawMessage) ([]operation.Target, error) {
	if len(sections) != len(c.instances) {
		return nil, errors.New("unknown or missing policy section")
	}
	out := []operation.Target{}
	seen := map[operation.Target]bool{}
	for name, instance := range c.instances {
		raw, ok := sections[name]
		if !ok {
			return nil, errors.New("missing policy section")
		}
		targets, err := instance.Targets(raw)
		if err != nil {
			return nil, err
		}
		for _, t := range targets {
			if !t.Valid() || t.Provider != name || !c.kinds[name][t.Kind] || seen[t] {
				return nil, errors.New("invalid target namespace or duplicate target")
			}
			seen[t] = true
			out = append(out, t)
		}
	}
	return out, nil
}

// Operations returns a copy of the initialized and disabled operation bindings.
func (c *Configured) Operations() []operation.Binding {
	return append([]operation.Binding(nil), c.bindings...)
}
