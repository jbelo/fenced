package cli

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"errors"
	"flag"
	"io"
	"strings"
)

// FlagKind identifies the primitive value type accepted by a CLI flag.
type FlagKind int

// Supported flag value types.
const (
	StringFlag FlagKind = iota
	IntegerFlag
	BoolFlag
)

// Flag declares an argument or target field exposed by a command.
type Flag struct {
	Name   string
	Kind   FlagKind
	Target bool
}

// Command binds a CLI path and flags to a pure operation decoder.
type Command struct {
	Path      []string
	Operation string
	Flags     []Flag
	Decode    func(protocol.Request) (operation.ValidatedRequest, error)
}

// BindCommand constructs a command from a typed operation definition.
func BindCommand[A any](path []string, d operation.Definition[A], flags ...Flag) Command {
	c := Command{Path: path, Operation: d.Name, Flags: flags}
	if d.Target != nil && d.Arguments != nil && d.Audit != nil {
		c.Decode = d.Decode
	}
	return c
}

// Runner executes requests from an immutable command registry.
type Runner struct{ commands []Command }

// New validates command bindings and snapshots the registry.
func New(commands []Command) (*Runner, error) {
	out := &Runner{}
	for _, c := range commands {
		if len(c.Path) == 0 || c.Operation == "" || c.Decode == nil {
			return nil, errors.New("incomplete command")
		}
		for _, part := range c.Path {
			if part == "" || strings.ContainsAny(part, " \t\n") {
				return nil, errors.New("invalid command path")
			}
		}
		path := strings.Join(c.Path, " ")
		for _, existing := range out.commands {
			other := strings.Join(existing.Path, " ")
			if path == other || strings.HasPrefix(path, other+" ") || strings.HasPrefix(other, path+" ") {
				return nil, errors.New("duplicate or ambiguous command")
			}
		}
		seen := map[string]bool{"json": true}
		for _, f := range c.Flags {
			if f.Name == "" || seen[f.Name] || f.Kind < StringFlag || f.Kind > BoolFlag {
				return nil, errors.New("invalid command flags")
			}
			seen[f.Name] = true
		}
		c.Path = append([]string(nil), c.Path...)
		c.Flags = append([]Flag(nil), c.Flags...)
		out.commands = append(out.commands, c)
	}
	return out, nil
}

// buildRequest parses CLI arguments into a validated JSON request body without
// sending it. Only explicitly supplied flags are serialized; the gateway applies defaults.
func (r *Runner) buildRequest(args []string) ([]byte, error) {
	command, err := r.selectCommand(args)
	if err != nil {
		return nil, err
	}
	values, err := command.parseFlags(args[len(command.Path):])
	if err != nil {
		return nil, err
	}
	payload := command.buildPayload(values)
	data, err := json.Marshal(payload)
	if err != nil {
		return nil, &protocol.RequestError{Code: protocol.InvalidInput}
	}
	if err := command.validateRequest(data); err != nil {
		return nil, err
	}
	return data, nil
}

// selectCommand distinguishes incomplete input from an unsupported command path.
func (r *Runner) selectCommand(args []string) (*Command, error) {
	var selected *Command
	shortest := 0
	for _, c := range r.commands {
		if shortest == 0 || len(c.Path) < shortest {
			shortest = len(c.Path)
		}
	}
	if len(args) < shortest {
		return nil, &protocol.RequestError{Code: protocol.InvalidInput}
	}
	partial := len(args) == 0
	for i := range r.commands {
		c := &r.commands[i]
		n := len(c.Path)
		if len(args) < n {
			n = len(args)
		}
		if strings.Join(args[:n], " ") != strings.Join(c.Path[:n], " ") {
			continue
		}
		if len(args) < len(c.Path) {
			partial = true
			continue
		}
		selected = c
		break
	}
	if selected == nil {
		code := protocol.UnsupportedOperation
		if partial {
			code = protocol.InvalidInput
		}
		return nil, &protocol.RequestError{Code: code}
	}
	return selected, nil
}

// parseFlags returns only explicitly supplied operation and target flags.
func (c *Command) parseFlags(args []string) (map[string]any, error) {
	fs := flag.NewFlagSet("agentctl", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	pointers := map[string]any{}
	for _, f := range c.Flags {
		switch f.Kind {
		case StringFlag:
			pointers[f.Name] = fs.String(f.Name, "", "")
		case IntegerFlag:
			pointers[f.Name] = fs.Int64(f.Name, 0, "")
		case BoolFlag:
			pointers[f.Name] = fs.Bool(f.Name, false, "")
		}
	}
	fs.Bool("json", true, "")
	if fs.Parse(args) != nil || fs.NArg() != 0 {
		return nil, &protocol.RequestError{Code: protocol.InvalidInput}
	}
	values := map[string]any{}
	fs.Visit(func(f *flag.Flag) {
		if f.Name == "json" {
			return
		}
		switch p := pointers[f.Name].(type) {
		case *string:
			values[f.Name] = *p
		case *int64:
			values[f.Name] = *p
		case *bool:
			values[f.Name] = *p
		}
	})
	return values, nil
}

type requestPayload struct {
	Operation string         `json:"operation"`
	Target    map[string]any `json:"target"`
	Args      map[string]any `json:"args"`
}

// buildPayload separates supplied values according to the command's flag definitions.
func (c *Command) buildPayload(values map[string]any) requestPayload {
	payload := requestPayload{Operation: c.Operation, Target: map[string]any{}, Args: map[string]any{}}
	for _, f := range c.Flags {
		value, present := values[f.Name]
		if !present {
			continue
		}
		if f.Target {
			payload.Target[f.Name] = value
		} else {
			payload.Args[f.Name] = value
		}
	}
	return payload
}

// validateRequest checks the wire limits and operation schema without changing the payload.
func (c *Command) validateRequest(data []byte) error {
	request, err := protocol.DecodeRequest(data)
	if err != nil {
		return err
	}
	_, err = c.Decode(request)
	return err
}
