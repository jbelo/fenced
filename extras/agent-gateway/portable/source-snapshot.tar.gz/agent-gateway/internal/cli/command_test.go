package cli

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"testing"
)

func TestCommandParsing(t *testing.T) {
	command := Command{Path: []string{"example", "read"}, Operation: "example.read", Flags: []Flag{{Name: "number", Kind: IntegerFlag}}, Decode: func(r protocol.Request) (operation.ValidatedRequest, error) {
		var args struct {
			Number int `json:"number"`
		}
		if err := protocol.DecodeStrict(r.Args, &args); err != nil || args.Number < 1 {
			return operation.ValidatedRequest{}, protocol.Fail(protocol.InvalidInput)
		}
		return operation.ValidatedRequest{}, nil
	}}
	runner, err := New([]Command{command})
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		args  []string
		valid bool
	}{{[]string{"example", "read", "--number", "1", "--json"}, true}, {[]string{"example"}, false}, {[]string{"example", "read", "--number", "bad"}, false}, {[]string{"example", "read", "--unknown", "1"}, false}, {[]string{"example", "read"}, false}} {
		if _, err := runner.buildRequest(tc.args); (err == nil) != tc.valid {
			t.Fatalf("%v: %v", tc.args, err)
		}
	}
	if _, err = New([]Command{command, command}); err == nil {
		t.Fatal("duplicate accepted")
	}
}
