package cli

import (
	"errors"
	"io"
	"os"
)

func readConfig(path string) ([]byte, error) {
	f, err := os.Open(path) // #nosec G304 -- AGENTCTL_CONFIG intentionally selects a local file; no remote request supplies this path.
	if err != nil {
		return nil, err
	}
	// Closing a read-only descriptor cannot change the data or validation result.
	defer func() { _ = f.Close() }()
	info, err := f.Stat()
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() {
		return nil, errors.New("configuration must be a regular file")
	}
	b, err := io.ReadAll(io.LimitReader(f, 16385))
	if err != nil {
		return nil, err
	}
	if len(b) > 16384 {
		return nil, errors.New("configuration too large")
	}
	return b, nil
}
