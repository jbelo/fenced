package cli

import (
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"
)

func localError(out io.Writer, code protocol.Code) int {
	if err := json.NewEncoder(out).Encode(protocol.Envelope{Version: "v1", Error: &protocol.ErrorBody{Code: code, Message: protocol.Message(code)}}); err != nil {
		return protocol.ExitCode(protocol.InternalError)
	}
	return protocol.ExitCode(code)
}

// Run executes one CLI request using the configured httpapi.
func (r *Runner) Run(args []string, configPath string, out io.Writer) int {
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.Proxy = nil
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 20 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	return r.RunWithClient(args, configPath, out, client)
}

// RunWithClient permits embedding and testing without a listening httpapi.
func (r *Runner) RunWithClient(args []string, configPath string, out io.Writer, client *http.Client) int {
	local := func(code protocol.Code) int { return localError(out, code) }
	reqBytes, err := r.buildRequest(args)
	if err != nil {
		return local(protocol.ErrorCode(err))
	}
	path := configPath
	if path == "" {
		return local(protocol.ConfigurationError)
	}
	b, err := readConfig(path)
	if err != nil {
		return local(protocol.ConfigurationError)
	}
	var config struct {
		GatewayURL string `json:"gateway_url"`
	}
	if protocol.DecodeStrict(b, &config) != nil {
		return local(protocol.ConfigurationError)
	}
	u, err := url.Parse(config.GatewayURL)
	if err != nil || u.Scheme != "http" || u.Hostname() == "" || u.Port() != "8080" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return local(protocol.ConfigurationError)
	}
	u.Path = "/v1/read"
	request, err := http.NewRequest("POST", u.String(), bytes.NewReader(reqBytes))
	if err != nil {
		return local(protocol.ConfigurationError)
	}
	request.Header.Set("Content-Type", "application/json")
	response, err := client.Do(request)
	if err != nil {
		return local(protocol.TransportError)
	}
	data, err := io.ReadAll(io.LimitReader(response.Body, limits.ResponseBytes+1))
	closeErr := response.Body.Close()
	if err != nil || closeErr != nil || len(data) > limits.ResponseBytes {
		return local(protocol.TransportError)
	}
	var env protocol.Envelope
	if json.Unmarshal(data, &env) != nil || env.Version != "v1" || env.RequestID == nil {
		return local(protocol.TransportError)
	}
	if env.Error == nil && response.StatusCode != 200 {
		return local(protocol.TransportError)
	}
	if env.Error != nil && response.StatusCode == 200 {
		return local(protocol.TransportError)
	}
	if _, err := fmt.Fprintln(out, string(data)); err != nil {
		return protocol.ExitCode(protocol.InternalError)
	}
	if env.Error != nil {
		return protocol.ExitCode(env.Error.Code)
	}
	return 0
}
