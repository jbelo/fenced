// Package cli executes explicitly registered commands through the gateway API.
package cli
