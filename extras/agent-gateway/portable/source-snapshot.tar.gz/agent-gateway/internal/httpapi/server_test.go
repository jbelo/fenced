package httpapi_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/providers/github"
	ghapi "agent-gateway/internal/providers/github/contract"
	"agent-gateway/internal/providers/shortcut"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"strings"
	"testing"
)

type countingProvider struct {
	github.Reader
	calls       int
	wrongTarget bool
	largeDiff   bool
}

func (p *countingProvider) ViewPR(ctx context.Context, budget *access.Budget, repo string, n int64) (ghapi.PRDetail, error) {
	p.calls++
	v, e := p.Reader.ViewPR(ctx, budget, repo, n)
	if p.wrongTarget {
		v.Repo = "forbidden/repo"
	}
	return v, e
}

func (p *countingProvider) DiffPR(ctx context.Context, budget *access.Budget, repo string, n int64) (github.DiffResult, error) {
	p.calls++
	v, e := p.Reader.DiffPR(ctx, budget, repo, n)
	if p.largeDiff {
		v.Text = strings.Repeat("x", 512*1024+1)
	}
	return v, e
}

func TestHTTPDenialNeverCallsProvider(t *testing.T) {
	policy := fixture()
	provider := &countingProvider{Reader: github.FixtureReader()}
	var audit bytes.Buffer
	s := newServer(t, policy, provider, shortcut.FixtureReader(), &audit)
	for _, body := range []string{
		`{"operation":"github.pr.view","target":{"repo":"forbidden/repo"},"args":{"number":1}}`,
		`{"operation":"github.pr.merge","target":{"repo":"company/project"},"args":{"number":1}}`,
		`{"operation":"github.pr.view","target":{"repo":"company/project"},"args":{"number":1,"url":"SECRET_RAW_INPUT"}}`,
	} {
		req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		s.ServeHTTP(w, req)
		if w.Code == 200 {
			t.Fatal("denied request succeeded")
		}
		if strings.Contains(w.Body.String(), "SECRET_RAW_INPUT") {
			t.Fatal("input echoed")
		}
	}
	if provider.calls != 0 {
		t.Fatal("denied requests called provider")
	}
	if strings.Contains(audit.String(), "SECRET_RAW_INPUT") || strings.Contains(audit.String(), "forbidden/repo") {
		t.Fatal("denied input leaked to audit")
	}
}

func TestHTTPAllSixMockOperations(t *testing.T) {
	policy := fixture()
	s := newServer(t, policy, github.FixtureReader(), shortcut.FixtureReader(), nil)
	operations := []struct{ op, target, args string }{{"github.pr.list", `{"repo":"company/project"}`, `{}`}, {"github.pr.view", `{"repo":"company/project"}`, `{"number":1}`}, {"github.pr.diff", `{"repo":"company/project"}`, `{"number":1}`}, {"github.pr.checks", `{"repo":"company/project"}`, `{"number":1}`}, {"shortcut.story.get", `{"workspace":"engineering"}`, `{"id":1}`}, {"shortcut.story.search", `{"workspace":"engineering"}`, `{"text":"mock story","archived":true}`}}
	for _, op := range operations {
		t.Run(op.op, func(t *testing.T) {
			req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"`+op.op+`","target":`+op.target+`,"args":`+op.args+`}`))
			req.Header.Set("Content-Type", "application/json")
			w := httptest.NewRecorder()
			s.ServeHTTP(w, req)
			if w.Code != 200 {
				t.Fatalf("%d %s", w.Code, w.Body)
			}
			var env protocol.Envelope
			if json.Unmarshal(w.Body.Bytes(), &env) != nil || env.Data == nil || env.RequestID == nil || *env.RequestID != w.Header().Get("X-Request-ID") {
				t.Fatal("invalid response envelope")
			}
		})
	}
}

func TestReturnedTargetAndDiffBounds(t *testing.T) {
	policy := fixture()
	for _, tc := range []struct {
		op     string
		p      countingProvider
		status int
	}{{"view", countingProvider{Reader: github.FixtureReader(), wrongTarget: true}, 403}, {"diff", countingProvider{Reader: github.FixtureReader(), largeDiff: true}, 413}} {
		s := newServer(t, policy, &tc.p, shortcut.FixtureReader(), nil)
		req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"github.pr.`+tc.op+`","target":{"repo":"company/project"},"args":{"number":1}}`))
		req.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		s.ServeHTTP(w, req)
		if w.Code != tc.status {
			t.Fatalf("got %d want %d", w.Code, tc.status)
		}
	}
}

func TestHTTPInputBounds(t *testing.T) {
	p := fixture()
	provider := &countingProvider{Reader: github.FixtureReader()}
	s := newServer(t, p, provider, shortcut.FixtureReader(), nil)
	req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(strings.Repeat(" ", 16385)))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	s.ServeHTTP(w, req)
	if w.Code != 413 || provider.calls != 0 {
		t.Fatal("request bound failed")
	}
}

func newServer(t *testing.T, p httpapi.Policy, gh github.Reader, sc shortcut.Reader, audit io.Writer) *httpapi.Server {
	t.Helper()
	s, err := httpapi.NewServer(p, append(github.Operations(gh), shortcut.Operations(sc)...), audit)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestDisabledProvidersRemainKnownButDenied(t *testing.T) {
	policy := fixture()
	s := newServer(t, policy, nil, nil, nil)
	for _, body := range []string{
		`{"operation":"github.pr.view","target":{"repo":"company/project"},"args":{"number":1}}`,
		`{"operation":"shortcut.story.get","target":{"workspace":"engineering"},"args":{"id":1}}`,
	} {
		if w := request(s, body); w.Code != 403 {
			t.Fatalf("disabled integration: %d %s", w.Code, w.Body)
		}
	}
}

type oversizedGitHub struct{ github.Reader }

func (p oversizedGitHub) ListPRs(ctx context.Context, budget *access.Budget, r string, a ghapi.PRListArgs) (protocol.Page[ghapi.PRSummary], error) {
	v, err := p.Reader.ListPRs(ctx, budget, r, a)
	v.Items = append(v.Items, v.Items[0])
	return v, err
}

func (p oversizedGitHub) PRChecks(ctx context.Context, budget *access.Budget, r string, a ghapi.PRChecksArgs) (github.ChecksResult, error) {
	v, err := p.Reader.PRChecks(ctx, budget, r, a)
	v.Items = append(v.Items, v.Items[0])
	return v, err
}

type oversizedShortcut struct{ shortcut.Reader }

func (p oversizedShortcut) SearchStories(ctx context.Context, budget *access.Budget, w string, a scapi.StorySearchArgs) (shortcut.SearchResult, error) {
	v, err := p.Reader.SearchStories(ctx, budget, w, a)
	v.Items = append(v.Items, v.Items[0])
	return v, err
}

func TestAllPagedBindingsEnforceRequestedLimit(t *testing.T) {
	policy := fixture()
	s := newServer(t, policy, oversizedGitHub{Reader: github.FixtureReader()}, oversizedShortcut{Reader: shortcut.FixtureReader()}, nil)
	for _, body := range []string{
		`{"operation":"github.pr.list","target":{"repo":"company/project"},"args":{"limit":1}}`,
		`{"operation":"github.pr.checks","target":{"repo":"company/project"},"args":{"number":1,"limit":1}}`,
		`{"operation":"shortcut.story.search","target":{"workspace":"engineering"},"args":{"text":"story","limit":1}}`,
	} {
		if w := request(s, body); w.Code != 413 {
			t.Fatalf("page limit: %d %s", w.Code, w.Body)
		}
	}
}

type wrongGitHubResults struct{ github.Reader }

func (p wrongGitHubResults) ListPRs(ctx context.Context, budget *access.Budget, r string, a ghapi.PRListArgs) (protocol.Page[ghapi.PRSummary], error) {
	v, err := p.Reader.ListPRs(ctx, budget, r, a)
	v.Items[0].Repo = "forbidden/repo"
	return v, err
}

func (p wrongGitHubResults) PRChecks(ctx context.Context, budget *access.Budget, r string, a ghapi.PRChecksArgs) (github.ChecksResult, error) {
	v, err := p.Reader.PRChecks(ctx, budget, r, a)
	v.Number++
	return v, err
}

type wrongShortcutResults struct {
	shortcut.Reader
	wrongFilter bool
}

func (p wrongShortcutResults) GetStory(ctx context.Context, budget *access.Budget, w string, id int64) (shortcut.StoryResult, error) {
	v, err := p.Reader.GetStory(ctx, budget, w, id)
	v.Workspace = "other"
	return v, err
}

func (p wrongShortcutResults) SearchStories(ctx context.Context, budget *access.Budget, w string, a scapi.StorySearchArgs) (shortcut.SearchResult, error) {
	v, err := p.Reader.SearchStories(ctx, budget, w, a)
	if p.wrongFilter {
		v.Items[0].Archived = !a.Archived
	} else {
		v.Items[0].Workspace = "other"
	}
	return v, err
}

func TestProviderResultValidatorsRunBeforePublication(t *testing.T) {
	policy := fixture()
	for _, tc := range []struct {
		op, target, args string
		status           int
		wrongFilter      bool
	}{
		{"github.pr.list", `{"repo":"company/project"}`, `{}`, 403, false},
		{"github.pr.checks", `{"repo":"company/project"}`, `{"number":1}`, 403, false},
		{"shortcut.story.get", `{"workspace":"engineering"}`, `{"id":1}`, 403, false},
		{"shortcut.story.search", `{"workspace":"engineering"}`, `{"text":"story"}`, 403, false},
		{"shortcut.story.search", `{"workspace":"engineering"}`, `{"text":"story"}`, 502, true},
	} {
		s := newServer(t, policy, wrongGitHubResults{Reader: github.FixtureReader()}, wrongShortcutResults{Reader: shortcut.FixtureReader(), wrongFilter: tc.wrongFilter}, nil)
		w := request(s, `{"operation":"`+tc.op+`","target":`+tc.target+`,"args":`+tc.args+`}`)
		if w.Code != tc.status || strings.Contains(w.Body.String(), `"data"`) {
			t.Fatalf("%s: %d %s", tc.op, w.Code, w.Body)
		}
	}
}
