package httpapi_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
	ghapi "agent-gateway/internal/providers/github/contract"
	"bytes"
	"context"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func request(s *httpapi.Server, body string) *httptest.ResponseRecorder {
	r := httptest.NewRequest("POST", "/v1/read", strings.NewReader(body))
	r.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	s.ServeHTTP(w, r)
	return w
}

const extraRequest = `{"operation":"example.read","target":{"repo":"company/project"},"args":{"number":1}}`

func extraOperation(execute func(context.Context, *access.Budget, operation.Target, ghapi.PRViewArgs) (string, error), bounds operation.Bounds) operation.Binding {
	definition := ghapi.PRView
	definition.Name = "example.read"
	return operation.Bind(definition, operation.Handler[ghapi.PRViewArgs, string]{
		Execute: execute, MaxBytes: 1,
		Validate: func(operation.Target, ghapi.PRViewArgs, string) error { return nil },
		Measure:  func(ghapi.PRViewArgs, string) operation.Bounds { return bounds },
	})
}

func TestRegisteredOperationUsesSharedControls(t *testing.T) {
	policy := fixture()
	for _, tc := range []struct {
		name, body, value string
		bounds            operation.Bounds
		status, calls     int
	}{
		{"success", extraRequest, "result", operation.Bounds{}, 200, 1},
		{"denied", strings.Replace(extraRequest, "company/project", "forbidden/repo", 1), "", operation.Bounds{}, 403, 0},
		{"invalid", strings.Replace(extraRequest, `"number":1`, `"number":1,"extra":true`, 1), "", operation.Bounds{}, 400, 0},
		{"item limit", extraRequest, "", operation.Bounds{Items: 2, ItemLimit: 1}, 413, 1},
		{"byte limit", extraRequest, "", operation.Bounds{Bytes: 2}, 413, 1},
		{"response limit", extraRequest, strings.Repeat("x", 1<<20), operation.Bounds{}, 413, 1},
	} {
		t.Run(tc.name, func(t *testing.T) {
			calls := 0
			op := extraOperation(func(context.Context, *access.Budget, operation.Target, ghapi.PRViewArgs) (string, error) {
				calls++
				return tc.value, nil
			}, tc.bounds)
			var audit bytes.Buffer
			s, err := httpapi.NewServer(policy, []operation.Binding{op}, &audit)
			if err != nil {
				t.Fatal(err)
			}
			w := request(s, tc.body)
			if w.Code != tc.status || calls != tc.calls {
				t.Fatalf("status=%d calls=%d body=%s", w.Code, calls, w.Body)
			}
			if !strings.Contains(audit.String(), `"request_id"`) {
				t.Fatal("missing audit")
			}
		})
	}
}

func TestRegistryRejectsIncompleteAndDuplicateBindings(t *testing.T) {
	policy := fixture()
	op := extraOperation(func(context.Context, *access.Budget, operation.Target, ghapi.PRViewArgs) (string, error) {
		return "", nil
	}, operation.Bounds{})
	incomplete := operation.Bind(ghapi.PRView, operation.Handler[ghapi.PRViewArgs, string]{Execute: func(context.Context, *access.Budget, operation.Target, ghapi.PRViewArgs) (string, error) {
		return "", nil
	}, Validate: nil, Measure: func(ghapi.PRViewArgs, string) operation.Bounds { return operation.Bounds{} }})
	for _, ops := range [][]operation.Binding{{op, op}, {{}}, {incomplete}} {
		if _, err := httpapi.NewServer(policy, ops, nil); err == nil {
			t.Fatal("invalid registry accepted")
		}
	}
}

func TestConstructionCopiesPolicyAndRegistry(t *testing.T) {
	policy := fixture()
	op := extraOperation(func(context.Context, *access.Budget, operation.Target, ghapi.PRViewArgs) (string, error) {
		return "ok", nil
	}, operation.Bounds{})
	ops := []operation.Binding{op}
	s, err := httpapi.NewServer(policy, ops, nil)
	if err != nil {
		t.Fatal(err)
	}
	policy[0].Key = "forbidden/repo"
	ops[0] = operation.Binding{}
	if w := request(s, extraRequest); w.Code != 200 {
		t.Fatalf("caller mutation affected server: %s", w.Body)
	}
	if w := request(s, strings.Replace(extraRequest, "company/project", "forbidden/repo", 1)); w.Code != 403 {
		t.Fatal("caller mutation changed authorization")
	}
}

func TestAdmissionAppliesToRegisteredOperations(t *testing.T) {
	policy := fixture()
	entered := make(chan struct{}, 8)
	release := make(chan struct{})
	var once sync.Once
	unblock := func() { once.Do(func() { close(release) }) }
	defer unblock()
	var calls atomic.Int32
	op := extraOperation(func(ctx context.Context, _ *access.Budget, _ operation.Target, _ ghapi.PRViewArgs) (string, error) {
		calls.Add(1)
		entered <- struct{}{}
		select {
		case <-release:
			return "ok", nil
		case <-ctx.Done():
			return "", ctx.Err()
		}
	}, operation.Bounds{})
	s, err := httpapi.NewServer(policy, []operation.Binding{op}, nil)
	if err != nil {
		t.Fatal(err)
	}
	completed := make(chan int, 8)
	for i := 0; i < 8; i++ {
		go func() { completed <- request(s, extraRequest).Code }()
	}
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	for i := 0; i < 8; i++ {
		select {
		case <-entered:
		case <-timer.C:
			t.Fatal("requests did not enter execution")
		}
	}
	w := request(s, extraRequest)
	if w.Code != 429 || calls.Load() != 8 {
		t.Errorf("admission: status=%d calls=%d", w.Code, calls.Load())
	}
	unblock()
	for i := 0; i < 8; i++ {
		if code := <-completed; code != 200 {
			t.Errorf("admitted request returned %d", code)
		}
	}
}
