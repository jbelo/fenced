package httpapi

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"context"
	"errors"
	"net/http/httptest"
	"strings"
	"testing"
)

type encodedView struct {
	calls *int
	fail  bool
}

func (v encodedView) MarshalJSON() ([]byte, error) {
	*v.calls++
	if v.fail {
		return nil, errors.New("private encoding diagnostic")
	}
	return []byte(`{"value":"view"}`), nil
}

func publicationBinding(value any) operation.Binding {
	target := operation.Target{Provider: "example", Kind: "collection", Key: "manuals"}
	return operation.Binding{Descriptor: operation.Descriptor{Name: "example.read", ScopeKind: "collection", Decode: func(protocol.Request) (operation.ValidatedRequest, error) {
		return operation.ValidatedRequest{Operation: "example.read", Target: target}, nil
	}, Normalize: func(r operation.ValidatedRequest) (operation.ValidatedRequest, error) { return r, nil }}, Execute: func(context.Context, *access.Budget, operation.ValidatedRequest) (operation.Result, error) {
		return operation.Result{Data: value}, nil
	}}
}

func TestPublicationEncodesOnce(t *testing.T) {
	for _, fail := range []bool{false, true} {
		count := 0
		b := publicationBinding(encodedView{calls: &count, fail: fail})
		s, err := NewServer(Policy{{Provider: "example", Kind: "collection", Key: "manuals"}}, []operation.Binding{b}, nil)
		if err != nil {
			t.Fatal(err)
		}
		req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"example.read","target":{},"args":{}}`))
		req.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		s.ServeHTTP(w, req)
		want := 200
		if fail {
			want = 500
		}
		if count != 1 || w.Code != want || strings.Contains(w.Body.String(), "private encoding diagnostic") {
			t.Fatalf("count=%d status=%d body=%s", count, w.Code, w.Body)
		}
	}
}

type panickingBody struct{}

func (panickingBody) Read([]byte) (int, error) { panic("fixture read panic") }
func TestBoundaryPanicReleasesAdmission(t *testing.T) {
	p, err := NewPipeline(nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	func() {
		defer func() {
			if recover() == nil {
				t.Error("missing panic")
			}
		}()
		_, _, _, _ = p.read(context.Background(), panickingBody{}, nil)
	}()
	for range limits.Concurrent {
		permit, err := p.reader.Admit(context.Background())
		if err != nil {
			t.Fatal("leaked admission:", err)
		}
		defer permit.Release()
	}
}
