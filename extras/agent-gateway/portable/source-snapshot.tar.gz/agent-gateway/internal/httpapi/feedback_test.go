package httpapi_test

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/providers/github"
	ghapi "agent-gateway/internal/providers/github/contract"
	"bytes"
	"context"
	"strings"
	"testing"
)

type feedbackCounter struct {
	github.Reader
	calls int
	large bool
	wrong bool
}

func (c *feedbackCounter) PRFeedback(ctx context.Context, b *access.Budget, repo string, a ghapi.PRFeedbackArgs) (github.FeedbackResult, error) {
	c.calls++
	result, err := c.Reader.PRFeedback(ctx, b, repo, a)
	if c.large {
		value := strings.Repeat("private-feedback", 100000)
		result.Reviews[0].Body = &value
	}
	if c.wrong {
		result.Identity.Repository = "other/private"
	}
	return result, err
}

func TestFeedbackHTTPValidationAndPublication(t *testing.T) {
	const valid = `{"operation":"github.pr.feedback","target":{"repo":"company/project"},"args":{"number":1}}`
	for _, tc := range []struct {
		name, body    string
		status, calls int
		large, wrong  bool
	}{
		{"valid", valid, 200, 1, false, false},
		{"denied", strings.Replace(valid, "company/project", "other/project", 1), 403, 0, false, false},
		{"unknown", strings.Replace(valid, `"number":1`, `"number":1,"since":"yesterday"`, 1), 400, 0, false, false},
		{"zero", strings.Replace(valid, `"number":1`, `"number":0`, 1), 400, 0, false, false},
		{"null", strings.Replace(valid, `"number":1`, `"number":null`, 1), 400, 0, false, false},
		{"limit", strings.Replace(valid, `"number":1`, `"number":1,"limit":51`, 1), 400, 0, false, false},
		{"cursor", strings.Replace(valid, `"number":1`, `"number":1,"cursor":"invalid"`, 1), 400, 1, false, false},
		{"oversize", valid, 413, 1, true, false},
		{"wrong evidence", valid, 403, 1, false, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			reader := &feedbackCounter{Reader: github.FixtureReader(), large: tc.large, wrong: tc.wrong}
			var audit bytes.Buffer
			server, err := httpapi.NewServer(fixture(), github.Operations(reader), &audit)
			if err != nil {
				t.Fatal(err)
			}
			response := request(server, tc.body)
			if response.Code != tc.status || reader.calls != tc.calls {
				t.Fatalf("status=%d calls=%d", response.Code, reader.calls)
			}
			if strings.Contains(audit.String(), "Synthetic") || strings.Contains(audit.String(), "private-feedback") {
				t.Fatal("body logged")
			}
			if tc.status != 200 && (strings.Contains(response.Body.String(), "Synthetic") || strings.Contains(response.Body.String(), "private-feedback")) {
				t.Fatal("body in error")
			}
		})
	}
}
