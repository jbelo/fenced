package httpapi_test

import (
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
)

func fixture() httpapi.Policy {
	return httpapi.Policy{
		operation.Target{Provider: "github", Kind: "repository", Key: "company/project"},
		operation.Target{Provider: "shortcut", Kind: "workspace", Key: "engineering"},
	}
}
