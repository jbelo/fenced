package httpapi

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"time"
)

// Audit is the safe wire representation of a request's access record.
type Audit struct {
	RequestID      string        `json:"request_id"`
	Operation      *string       `json:"operation"`
	Target         any           `json:"target"`
	Outcome        protocol.Code `json:"outcome"`
	ElapsedMS      int64         `json:"elapsed_ms"`
	UpstreamStatus *int          `json:"upstream_status"`
}

// Pipeline translates bounded wire requests into typed access.Read calls.
type Pipeline struct {
	reader     *access.Reader
	operations map[string]operation.Binding
}

// NewPipeline assembles wire decoders and the independent read use case.
func NewPipeline(policy Policy, bindings []operation.Binding) (*Pipeline, error) {
	entries, err := operation.Registry(bindings)
	if err != nil {
		return nil, err
	}
	operations := make([]access.Operation, 0, len(bindings))
	for _, b := range bindings {
		operations = append(operations, b.Core())
	}
	reader, err := access.New(policy, operations)
	if err != nil {
		return nil, err
	}
	return &Pipeline{reader: reader, operations: entries}, nil
}

// Do translates a complete wire request without a listening HTTP server.
func (p *Pipeline) Do(ctx context.Context, body []byte) (protocol.Envelope, Audit) {
	env, audit, _, release := p.read(ctx, bytes.NewReader(body), nil)
	defer release()
	return env, audit
}

func (p *Pipeline) read(ctx context.Context, body io.Reader, rejection error) (env protocol.Envelope, audit Audit, encoded []byte, release func()) {
	start := time.Now()
	release = func() {}
	var rawID [16]byte
	if _, err := rand.Read(rawID[:]); err != nil {
		rejection = protocol.Fail(protocol.InternalError)
	}
	id := hex.EncodeToString(rawID[:])
	audit = Audit{RequestID: id}
	defer func() { audit.ElapsedMS = time.Since(start).Milliseconds() }()
	finish := func(err error) {
		env = protocol.Envelope{Version: "v1", RequestID: &id, Error: protocol.ErrorPayload(err)}
		audit.Outcome = env.Error.Code
		// This envelope contains only fixed codes, a generated ID and numeric retry advice.
		encoded, _ = json.Marshal(env)
	}
	if rejection != nil {
		finish(rejection)
		return
	}
	permit, err := p.reader.Admit(ctx)
	if err != nil {
		finish(err)
		return
	}
	release = permit.Release
	// Cleanup on a panic before handing the permit back to the HTTP adapter.
	defer func() {
		if recovered := recover(); recovered != nil {
			permit.Release()
			panic(recovered)
		}
	}()
	ctx = permit.Context()
	data, err := io.ReadAll(io.LimitReader(body, limits.RequestBytes+1))
	if err != nil {
		if ctx.Err() != nil {
			finish(access.Fail(access.Timeout))
		} else {
			finish(protocol.Fail(protocol.InvalidInput))
		}
		return
	}
	raw, err := protocol.DecodeRequest(data)
	if err != nil {
		finish(err)
		return
	}
	binding, ok := p.operations[raw.Operation]
	if !ok {
		finish(protocol.Fail(protocol.UnsupportedOperation))
		return
	}
	request, err := binding.Decode(raw)
	if err != nil {
		finish(err)
		return
	}
	fits := func(value any) error {
		candidate := protocol.Envelope{Version: "v1", RequestID: &id, Data: value}
		payload, err := json.Marshal(candidate)
		if err != nil {
			return access.Fail(access.InternalError)
		}
		if len(payload) > limits.ResponseBytes {
			return access.Fail(access.LimitExceeded)
		}
		env = candidate
		encoded = payload
		return nil
	}
	_, record, err := p.reader.Read(permit, request, fits)
	audit.Operation = record.Operation
	audit.Target = record.Target
	audit.UpstreamStatus = record.UpstreamStatus
	if err != nil {
		finish(err)
		return
	}
	audit.Outcome = protocol.Success
	return
}
