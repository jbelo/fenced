package httpapi

import "agent-gateway/internal/access"

// Policy is the canonical allowlist supplied by executable assembly.
type Policy = access.Policy
