// Package httpapi adapts HTTP and wire requests to typed access execution.
package httpapi
