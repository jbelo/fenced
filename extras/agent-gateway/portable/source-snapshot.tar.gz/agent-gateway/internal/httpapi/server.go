package httpapi

import (
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"context"
	"encoding/json"
	"errors"
	"io"
	"log"
	"mime"
	"net/http"
	"sync"
	"time"
)

// Server adapts HTTP requests and audit output to a shared execution pipeline.
type Server struct {
	pipeline    *Pipeline
	auditWriter io.Writer
	auditMu     sync.Mutex
}

// NewServer constructs an HTTP adapter around immutable pipeline registration.
func NewServer(p Policy, bindings []operation.Binding, audit io.Writer) (*Server, error) {
	pipeline, err := NewPipeline(p, bindings)
	if err != nil {
		return nil, err
	}
	return &Server{pipeline: pipeline, auditWriter: audit}, nil
}

// ServeHTTP performs transport checks, then delegates all execution to the pipeline.
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if (r.URL.Path == "/healthz" || r.URL.Path == "/readyz") && r.Method == http.MethodGet {
		w.Header().Set("Content-Type", "application/json")
		status := `{"status":"ok"}`
		if r.URL.Path == "/readyz" && !s.pipeline.reader.Ready() {
			w.WriteHeader(http.StatusServiceUnavailable)
			status = `{"status":"draining"}`
		}
		if _, err := w.Write([]byte(status)); err != nil {
			log.Print("gateway health response write failed")
		}
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), limits.RequestTimeout)
	defer cancel()
	if err := http.NewResponseController(w).SetReadDeadline(time.Now().Add(limits.RequestTimeout)); err != nil && !errors.Is(err, http.ErrNotSupported) {
		log.Print("gateway read deadline unavailable")
	}
	env, audit, data, release := s.pipeline.read(ctx, r.Body, httpRejection(r))
	defer release()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Request-ID", audit.RequestID)
	status := http.StatusOK
	if env.Error != nil {
		status = protocol.HTTPStatus(env.Error.Code)
	}
	w.WriteHeader(status)
	if _, err := w.Write(data); err != nil {
		log.Print("gateway response write failed")
	}
	s.record(audit)
}

func httpRejection(r *http.Request) error {
	if r.URL.Path != "/v1/read" || r.Method != http.MethodPost {
		return protocol.Fail(protocol.UnsupportedOperation)
	}
	if r.URL.RawQuery != "" {
		return protocol.Fail(protocol.InvalidInput)
	}
	mt, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || mt != "application/json" {
		return protocol.Fail(protocol.InvalidInput)
	}
	return nil
}

func (s *Server) record(audit Audit) {
	if s.auditWriter == nil {
		return
	}
	s.auditMu.Lock()
	defer s.auditMu.Unlock()
	if err := json.NewEncoder(s.auditWriter).Encode(audit); err != nil {
		log.Print("gateway audit write failed")
	}
}

// Drain makes readiness fail and stops new read admission while existing work finishes.
func (s *Server) Drain() { s.pipeline.reader.Drain() }
