package httpapi

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"context"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestDrainReadinessAndAdmission(t *testing.T) {
	started, finish := make(chan struct{}), make(chan struct{})
	var calls atomic.Int32
	binding := publicationBinding("view")
	binding.Execute = func(context.Context, *access.Budget, operation.ValidatedRequest) (operation.Result, error) {
		calls.Add(1)
		close(started)
		<-finish
		return operation.Result{Data: "view"}, nil
	}
	server, err := NewServer(Policy{{Provider: "example", Kind: "collection", Key: "manuals"}}, []operation.Binding{binding}, nil)
	if err != nil {
		t.Fatal(err)
	}
	probe := func(path string) int {
		req := httptest.NewRequest("GET", path, nil)
		w := httptest.NewRecorder()
		server.ServeHTTP(w, req)
		return w.Code
	}
	read := func() int {
		req := httptest.NewRequest("POST", "/v1/read", strings.NewReader(`{"operation":"example.read","target":{},"args":{}}`))
		req.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		server.ServeHTTP(w, req)
		return w.Code
	}
	if status := probe("/readyz"); status != 200 {
		t.Fatal(status)
	}
	result := make(chan int, 1)
	go func() { result <- read() }()
	<-started
	server.Drain()
	server.Drain()
	if status := probe("/readyz"); status != 503 {
		t.Errorf("draining readiness=%d", status)
	}
	if status := probe("/healthz"); status != 200 {
		t.Errorf("draining health=%d", status)
	}
	if status := read(); status != 429 {
		t.Errorf("new request=%d", status)
	}
	close(finish)
	if status := <-result; status != 200 {
		t.Errorf("admitted request interrupted: %d", status)
	}
	if calls.Load() != 1 {
		t.Fatal("work admitted after drain")
	}
	if status := probe("/readyz"); status != 503 {
		t.Fatal("readiness recovered after draining", status)
	}
}
