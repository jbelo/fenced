package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"context"
	"strings"
)

// Reader exposes only the integration's supported typed read operations.
type Reader interface {
	ExpectedWorkspaceID(string) string
	GetStory(context.Context, *access.Budget, string, int64) (StoryResult, error)
	SearchStories(context.Context, *access.Budget, string, scapi.StorySearchArgs) (SearchResult, error)
}

// Operations binds the supported reads, returning policy denial when the reader is disabled.
func Operations(reader Reader) []operation.Binding {
	if reader == nil {
		out := []operation.Binding{}
		for _, d := range (registration{}).Definitions() {
			out = append(out, operation.Binding{Descriptor: d})
		}
		return out
	}
	return []operation.Binding{
		operation.Bind(scapi.StoryGet, operation.Handler[scapi.StoryGetArgs, StoryResult]{View: func(v StoryResult) any { return v.StoryDetail }, Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a scapi.StoryGetArgs) (StoryResult, error) {
			w := target.Key
			return reader.GetStory(ctx, budget, w, a.ID)
		}, Validate: func(target operation.Target, a scapi.StoryGetArgs, v StoryResult) error {
			w := target.Key
			if v.WorkspaceID == "" || !strings.EqualFold(v.WorkspaceID, reader.ExpectedWorkspaceID(w)) {
				return protocol.Fail(protocol.UpstreamAuthorization)
			}
			if v.Workspace != w || v.ID != a.ID {
				return protocol.Fail(protocol.PolicyDenied)
			}
			return nil
		}, Measure: func(scapi.StoryGetArgs, StoryResult) operation.Bounds { return operation.Bounds{} }},
		),
		operation.Bind(scapi.StorySearch, operation.Handler[scapi.StorySearchArgs, SearchResult]{View: func(v SearchResult) any { return v.Page }, Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a scapi.StorySearchArgs) (SearchResult, error) {
			w := target.Key
			return reader.SearchStories(ctx, budget, w, a)
		}, Validate: func(target operation.Target, a scapi.StorySearchArgs, v SearchResult) error {
			w := target.Key
			if v.WorkspaceID == "" || !strings.EqualFold(v.WorkspaceID, reader.ExpectedWorkspaceID(w)) {
				return protocol.Fail(protocol.UpstreamAuthorization)
			}
			for _, story := range v.Items {
				if story.Workspace != w {
					return protocol.Fail(protocol.PolicyDenied)
				}
				if story.Archived != a.Archived || (a.Type != "" && story.Type != a.Type) {
					return protocol.Fail(protocol.UpstreamUnavailable)
				}
			}
			return nil
		}, Measure: func(a scapi.StorySearchArgs, v SearchResult) operation.Bounds {
			return operation.Bounds{Items: len(v.Items), ItemLimit: a.Limit}
		}},
		),
	}
}
