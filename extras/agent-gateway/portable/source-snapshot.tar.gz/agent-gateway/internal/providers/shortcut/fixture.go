package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"bytes"
	"embed"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"
)

//go:embed testdata/*
var fixtures embed.FS

type fixtureTransport struct{ workspace WorkspaceConfig }

func (f fixtureTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	status := http.StatusOK
	var data []byte
	if r.Method != http.MethodGet || r.URL.Host != "api.app.shortcut.com" {
		status = http.StatusNotFound
	} else {
		switch {
		case r.URL.Path == "/api/v3/member":
			data, _ = json.Marshal(map[string]any{"workspace2": map[string]string{"id": f.workspace.WorkspaceID, "url_slug": f.workspace.Alias}})
		case strings.HasPrefix(r.URL.Path, "/api/v3/stories/") || r.URL.Path == "/api/v3/search/stories":
			data, _ = fixtures.ReadFile("testdata/story.json")
			var s story
			_ = json.Unmarshal(data, &s)
			search := r.URL.Path == "/api/v3/search/stories"
			if search {
				q := r.URL.Query().Get("query")
				s.Archived = strings.Contains(q, " is:archived")
				s.Name = strings.Split(strings.Split(q, " is:")[0], " !is:")[0]
				if parts := strings.Split(q, " type:"); len(parts) == 2 {
					s.Type = parts[1]
				}
			} else {
				s.ID, _ = strconv.ParseInt(strings.TrimPrefix(r.URL.Path, "/api/v3/stories/"), 10, 64)
			}
			s.URL = "https://app.shortcut.com/" + f.workspace.Alias + "/story/" + strconv.FormatInt(s.ID, 10)
			if search {
				data, _ = json.Marshal(map[string]any{"data": []story{s}, "next": nil})
			} else {
				data, _ = json.Marshal(s)
			}
		default:
			status = http.StatusNotFound
		}
	}
	return &http.Response{StatusCode: status, Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(data)), Request: r}, nil
}

// Fixture supplies optional mock transport to executable assembly.
func (registration) Fixture() http.RoundTripper { return fixtureTransport{} }

// FixtureReader's standalone test assembly owns its own key; runtime assembly shares one.
func fixtureContinuations() *access.Continuations {
	codec, err := cursor.New()
	if err != nil {
		panic(err)
	}
	pages, err := access.NewContinuations(codec, time.Now)
	if err != nil {
		panic(err)
	}
	return pages
}
