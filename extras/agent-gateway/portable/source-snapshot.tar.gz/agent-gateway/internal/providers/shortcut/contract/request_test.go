package contract

import (
	"agent-gateway/internal/protocol"
	"encoding/json"
	"testing"
)

func TestSearchContract(t *testing.T) {
	for _, tc := range []struct {
		args  string
		valid bool
	}{{`{"text":"gateway"}`, true}, {`{"text":"gateway","limit":50}`, true}, {`{"text":"gateway","limit":0}`, false}, {`{"text":"gateway","limit":51}`, false}, {`{"text":"is:archived"}`, false}, {`{"text":"gateway","unknown":true}`, false}} {
		r, err := StorySearch.Decode(protocol.Request{Operation: StorySearch.Name, Target: json.RawMessage(`{"workspace":"engineering"}`), Args: json.RawMessage(tc.args)})
		if (err == nil) != tc.valid {
			t.Fatalf("%s: %v", tc.args, err)
		}
		if tc.args == `{"text":"gateway"}` && r.Args.(StorySearchArgs).Limit != 20 {
			t.Fatal("wrong default")
		}
	}
}
