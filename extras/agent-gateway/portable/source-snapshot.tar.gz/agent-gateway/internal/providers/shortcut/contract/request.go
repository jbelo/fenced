package contract

import (
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"strings"
	"unicode"
)

// StoryGetArgs identifies the story to retrieve.
type StoryGetArgs struct {
	ID int64 `json:"id"`
}

// StorySearchArgs contains the search text, filters and pagination options.
type StorySearchArgs struct {
	Text     string `json:"text"`
	Type     string `json:"type,omitempty"`
	Archived bool   `json:"archived"`
	Limit    int    `json:"limit"`
	Cursor   string `json:"cursor,omitempty"`
}

// StoryGet defines story selection and its semantic validation.
var StoryGet = operation.Definition[StoryGetArgs]{Name: "shortcut.story.get", ScopeKind: "workspace", Target: workspaceTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizeGet, Audit: auditTarget, Arguments: func(raw json.RawMessage) (StoryGetArgs, error) {
	var a StoryGetArgs
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizeGet(a)
}}

func normalizeGet(a StoryGetArgs) (StoryGetArgs, error) {
	if !protocol.ValidID(a.ID) {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, nil
}

// StorySearch defines search decoding and pure semantic validation.
var StorySearch = operation.Definition[StorySearchArgs]{Name: "shortcut.story.search", ScopeKind: "workspace", Target: workspaceTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizeSearch, Audit: auditTarget, Arguments: func(raw json.RawMessage) (StorySearchArgs, error) {
	a := StorySearchArgs{Limit: limits.DefaultPageItems}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	var keys map[string]json.RawMessage
	_ = json.Unmarshal(raw, &keys)
	if _, present := keys["type"]; present && a.Type == "" {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizeSearch(a)
}}

func normalizeSearch(a StorySearchArgs) (StorySearchArgs, error) {
	if err := protocol.ValidatePage(a.Limit, a.Cursor); err != nil {
		return a, err
	}
	if len(a.Text) < 1 || len(a.Text) > 256 {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	for _, ch := range a.Text {
		if ch != ' ' && !unicode.IsLetter(ch) && !unicode.IsNumber(ch) {
			return a, protocol.Fail(protocol.InvalidInput)
		}
	}
	a.Text = strings.Join(strings.Fields(a.Text), " ")
	if a.Text == "" {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	if a.Type != "" && a.Type != "feature" && a.Type != "bug" && a.Type != "chore" {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, nil
}
