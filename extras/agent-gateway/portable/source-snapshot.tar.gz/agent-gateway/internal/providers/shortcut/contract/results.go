package contract

// StorySummary is the public story summary representation.
type StorySummary struct {
	ID        int64  `json:"id"`
	Workspace string `json:"workspace"`
	Title     string `json:"title"`
	Type      string `json:"type"`
	StateID   int64  `json:"state_id"`
	Archived  bool   `json:"archived"`
	URL       string `json:"url"`
	UpdatedAt string `json:"updated_at"`
}

// StoryDetail adds description, ownership and project information to a story summary.
type StoryDetail struct {
	StorySummary
	Description string   `json:"description"`
	OwnerIDs    []string `json:"owner_ids"`
	ProjectID   *int64   `json:"project_id"`
}
