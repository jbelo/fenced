package shortcut

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/provider"
	"agent-gateway/internal/providers/shortcut/contract"
	"encoding/json"
	"errors"
	"regexp"
	"strings"
)

var uuidPattern = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// WorkspaceConfig maps a public workspace alias to its provider identity and credential file.
type WorkspaceConfig struct {
	Alias       string `json:"alias"`
	WorkspaceID string `json:"workspace_id"`
	TokenFile   string `json:"token_file"`
}

// Config describes operator-supplied runtime configuration.
type Config struct {
	Enabled    *bool             `json:"enabled"`
	Workspaces []WorkspaceConfig `json:"workspaces"`
}

// Validate checks the configuration constraints before runtime initialization.
func (c Config) Validate(_ bool) error {
	if c.Enabled == nil || c.Workspaces == nil {
		return errors.New("missing Shortcut configuration")
	}
	if *c.Enabled && len(c.Workspaces) == 0 {
		return errors.New("missing Shortcut workspace mappings")
	}
	seen := map[string]bool{}
	for _, w := range c.Workspaces {
		if !contract.ValidWorkspaceAlias(w.Alias) || !uuidPattern.MatchString(w.WorkspaceID) || w.TokenFile != "/run/secrets/shortcut_"+w.Alias || seen[w.Alias] {
			return errors.New("invalid or duplicate Shortcut mapping")
		}
		seen[w.Alias] = true
	}
	return nil
}

// Targets validates provider policy entries and produces canonical target identities.
func (c Config) Targets(entries []contract.WorkspaceTarget) ([]operation.Target, error) {
	if entries == nil || c.Enabled == nil {
		return nil, errors.New("missing workspace policy")
	}
	aliases := map[string]bool{}
	for _, w := range c.Workspaces {
		aliases[w.Alias] = true
	}
	out := []operation.Target{}
	seen := map[operation.Target]bool{}
	for _, entry := range entries {
		target, err := contract.Target(entry.Workspace)
		if err != nil || !aliases[entry.Workspace] || seen[target] || !*c.Enabled {
			return nil, errors.New("unmapped, duplicate or disabled workspace target")
		}
		seen[target] = true
		out = append(out, target)
	}
	return out, nil
}

// New returns the statically registered Shortcut integration.
func New() provider.Provider { return registration{} }

type registration struct{}

func (registration) Name() string { return "shortcut" }
func (registration) Definitions() []operation.Descriptor {
	return []operation.Descriptor{contract.StoryGet.Describe(), contract.StorySearch.Describe()}
}

func (registration) Configure(raw json.RawMessage, rt provider.Runtime) (provider.Instance, error) {
	var c Config
	if protocol.DecodeStrict(raw, &c) != nil {
		return nil, errors.New("invalid Shortcut configuration")
	}
	if err := c.Validate(rt.ReadSecret != nil); err != nil {
		return nil, err
	}
	instance := &configured{config: c}
	if !*c.Enabled {
		return instance, nil
	}
	tokens := map[string]string{}
	if rt.ReadSecret != nil {
		for _, w := range c.Workspaces {
			data, err := rt.ReadSecret(w.TokenFile)
			if err != nil {
				return nil, err
			}
			token := strings.TrimSpace(string(data))
			if token == "" || strings.ContainsAny(token, "\r\n\t ") {
				return nil, errors.New("invalid Shortcut credential")
			}
			tokens[w.Alias] = token
		}
	}
	reader, err := newClient(rt.Continuations, c, tokens, rt.Transport)
	if err != nil {
		return nil, err
	}
	instance.bindings = Operations(reader)
	return instance, nil
}

type configured struct {
	config   Config
	bindings []operation.Binding
}

func (c *configured) Targets(raw json.RawMessage) ([]operation.Target, error) {
	var entries []contract.WorkspaceTarget
	if protocol.DecodeStrict(raw, &entries) != nil {
		return nil, errors.New("invalid Shortcut policy")
	}
	return c.config.Targets(entries)
}
func (c *configured) Operations() []operation.Binding { return c.bindings }

// FixtureReader runs the real adapter against a synthetic workspace transport.
func FixtureReader() Reader {
	enabled := true
	c := Config{Enabled: &enabled, Workspaces: []WorkspaceConfig{{Alias: "engineering", WorkspaceID: "11111111-1111-1111-1111-111111111111"}}}
	reader, _ := newClient(fixtureContinuations(), c, nil, fixtureTransport{})
	return reader
}
