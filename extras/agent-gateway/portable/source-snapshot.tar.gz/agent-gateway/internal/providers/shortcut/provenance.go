package shortcut

import (
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
)

// StoryResult carries verified workspace identity separately from its public alias.
type (
	StoryResult struct {
		scapi.StoryDetail
		WorkspaceID string
	}
	// SearchResult retains workspace identity even for an empty result page.
	SearchResult struct {
		protocol.Page[scapi.StorySummary]
		WorkspaceID string
	}
)

// ExpectedWorkspaceID returns configured identity, never response data.
func (c *client) ExpectedWorkspaceID(alias string) string { return c.workspaces[alias].id }
