package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"agent-gateway/internal/upstream"
	"context"
	"encoding/json"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type workspaceClient struct {
	http       *upstream.Client
	id         string
	verifiedID string
	slug       string
}
type (
	client struct {
		workspaces map[string]workspaceClient
		pages      *access.Continuations
	}
	story struct {
		ID          int64    `json:"id"`
		Name        string   `json:"name"`
		Type        string   `json:"story_type"`
		State       int64    `json:"workflow_state_id"`
		Archived    bool     `json:"archived"`
		URL         string   `json:"app_url"`
		Updated     string   `json:"updated_at"`
		Description string   `json:"description"`
		Owners      []string `json:"owner_ids"`
		Project     *int64   `json:"project_id"`
	}
)

func newClient(pages *access.Continuations, config Config, tokens map[string]string, transport http.RoundTripper) (*client, error) {
	if pages == nil {
		return nil, protocol.Fail(protocol.InternalError)
	}
	out := &client{workspaces: map[string]workspaceClient{}, pages: pages}
	for _, w := range config.Workspaces {
		headers := http.Header{}
		if token := tokens[w.Alias]; token != "" {
			headers.Set("Shortcut-Token", token)
		}
		selected := transport
		if fixture, ok := transport.(fixtureTransport); ok {
			fixture.workspace = w
			selected = fixture
		}
		httpClient, err := upstream.New("https://api.app.shortcut.com", headers, selected)
		if err != nil {
			return nil, err
		}
		out.workspaces[w.Alias] = workspaceClient{http: httpClient, id: w.WorkspaceID}
	}
	return out, nil
}

func (w workspaceClient) get(ctx context.Context, budget *access.Budget, path string, q url.Values, out any) error {
	data, _, err := w.http.Get(ctx, budget, path, q, "application/json")
	if err != nil {
		return err
	}
	if json.Unmarshal(data, out) != nil {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	return nil
}

func (c *client) workspace(ctx context.Context, budget *access.Budget, alias string) (workspaceClient, error) {
	w, ok := c.workspaces[alias]
	if !ok {
		return w, protocol.Fail(protocol.PolicyDenied)
	}
	var member struct {
		Workspace struct {
			ID   string `json:"id"`
			Slug string `json:"url_slug"`
		} `json:"workspace2"`
	}
	if err := w.get(ctx, budget, "/api/v3/member", nil, &member); err != nil {
		return w, err
	}
	if member.Workspace.ID == "" || !strings.EqualFold(member.Workspace.ID, w.id) || !scapi.ValidWorkspaceAlias(member.Workspace.Slug) {
		return w, protocol.Fail(protocol.UpstreamAuthorization)
	}
	w.verifiedID = member.Workspace.ID
	w.slug = member.Workspace.Slug
	return w, nil
}

func (s story) summary(alias, slug string) (scapi.StorySummary, error) {
	u, err := url.Parse(s.URL)
	if err != nil || u.Scheme != "https" || u.Host != "app.shortcut.com" || u.User != nil || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.RawPath != "" || !strings.HasPrefix(u.Path, "/"+slug+"/story/"+strconv.FormatInt(s.ID, 10)) || s.ID < 1 {
		return scapi.StorySummary{}, protocol.Fail(protocol.PolicyDenied)
	}
	rest := strings.TrimPrefix(u.Path, "/"+slug+"/story/"+strconv.FormatInt(s.ID, 10))
	if rest != "" && !strings.HasPrefix(rest, "/") {
		return scapi.StorySummary{}, protocol.Fail(protocol.PolicyDenied)
	}
	return scapi.StorySummary{ID: s.ID, Workspace: alias, Title: s.Name, Type: s.Type, StateID: s.State, Archived: s.Archived, URL: s.URL, UpdatedAt: s.Updated}, nil
}

func (c *client) GetStory(ctx context.Context, budget *access.Budget, alias string, id int64) (StoryResult, error) {
	w, err := c.workspace(ctx, budget, alias)
	if err != nil {
		return StoryResult{}, err
	}
	var s story
	if err := w.get(ctx, budget, "/api/v3/stories/"+strconv.FormatInt(id, 10), nil, &s); err != nil {
		return StoryResult{}, err
	}
	summary, err := s.summary(alias, w.slug)
	if err != nil {
		return StoryResult{}, err
	}
	if s.ID != id {
		return StoryResult{}, protocol.Fail(protocol.PolicyDenied)
	}
	if s.Owners == nil {
		s.Owners = []string{}
	}
	return StoryResult{StoryDetail: scapi.StoryDetail{StorySummary: summary, Description: s.Description, OwnerIDs: s.Owners, ProjectID: s.Project}, WorkspaceID: w.verifiedID}, nil
}
