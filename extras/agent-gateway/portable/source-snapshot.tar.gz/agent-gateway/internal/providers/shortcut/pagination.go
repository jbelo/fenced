package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"context"
	"encoding/json"
	"net/url"
	"strconv"
)

const searchPath = "/api/v3/search/stories"

type searchPosition struct {
	Token  string `json:"token"`
	Offset int    `json:"offset"`
}

func searchQuery(a scapi.StorySearchArgs) url.Values {
	query := a.Text + " "
	if !a.Archived {
		query += "!"
	}
	query += "is:archived"
	if a.Type != "" {
		query += " type:" + a.Type
	}
	return url.Values{"query": {query}, "page_size": {strconv.Itoa(a.Limit)}, "detail": {"full"}}
}

// continuation extracts only the opaque token from a verified provider path/URL.
// All other request parameters are rebuilt from the bound typed selection.
func continuation(next *string) (string, error) {
	if next == nil || *next == "" {
		return "", nil
	}
	u, err := url.Parse(*next)
	if err != nil || u.User != nil || u.Fragment != "" || u.Path != searchPath || u.RawPath != "" ||
		((u.Scheme != "" || u.Host != "") && (u.Scheme != "https" || u.Host != "api.app.shortcut.com")) {
		return "", protocol.Fail(protocol.UpstreamUnavailable)
	}
	q, err := url.ParseQuery(u.RawQuery)
	if err != nil {
		return "", protocol.Fail(protocol.UpstreamUnavailable)
	}
	// Echoed/default parameters are untrusted metadata, not request instructions.
	// Require an unambiguous continuation and ignore everything else.
	if len(q["next"]) != 1 {
		return "", protocol.Fail(protocol.UpstreamUnavailable)
	}
	token := q.Get("next")
	if token == "" {
		return "", protocol.Fail(protocol.UpstreamUnavailable)
	}
	return token, nil
}

func (c *client) SearchStories(ctx context.Context, budget *access.Budget, alias string, a scapi.StorySearchArgs) (SearchResult, error) {
	out := SearchResult{Page: protocol.Page[scapi.StorySummary]{Items: []scapi.StorySummary{}}}
	token := a.Cursor
	a.Cursor = ""
	encoded, err := json.Marshal(a)
	if err != nil {
		return out, protocol.Fail(protocol.InternalError)
	}
	target, err := scapi.Target(alias)
	if err != nil {
		return out, err
	}
	state, err := c.pages.Resume(access.CursorBinding(budget.PolicyRevision(), "shortcut.story.search", target, encoded), token)
	if err != nil {
		return out, err
	}
	pos := searchPosition{}
	if token != "" && (json.Unmarshal(state.Position, &pos) != nil || pos.Offset < 0 || pos.Offset > a.Limit) {
		return out, protocol.Fail(protocol.InvalidCursor)
	}
	w, err := c.workspace(ctx, budget, alias)
	if err != nil {
		return out, err
	}
	out.WorkspaceID = w.verifiedID
	scanned := 0
	more := true
	visited := map[string]bool{}
	for fetch := 0; fetch < limits.Fetches-1; fetch++ {
		if visited[pos.Token] {
			return out, protocol.Fail(protocol.UpstreamUnavailable)
		}
		visited[pos.Token] = true
		query := searchQuery(a)
		if pos.Token != "" {
			query.Set("next", pos.Token)
		}
		var result struct {
			Data []story `json:"data"`
			Next *string `json:"next"`
		}
		if err := w.get(ctx, budget, searchPath, query, &result); err != nil {
			return out, err
		}
		if len(result.Data) > a.Limit {
			return out, protocol.Fail(protocol.LimitExceeded)
		}
		next, err := continuation(result.Next)
		if err != nil {
			return out, err
		}
		if next != "" && visited[next] {
			return out, protocol.Fail(protocol.UpstreamUnavailable)
		}
		pos.Offset = min(pos.Offset, len(result.Data))
		for pos.Offset < len(result.Data) && len(out.Items) < a.Limit && state.Items+len(out.Items) < limits.TraversalItems && state.Candidates+scanned < limits.TraversalCandidates {
			row := result.Data[pos.Offset]
			pos.Offset++
			scanned++
			summary, err := row.summary(alias, w.slug)
			if err != nil {
				return out, err
			}
			if row.Archived == a.Archived && (a.Type == "" || row.Type == a.Type) {
				out.Items = append(out.Items, summary)
			}
		}
		if pos.Offset < len(result.Data) {
			break
		}
		pos = searchPosition{Token: next}
		more = next != ""
		if !more || len(out.Items) == a.Limit || state.Items+len(out.Items) == limits.TraversalItems || state.Candidates+scanned == limits.TraversalCandidates {
			break
		}
	}
	// Bound serialization before copying a potentially large provider token.
	// This oversized marker is never sealed: Next replaces it with a terminal cursor.
	position := make([]byte, limits.CursorBytes+1)
	if len(pos.Token) <= limits.CursorBytes {
		position, err = json.Marshal(pos)
		if err != nil {
			return out, protocol.Fail(protocol.InternalError)
		}
	}
	out.NextCursor, err = c.pages.Next(state, access.PageUsage{Items: len(out.Items), Candidates: scanned}, position, more)
	return out, err
}
