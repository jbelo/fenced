package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
)

type testTransport func(*http.Request) (*http.Response, error)

func (f testTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// R2: workspace verification precedes story access, including empty search pages.
func TestWorkspaceProvenance(t *testing.T) {
	const id = "11111111-1111-1111-1111-111111111111"
	workspace := WorkspaceConfig{Alias: "engineering", WorkspaceID: id}
	for _, name := range []string{"shortcut.story.get", "shortcut.story.search"} {
		for _, fault := range []string{"none", "workspace", "story", "different-alias", "missing-slug", "invalid-slug"} {
			t.Run(name+"/"+fault, func(t *testing.T) {
				calls := []string{}
				c, err := newClient(fixtureContinuations(), Config{Workspaces: []WorkspaceConfig{workspace}}, nil, testTransport(func(r *http.Request) (*http.Response, error) {
					if r.Method != "GET" || r.URL.Host != "api.app.shortcut.com" {
						t.Fatal("unsafe request")
					}
					calls = append(calls, r.URL.Path)
					response, err := (fixtureTransport{workspace: workspace}).RoundTrip(r)
					if err != nil {
						return nil, err
					}
					data, err := io.ReadAll(response.Body)
					if err != nil {
						t.Fatal(err)
					}
					if err = response.Body.Close(); err != nil {
						t.Fatal(err)
					}
					if fault == "workspace" && r.URL.Path == "/api/v3/member" {
						data = bytes.ReplaceAll(data, []byte(id), []byte("22222222-2222-2222-2222-222222222222"))
					}
					if fault == "story" {
						data = bytes.ReplaceAll(data, []byte("app.shortcut.com/engineering/"), []byte("app.shortcut.com/elsewhere/"))
					}
					if fault == "different-alias" {
						data = bytes.ReplaceAll(data, []byte(`"url_slug":"engineering"`), []byte(`"url_slug":"exoscale"`))
						data = bytes.ReplaceAll(data, []byte("app.shortcut.com/engineering/"), []byte("app.shortcut.com/exoscale/"))
					}
					if fault == "missing-slug" || fault == "invalid-slug" {
						slug := ""
						if fault == "invalid-slug" {
							slug = "../elsewhere"
						}
						data = bytes.ReplaceAll(data, []byte(`"url_slug":"engineering"`), []byte(`"url_slug":"`+slug+`"`))
					}
					response.Body = io.NopCloser(bytes.NewReader(data))
					return response, nil
				}))
				if err != nil {
					t.Fatal(err)
				}
				var binding operation.Binding
				for _, b := range Operations(c) {
					if b.Name == name {
						binding = b
					}
				}
				target := operation.Target{Provider: "shortcut", Kind: "workspace", Key: "engineering"}
				var args any = scapi.StoryGetArgs{ID: 1}
				if name == "shortcut.story.search" {
					args = scapi.StorySearchArgs{Text: "story", Limit: 20}
				}
				reader, err := access.New([]access.ResourceScope{target}, []access.Operation{binding.Core()})
				if err != nil {
					t.Fatal(err)
				}
				p, err := reader.Admit(context.Background())
				if err != nil {
					t.Fatal(err)
				}
				defer p.Release()
				data, _, err := reader.Read(p, access.Request{Operation: name, Target: target, Args: args}, func(any) error { return nil })
				if len(calls) == 0 || calls[0] != "/api/v3/member" {
					t.Fatal(calls)
				}
				switch fault {
				case "workspace", "missing-slug", "invalid-slug":
					if access.FailureKind(err) != access.UpstreamAuthorization || len(calls) != 1 || data != nil {
						t.Fatalf("calls=%v err=%v", calls, err)
					}
				case "story":
					if access.FailureKind(err) != access.PolicyDenied || data != nil {
						t.Fatal(err)
					}
				default:
					if err != nil {
						t.Fatal(err)
					}
					if len(calls) != 2 {
						t.Fatal(calls)
					}
					encoded, err := json.Marshal(data)
					if err != nil {
						t.Fatal(err)
					}
					if fault == "different-alias" && (!strings.Contains(string(encoded), `"workspace":"engineering"`) || !strings.Contains(string(encoded), "app.shortcut.com/exoscale/")) {
						t.Fatal("alias replaced by provider slug")
					}
					if strings.Contains(string(encoded), id) || strings.Contains(string(encoded), "WorkspaceID") {
						t.Fatal("internal workspace identity published")
					}
				}
			})
		}
	}
}

type wrongEvidence struct{ Reader }

func (w wrongEvidence) GetStory(ctx context.Context, b *access.Budget, alias string, id int64) (StoryResult, error) {
	v, err := w.Reader.GetStory(ctx, b, alias, id)
	v.WorkspaceID = "other-workspace"
	return v, err
}

func (w wrongEvidence) SearchStories(ctx context.Context, b *access.Budget, alias string, a scapi.StorySearchArgs) (SearchResult, error) {
	v, err := w.Reader.SearchStories(ctx, b, alias, a)
	v.WorkspaceID = "other-workspace"
	v.Items = nil
	return v, err
}

func TestBindingRejectsWrongWorkspaceIdentity(t *testing.T) {
	for _, binding := range Operations(wrongEvidence{Reader: FixtureReader()}) {
		args := `{"id":1}`
		if binding.Name == "shortcut.story.search" {
			args = `{"text":"story"}`
		}
		r, err := binding.Decode(protocol.Request{Operation: binding.Name, Target: json.RawMessage(`{"workspace":"engineering"}`), Args: json.RawMessage(args)})
		if err != nil {
			t.Fatal(err)
		}
		reader, err := access.New([]access.ResourceScope{r.Target}, []access.Operation{binding.Core()})
		if err != nil {
			t.Fatal(err)
		}
		p, err := reader.Admit(context.Background())
		if err != nil {
			t.Fatal(err)
		}
		data, _, err := reader.Read(p, r, func(any) error { return nil })
		p.Release()
		if access.FailureKind(err) != access.UpstreamAuthorization || data != nil {
			t.Fatalf("%s: %v", binding.Name, err)
		}
	}
}
