package shortcut

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"testing"
	"time"
)

const workspaceID = "11111111-1111-1111-1111-111111111111"

var workspaceScope = access.ResourceScope{Provider: "shortcut", Kind: "workspace", Key: "engineering"}

func searchResponse(t *testing.T, value any) *http.Response {
	t.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	return &http.Response{StatusCode: 200, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(string(data)))}
}

func searchStory(id int64, archived bool) story {
	return story{ID: id, Name: "story", Type: "feature", Archived: archived, State: 1, URL: "https://app.shortcut.com/engineering/story/" + strconv.FormatInt(id, 10), Updated: "2026-10-27T09:00:00Z"}
}

func searchReader(t *testing.T, c *client) *access.Reader {
	t.Helper()
	ops := []access.Operation{}
	for _, b := range Operations(c) {
		ops = append(ops, b.Core())
	}
	r, err := access.New([]access.ResourceScope{workspaceScope}, ops)
	if err != nil {
		t.Fatal(err)
	}
	return r
}

func readSearch(t *testing.T, r *access.Reader, args scapi.StorySearchArgs) (protocol.Page[scapi.StorySummary], error) {
	t.Helper()
	p, err := r.Admit(context.Background())
	if err != nil {
		return protocol.Page[scapi.StorySummary]{}, err
	}
	defer p.Release()
	data, _, err := r.Read(p, access.Request{Operation: "shortcut.story.search", Target: workspaceScope, Args: args}, func(any) error { return nil })
	if err != nil {
		if data != nil {
			t.Fatal("data with error")
		}
		return protocol.Page[scapi.StorySummary]{}, err
	}
	return data.(protocol.Page[scapi.StorySummary]), nil
}

func fixtureSearchClient(t *testing.T, pages *access.Continuations, transport http.RoundTripper) *client {
	t.Helper()
	c, err := newClient(pages, Config{Workspaces: []WorkspaceConfig{{Alias: "engineering", WorkspaceID: workspaceID}}}, nil, transport)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func nextSearch(args scapi.StorySearchArgs, token string) *string {
	q := searchQuery(args)
	q.Set("next", token)
	next := searchPath + "?" + q.Encode()
	return &next
}

func TestSearchOffsetsReplayAndWorkspace(t *testing.T) {
	args := scapi.StorySearchArgs{Text: "gateway", Limit: 2}
	calls := 0
	memberID := workspaceID
	title := "original"
	c := fixtureSearchClient(t, fixtureContinuations(), testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.URL.Path == "/api/v3/member" {
			return searchResponse(t, map[string]any{"workspace2": map[string]string{"id": memberID, "url_slug": "engineering"}}), nil
		}
		if r.URL.Path != searchPath || r.URL.Query().Get("query") != searchQuery(args).Get("query") || r.URL.Query().Get("detail") != "full" || r.URL.Query().Get("page_size") != "2" || r.URL.Query().Has("extra") {
			t.Fatal("unbound request")
		}
		rows := []story{searchStory(1, true), searchStory(2, false)}
		// Provider-supplied defaults/echoes must never override the bound query.
		nextValue := searchPath + "?next=page-two&query=other&page_size=99&detail=slim&extra=one&extra=two"
		next := &nextValue
		if r.URL.Query().Get("next") == "page-two" {
			rows = []story{searchStory(3, false), searchStory(4, false)}
			rows[1].Name = title
			next = nil
		}
		return searchResponse(t, map[string]any{"data": rows, "next": next}), nil
	}))
	reader := searchReader(t, c)
	first, err := readSearch(t, reader, args)
	if err != nil {
		t.Fatal(err)
	}
	if len(first.Items) != 2 || first.Items[0].ID != 2 || first.Items[1].ID != 3 || first.NextCursor == nil || calls != 3 {
		t.Fatal("first page", first, calls)
	}
	args.Cursor = *first.NextCursor
	second, err := readSearch(t, reader, args)
	if err != nil || len(second.Items) != 1 || second.Items[0].ID != 4 || second.NextCursor != nil {
		t.Fatal("partial page lost", second, err)
	}
	title = "mutated"
	replay, err := readSearch(t, reader, args)
	if err != nil || replay.Items[0].Title != "mutated" {
		t.Fatal("cached replay", err)
	}
	memberID = "22222222-2222-2222-2222-222222222222"
	before := calls
	if _, err := readSearch(t, reader, args); access.FailureKind(err) != access.UpstreamAuthorization || calls-before != 1 {
		t.Fatal("workspace bypass", err)
	}
}

func TestSearchCandidateCapAndWorstCaseFetches(t *testing.T) {
	args := scapi.StorySearchArgs{Text: "gateway", Limit: 50}
	calls := 0
	c := fixtureSearchClient(t, fixtureContinuations(), testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.URL.Path == "/api/v3/member" {
			return searchResponse(t, map[string]any{"workspace2": map[string]string{"id": workspaceID, "url_slug": "engineering"}}), nil
		}
		page, _ := strconv.Atoi(r.URL.Query().Get("next"))
		rows := []story{}
		for i := 0; i < 50; i++ {
			rows = append(rows, searchStory(int64(page*50+i+1), true))
		}
		return searchResponse(t, map[string]any{"data": rows, "next": nextSearch(args, strconv.Itoa(page+1))}), nil
	}))
	reader := searchReader(t, c)
	for i, wantCalls := range []int{5, 5, 3} {
		before := calls
		page, err := readSearch(t, reader, args)
		if err != nil {
			t.Fatal(err)
		}
		if len(page.Items) != 0 || page.NextCursor == nil || calls-before != wantCalls {
			t.Fatal("filtered page/candidate count", i, calls-before)
		}
		args.Cursor = *page.NextCursor
	}
	before := calls
	if _, err := readSearch(t, reader, args); access.FailureKind(err) != access.LimitExceeded || calls != before {
		t.Fatal("terminal accessed provider", err)
	}
}

func TestOversizedSearchContinuationKeepsPage(t *testing.T) {
	args := scapi.StorySearchArgs{Text: "gateway", Limit: 1}
	calls := 0
	c := fixtureSearchClient(t, fixtureContinuations(), testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.URL.Path == "/api/v3/member" {
			return searchResponse(t, map[string]any{"workspace2": map[string]string{"id": workspaceID, "url_slug": "engineering"}}), nil
		}
		return searchResponse(t, map[string]any{"data": []story{searchStory(1, false)}, "next": nextSearch(args, strings.Repeat("x", 1500))}), nil
	}))
	reader := searchReader(t, c)
	page, err := readSearch(t, reader, args)
	if err != nil || len(page.Items) != 1 || page.NextCursor == nil || len(*page.NextCursor) > limits.CursorBytes {
		t.Fatal("oversized position discarded page", err)
	}
	before := calls
	args.Cursor = *page.NextCursor
	if _, err := readSearch(t, reader, args); access.FailureKind(err) != access.LimitExceeded || calls != before {
		t.Fatal("terminal", err)
	}
}

func TestSearchContinuationValidation(t *testing.T) {
	args := scapi.StorySearchArgs{Text: "gateway", Limit: 50}
	good := nextSearch(args, "opaque+/=value")
	for _, prefix := range []string{"", "https://api.app.shortcut.com"} {
		value := prefix + *good
		token, err := continuation(&value)
		if err != nil || token != "opaque+/=value" { //nolint:gosec // G101: synthetic pagination value, not a credential.
			t.Fatal(token, err)
		}
	}
	for _, value := range []string{searchPath + "?next=x&query=other", searchPath + "?next=x&provider_default=one&provider_default=two"} {
		token, err := continuation(&value)
		if err != nil || token != "x" {
			t.Fatal("ignored metadata rejected", err)
		}
	}
	for _, value := range []string{"foo", "https://evil.example" + *good, "//evil.example" + *good, "http://api.app.shortcut.com" + *good, searchPath + "?next=x&next=y", searchPath + "?next=", searchPath + "?query=only", searchPath + "?next=x&extra=%zz", searchPath + "?next=x#fragment", "/api/v3/stories?next=x"} {
		if _, err := continuation(&value); err == nil {
			t.Fatal("unsafe continuation", value)
		}
	}
}

// Measurements are synthetic boundary evidence, not samples of live Shortcut tokens.
func TestShortcutContinuationSizes(t *testing.T) {
	codec, err := cursor.New()
	if err != nil {
		t.Fatal(err)
	}
	args := scapi.StorySearchArgs{Text: strings.Repeat("a", 256), Limit: 50}
	for _, size := range []int{64, 256, 800, 1000, 1500} {
		next := nextSearch(args, strings.Repeat("x", size))
		token, err := continuation(next)
		if err != nil {
			t.Fatal(err)
		}
		position, err := json.Marshal(searchPosition{Token: token, Offset: 49})
		if err != nil {
			t.Fatal(err)
		}
		state := access.CursorState{ExpiresAt: time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC).UnixNano(), Pages: 9, Items: 450, Candidates: 499, Position: position}
		for i := range state.Binding {
			state.Binding[i] = 255
		}
		encoded, err := codec.Seal(state)
		t.Logf("synthetic provider path=%d token=%d position=%d cursor=%d error=%v", len(*next), len(token), len(position), len(encoded), err)
		if size <= 800 && err != nil {
			t.Fatal("unexpected capacity regression", err)
		}
		if size >= 1000 && access.FailureKind(err) != access.LimitExceeded {
			t.Fatal("bound not enforced", err)
		}
	}
	// Extraction removes the repeated query and URL; only token/offset enter the position.
	u, err := url.Parse(*nextSearch(args, "small"))
	if err != nil || u.Query().Get("query") == "" {
		t.Fatal(err)
	}
}
