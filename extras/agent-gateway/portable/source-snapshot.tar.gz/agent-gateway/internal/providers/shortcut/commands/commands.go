package commands

import (
	"agent-gateway/internal/cli"
	"agent-gateway/internal/providers/shortcut/contract"
)

// Commands returns the explicitly supported command definitions.
func Commands() []cli.Command {
	return []cli.Command{
		cli.BindCommand([]string{"shortcut", "story", "get"}, contract.StoryGet, cli.Flag{Name: "workspace", Target: true}, cli.Flag{Name: "id", Kind: cli.IntegerFlag}),
		cli.BindCommand([]string{"shortcut", "story", "search"}, contract.StorySearch, cli.Flag{Name: "workspace", Target: true}, cli.Flag{Name: "text", Kind: cli.StringFlag}, cli.Flag{Name: "type", Kind: cli.StringFlag}, cli.Flag{Name: "archived", Kind: cli.BoolFlag}, cli.Flag{Name: "limit", Kind: cli.IntegerFlag}, cli.Flag{Name: "cursor", Kind: cli.StringFlag}),
	}
}
