// Package commands declares Shortcut CLI commands without importing provider clients.
package commands
