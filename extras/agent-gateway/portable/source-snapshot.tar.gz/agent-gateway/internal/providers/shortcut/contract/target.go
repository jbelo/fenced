package contract

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"regexp"
)

var aliasPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9-]*$`)

// WorkspaceTarget is the external workspace target shape.
type WorkspaceTarget struct {
	Workspace string `json:"workspace"`
}

// ValidWorkspaceAlias reports whether an alias uses the supported syntax.
func ValidWorkspaceAlias(alias string) bool { return aliasPattern.MatchString(alias) }

// Target converts an external provider identifier into a canonical target identity.
func Target(alias string) (operation.Target, error) {
	if !ValidWorkspaceAlias(alias) {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	return operation.Target{Provider: "shortcut", Kind: "workspace", Key: alias}, nil
}

func workspaceTarget(raw json.RawMessage) (operation.Target, error) {
	var t WorkspaceTarget
	if protocol.DecodeStrict(raw, &t) != nil {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	return Target(t.Workspace)
}
func auditTarget(t operation.Target) any { return WorkspaceTarget{Workspace: t.Key} }

func normalizeTarget(t operation.Target) (operation.Target, error) {
	if t.Provider != "shortcut" || t.Kind != "workspace" {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	return Target(t.Key)
}
