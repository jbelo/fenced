// Package shortcut implements the Shortcut integration and synthetic reads.
package shortcut
