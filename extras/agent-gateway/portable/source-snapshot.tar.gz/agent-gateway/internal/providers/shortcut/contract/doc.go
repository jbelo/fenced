// Package contract defines pure Shortcut operation schemas and public results.
package contract
