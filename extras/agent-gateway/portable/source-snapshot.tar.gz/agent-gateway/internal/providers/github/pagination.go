package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
	"encoding/json"
	"net/url"
	"strconv"
	"strings"
)

type position struct {
	Page, Offset, Source int
	Head                 string
}

func (c *client) resume(budget *access.Budget, operation, repo, token string, args any) (access.CursorState, position, error) {
	return c.resumeSources(budget, operation, repo, token, args, 1)
}

func (c *client) resumeSources(budget *access.Budget, operation, repo, token string, args any, maxSource int) (access.CursorState, position, error) {
	encoded, err := json.Marshal(args)
	if err != nil {
		return access.CursorState{}, position{}, protocol.Fail(protocol.InternalError)
	}
	target, err := ghapi.Target(repo)
	if err != nil {
		return access.CursorState{}, position{}, err
	}
	binding := access.CursorBinding(budget.PolicyRevision(), operation, target, encoded)
	state, err := c.pages.Resume(binding, token)
	pos := position{Page: 1}
	if err == nil && token != "" {
		if json.Unmarshal(state.Position, &pos) != nil || pos.Page < 1 || pos.Page > limits.TraversalPages+1 || pos.Offset < 0 || pos.Offset > limits.PageItems || pos.Source < 0 || pos.Source > maxSource {
			err = protocol.Fail(protocol.InvalidCursor)
		}
	}
	return state, pos, err
}

func (c *client) next(state access.CursorState, items int, pos position, more bool) (*string, error) {
	data, err := json.Marshal(pos)
	if err != nil {
		return nil, protocol.Fail(protocol.InternalError)
	}
	return c.pages.Next(state, access.PageUsage{Items: items}, data, more)
}

// getPage reads only the requested endpoint and extracts a validated next page number.
func (c *client) getPage(ctx context.Context, budget *access.Budget, path string, q url.Values, out any) (int, error) {
	body, headers, err := c.http.Get(ctx, budget, path, q, "application/vnd.github+json")
	if err != nil {
		return 0, err
	}
	next, err := nextPage(headers.Values("Link"), path, q)
	if err != nil {
		return 0, err
	}
	if json.Unmarshal(body, out) != nil {
		return 0, protocol.Fail(protocol.UpstreamUnavailable)
	}
	return next, nil
}

func nextPage(headers []string, path string, q url.Values) (int, error) {
	next := 0
	for _, header := range headers {
		for _, entry := range strings.Split(header, ",") {
			parts := strings.Split(strings.TrimSpace(entry), ";")
			isNext := false
			for _, attr := range parts[1:] {
				key, value, ok := strings.Cut(strings.TrimSpace(attr), "=")
				if ok && key == "rel" {
					for _, rel := range strings.Fields(strings.Trim(value, `"`)) {
						if rel == "next" {
							isNext = true
						}
					}
				}
			}
			if !isNext {
				continue
			}
			if next != 0 {
				return 0, protocol.Fail(protocol.UpstreamUnavailable)
			}
			link := strings.TrimSpace(parts[0])
			if !strings.HasPrefix(link, "<") || !strings.HasSuffix(link, ">") {
				return 0, protocol.Fail(protocol.UpstreamUnavailable)
			}
			u, err := url.Parse(link[1 : len(link)-1])
			if err != nil || u.Scheme != "https" || u.Host != "api.github.com" || u.User != nil || u.Fragment != "" || !paginationPath(u.Path, path) || u.RawPath != "" {
				return 0, protocol.Fail(protocol.UpstreamUnavailable)
			}
			values, err := url.ParseQuery(u.RawQuery)
			if err != nil {
				return 0, protocol.Fail(protocol.UpstreamUnavailable)
			}
			for key, v := range values {
				if len(v) != 1 || (key != "page" && (q.Get(key) == "" || v[0] != q.Get(key))) {
					return 0, protocol.Fail(protocol.UpstreamUnavailable)
				}
			}
			page, err := strconv.Atoi(values.Get("page"))
			current, _ := strconv.Atoi(q.Get("page"))
			if err != nil || page != current+1 || page < 2 {
				return 0, protocol.Fail(protocol.UpstreamUnavailable)
			}
			next = page
		}
	}
	return next, nil
}

// paginationPath accepts GitHub's canonical numeric repository URLs. Only the
// page number is used; subsequent requests keep the authorized owner/repo path.
func paginationPath(link, requested string) bool {
	if strings.EqualFold(link, requested) {
		return true
	}
	parts := strings.SplitN(requested, "/", 5)
	if len(parts) != 5 || parts[1] != "repos" {
		return false
	}
	repository, suffix, ok := strings.Cut(strings.TrimPrefix(link, "/repositories/"), "/")
	if !strings.HasPrefix(link, "/repositories/") || !ok || repository == "" || strings.Trim(repository, "0123456789") != "" {
		return false
	}
	id, err := strconv.ParseUint(repository, 10, 64)
	return err == nil && id > 0 && suffix == parts[4]
}

func (c *client) ListPRs(ctx context.Context, budget *access.Budget, repo string, a ghapi.PRListArgs) (protocol.Page[ghapi.PRSummary], error) {
	out := protocol.Page[ghapi.PRSummary]{Items: []ghapi.PRSummary{}}
	token := a.Cursor
	a.Cursor = ""
	state, pos, err := c.resume(budget, "github.pr.list", repo, token, a)
	if err != nil {
		return out, err
	}
	if pos.Source != 0 || pos.Offset != 0 || pos.Head != "" {
		return out, protocol.Fail(protocol.InvalidCursor)
	}
	var rows []pullRequest
	next, err := c.getPage(ctx, budget, "/repos/"+repo+"/pulls", url.Values{"state": {a.State}, "sort": {"updated"}, "direction": {"desc"}, "per_page": {strconv.Itoa(a.Limit)}, "page": {strconv.Itoa(pos.Page)}}, &rows)
	if err != nil {
		return out, err
	}
	if len(rows) > a.Limit {
		return out, protocol.Fail(protocol.LimitExceeded)
	}
	for _, row := range rows {
		summary, err := row.summary(repo)
		if err != nil {
			return out, err
		}
		out.Items = append(out.Items, summary)
	}
	pos.Page = next
	out.NextCursor, err = c.next(state, len(out.Items), pos, next != 0)
	return out, err
}

func (c *client) PRChecks(ctx context.Context, budget *access.Budget, repo string, a ghapi.PRChecksArgs) (ChecksResult, error) {
	out := ChecksResult{CheckPage: ghapi.CheckPage{Items: []ghapi.Check{}}}
	token := a.Cursor
	a.Cursor = ""
	state, pos, err := c.resume(budget, "github.pr.checks", repo, token, a)
	if err != nil {
		return out, err
	}
	pr, err := c.ViewPR(ctx, budget, repo, a.Number)
	if err != nil {
		return out, err
	}
	if !shaPattern.MatchString(pr.HeadSHA) {
		return out, protocol.Fail(protocol.UpstreamUnavailable)
	}
	if token != "" && pos.Head != pr.HeadSHA {
		return out, protocol.Fail(protocol.InvalidCursor)
	}
	pos.Head = pr.HeadSHA
	out.Identity = identity(pr)
	out.Number = pr.Number
	out.HeadSHA = pr.HeadSHA
	path := "/repos/" + repo + "/commits/" + pr.HeadSHA
	for pos.Source < 2 {
		var rows []ghapi.Check
		var next int
		if pos.Source == 0 {
			rows, next, err = c.checkRuns(ctx, budget, path, pos.Page, a.Limit)
		} else {
			rows, next, err = c.statuses(ctx, budget, path, pos.Page, a.Limit)
		}
		if err != nil {
			return out, err
		}
		if len(rows) > a.Limit {
			return out, protocol.Fail(protocol.LimitExceeded)
		}
		// A shortened mutable page can put the saved offset beyond its new end.
		offset := min(pos.Offset, len(rows))
		count := min(len(rows)-offset, a.Limit-len(out.Items), limits.TraversalItems-state.Items-len(out.Items))
		out.Items = append(out.Items, rows[offset:offset+count]...)
		offset += count
		if offset < len(rows) {
			pos.Offset = offset
			out.NextCursor, err = c.next(state, len(out.Items), pos, true)
			return out, err
		}
		if next != 0 {
			pos.Page = next
			pos.Offset = 0
			out.NextCursor, err = c.next(state, len(out.Items), pos, true)
			return out, err
		}
		pos.Source++
		pos.Page = 1
		pos.Offset = 0
	}
	out.NextCursor, err = c.next(state, len(out.Items), pos, false)
	return out, err
}
