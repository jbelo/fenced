package github

import (
	"agent-gateway/internal/access"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
	"net/url"
	"strconv"
)

func (c *client) checkRuns(ctx context.Context, budget *access.Budget, path string, page, limit int) ([]ghapi.Check, int, error) {
	var runs struct {
		Runs []struct {
			ID         int64   `json:"id"`
			Name       string  `json:"name"`
			Status     string  `json:"status"`
			Conclusion *string `json:"conclusion"`
			URL        *string `json:"html_url"`
			Started    *string `json:"started_at"`
			Completed  *string `json:"completed_at"`
		} `json:"check_runs"`
	}
	next, err := c.getPage(ctx, budget, path+"/check-runs", url.Values{"filter": {"latest"}, "per_page": {strconv.Itoa(limit)}, "page": {strconv.Itoa(page)}}, &runs)
	if err != nil {
		return nil, 0, err
	}
	out := []ghapi.Check{}
	for _, run := range runs.Runs {
		status := run.Status
		if status != "queued" && status != "in_progress" && status != "completed" {
			status = "unknown"
		}
		out = append(out, ghapi.Check{ID: strconv.FormatInt(run.ID, 10), Name: run.Name, Source: "check_run", Status: status, Conclusion: run.Conclusion, URL: run.URL, StartedAt: run.Started, CompletedAt: run.Completed})
	}

	return out, next, nil
}

func (c *client) statuses(ctx context.Context, budget *access.Budget, path string, page, limit int) ([]ghapi.Check, int, error) {
	var combined struct {
		Statuses []struct {
			ID      int64   `json:"id"`
			Context string  `json:"context"`
			State   string  `json:"state"`
			URL     *string `json:"target_url"`
			Created *string `json:"created_at"`
			Updated *string `json:"updated_at"`
		} `json:"statuses"`
	}
	next, err := c.getPage(ctx, budget, path+"/status", url.Values{"per_page": {strconv.Itoa(limit)}, "page": {strconv.Itoa(page)}}, &combined)
	if err != nil {
		return nil, 0, err
	}
	out := []ghapi.Check{}
	for _, status := range combined.Statuses {
		record := ghapi.Check{ID: strconv.FormatInt(status.ID, 10), Name: status.Context, Source: "status", Status: "unknown", URL: status.URL, StartedAt: status.Created}
		conclusion := "failure"
		switch status.State {
		case "pending":
			record.Status = "in_progress"
		case "success", "error", "failure":
			record.Status = "completed"
			if status.State == "success" {
				conclusion = "success"
			}
			record.Conclusion = &conclusion
			record.CompletedAt = status.Updated
		}
		out = append(out, record)
	}
	return out, next, nil
}
