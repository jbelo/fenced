// Package contract defines pure GitHub operation schemas and public results.
package contract
