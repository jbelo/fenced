package github

import ghapi "agent-gateway/internal/providers/github/contract"

// PRIdentity records identity from a verified upstream PR response.
type (
	PRIdentity struct {
		Repository string
		Number     int64
		HeadSHA    string
	}
	// DiffResult keeps lookup identity separate from the public diff view.
	DiffResult struct {
		ghapi.Diff
		Identity PRIdentity
	}
	// ChecksResult retains the verified PR identity used to construct checks requests.
	ChecksResult struct {
		ghapi.CheckPage
		Identity PRIdentity
	}
)

func identity(pr ghapi.PRDetail) PRIdentity {
	return PRIdentity{Repository: pr.Repo, Number: pr.Number, HeadSHA: pr.HeadSHA}
}
