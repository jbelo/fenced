package contract

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"errors"
	"regexp"
	"strings"
)

var repoPattern = regexp.MustCompile(`^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$`)

// RepositoryTarget is the external repository target shape.
type RepositoryTarget struct {
	Repo string `json:"repo"`
}

// CanonicalRepository validates owner/name syntax and normalizes its case.
func CanonicalRepository(repo string) (string, error) {
	if !repoPattern.MatchString(repo) {
		return "", errors.New("invalid repository")
	}
	for _, part := range strings.Split(repo, "/") {
		if part == "." || part == ".." {
			return "", errors.New("invalid repository")
		}
	}
	return strings.ToLower(repo), nil
}

// Target converts an external provider identifier into a canonical target identity.
func Target(repo string) (operation.Target, error) {
	canonical, err := CanonicalRepository(repo)
	if err != nil {
		return operation.Target{}, err
	}
	return operation.Target{Provider: "github", Kind: "repository", Key: canonical}, nil
}

func repositoryTarget(raw json.RawMessage) (operation.Target, error) {
	var t RepositoryTarget
	if protocol.DecodeStrict(raw, &t) != nil {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	target, err := Target(t.Repo)
	if err != nil {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	return target, nil
}
func auditTarget(t operation.Target) any { return RepositoryTarget{Repo: t.Key} }

func normalizeTarget(t operation.Target) (operation.Target, error) {
	if t.Provider != "github" || t.Kind != "repository" {
		return operation.Target{}, protocol.Fail(protocol.InvalidInput)
	}
	return Target(t.Key)
}
