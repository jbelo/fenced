package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
)

// Reader exposes only the integration's supported typed read operations.
type Reader interface {
	PRFeedback(context.Context, *access.Budget, string, ghapi.PRFeedbackArgs) (FeedbackResult, error)
	ListPRs(context.Context, *access.Budget, string, ghapi.PRListArgs) (protocol.Page[ghapi.PRSummary], error)
	ViewPR(context.Context, *access.Budget, string, int64) (ghapi.PRDetail, error)
	DiffPR(context.Context, *access.Budget, string, int64) (DiffResult, error)
	PRChecks(context.Context, *access.Budget, string, ghapi.PRChecksArgs) (ChecksResult, error)
}

// Operations registers known reads even when disabled; a nil reader denies access.
func Operations(reader Reader) []operation.Binding {
	if reader == nil {
		out := []operation.Binding{}
		for _, d := range (registration{}).Definitions() {
			out = append(out, operation.Binding{Descriptor: d})
		}
		return out
	}
	return []operation.Binding{
		feedbackBinding(reader),
		operation.Bind(ghapi.PRList, operation.Handler[ghapi.PRListArgs, protocol.Page[ghapi.PRSummary]]{Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a ghapi.PRListArgs) (protocol.Page[ghapi.PRSummary], error) {
			repo := target.Key
			return reader.ListPRs(ctx, budget, repo, a)
		}, Validate: func(target operation.Target, _ ghapi.PRListArgs, v protocol.Page[ghapi.PRSummary]) error {
			repo := target.Key
			for _, pr := range v.Items {
				if !sameRepository(repo, pr.Repo) {
					return protocol.Fail(protocol.PolicyDenied)
				}
			}
			return nil
		}, Measure: func(a ghapi.PRListArgs, v protocol.Page[ghapi.PRSummary]) operation.Bounds {
			return operation.Bounds{Items: len(v.Items), ItemLimit: a.Limit}
		}},
		),
		operation.Bind(ghapi.PRView, operation.Handler[ghapi.PRViewArgs, ghapi.PRDetail]{Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a ghapi.PRViewArgs) (ghapi.PRDetail, error) {
			repo := target.Key
			return reader.ViewPR(ctx, budget, repo, a.Number)
		}, Validate: func(target operation.Target, a ghapi.PRViewArgs, v ghapi.PRDetail) error {
			repo := target.Key
			if !sameRepository(repo, v.Repo) || v.Number != a.Number {
				return protocol.Fail(protocol.PolicyDenied)
			}
			return nil
		}, Measure: func(ghapi.PRViewArgs, ghapi.PRDetail) operation.Bounds { return operation.Bounds{} }},
		),
		operation.Bind(ghapi.PRDiff, operation.Handler[ghapi.PRDiffArgs, DiffResult]{MaxBytes: limits.DiffBytes, View: func(v DiffResult) any { return v.Diff }, Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a ghapi.PRDiffArgs) (DiffResult, error) {
			repo := target.Key
			return reader.DiffPR(ctx, budget, repo, a.Number)
		}, Validate: func(target operation.Target, a ghapi.PRDiffArgs, v DiffResult) error {
			if !sameRepository(target.Key, v.Identity.Repository) || v.Identity.Number != a.Number || v.Repo != v.Identity.Repository || v.Number != v.Identity.Number {
				return protocol.Fail(protocol.PolicyDenied)
			}
			return nil
		}, Measure: func(_ ghapi.PRDiffArgs, v DiffResult) operation.Bounds {
			return operation.Bounds{Bytes: len(v.Text)}
		}},
		),
		operation.Bind(ghapi.PRChecks, operation.Handler[ghapi.PRChecksArgs, ChecksResult]{View: func(v ChecksResult) any { return v.CheckPage }, Execute: func(ctx context.Context, budget *access.Budget, target operation.Target, a ghapi.PRChecksArgs) (ChecksResult, error) {
			repo := target.Key
			return reader.PRChecks(ctx, budget, repo, a)
		}, Validate: func(target operation.Target, a ghapi.PRChecksArgs, v ChecksResult) error {
			if !sameRepository(target.Key, v.Identity.Repository) || v.Identity.Number != a.Number || v.Number != v.Identity.Number || v.HeadSHA != v.Identity.HeadSHA || !shaPattern.MatchString(v.Identity.HeadSHA) {
				return protocol.Fail(protocol.PolicyDenied)
			}
			return nil
		}, Measure: func(a ghapi.PRChecksArgs, v ChecksResult) operation.Bounds {
			return operation.Bounds{Items: len(v.Items), ItemLimit: a.Limit}
		}},
		),
	}
}

func sameRepository(expected, actual string) bool {
	canonical, err := ghapi.CanonicalRepository(actual)
	return err == nil && canonical == expected
}
