package contract

import (
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
)

// PRListArgs contains the filters and pagination options for listing pull requests.
type PRListArgs struct {
	State  string `json:"state"`
	Limit  int    `json:"limit"`
	Cursor string `json:"cursor,omitempty"`
}

// PRViewArgs identifies the pull request to retrieve.
type PRViewArgs struct {
	Number int64 `json:"number"`
}

// PRDiffArgs identifies the pull request whose diff is requested.
type PRDiffArgs struct {
	Number int64 `json:"number"`
}

// PRChecksArgs identifies a pull request and its check pagination options.
type PRChecksArgs struct {
	Number int64  `json:"number"`
	Limit  int    `json:"limit"`
	Cursor string `json:"cursor,omitempty"`
}

// PRList defines the pure request contract.
var PRList = operation.Definition[PRListArgs]{Name: "github.pr.list", ScopeKind: "repository", Target: repositoryTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizePRList, Audit: auditTarget, Arguments: func(raw json.RawMessage) (PRListArgs, error) {
	a := PRListArgs{State: "open", Limit: limits.DefaultPageItems}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizePRList(a)
}}

func normalizePRList(a PRListArgs) (PRListArgs, error) {
	if a.State != "open" && a.State != "closed" && a.State != "all" {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, protocol.ValidatePage(a.Limit, a.Cursor)
}

// PRView defines the pure request contract.
var PRView = operation.Definition[PRViewArgs]{Name: "github.pr.view", ScopeKind: "repository", Target: repositoryTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizePRView, Audit: auditTarget, Arguments: func(raw json.RawMessage) (PRViewArgs, error) {
	a := PRViewArgs{}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizePRView(a)
}}

func normalizePRView(a PRViewArgs) (PRViewArgs, error) {
	if !protocol.ValidID(a.Number) {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, nil
}

// PRDiff defines the pure request contract.
var PRDiff = operation.Definition[PRDiffArgs]{Name: "github.pr.diff", ScopeKind: "repository", Target: repositoryTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizePRDiff, Audit: auditTarget, Arguments: func(raw json.RawMessage) (PRDiffArgs, error) {
	a := PRDiffArgs{}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizePRDiff(a)
}}

func normalizePRDiff(a PRDiffArgs) (PRDiffArgs, error) {
	if !protocol.ValidID(a.Number) {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, nil
}

// PRChecks defines the pure request contract.
var PRChecks = operation.Definition[PRChecksArgs]{Name: "github.pr.checks", ScopeKind: "repository", Target: repositoryTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizePRChecks, Audit: auditTarget, Arguments: func(raw json.RawMessage) (PRChecksArgs, error) {
	a := PRChecksArgs{Limit: limits.DefaultPageItems}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizePRChecks(a)
}}

func normalizePRChecks(a PRChecksArgs) (PRChecksArgs, error) {
	if !protocol.ValidID(a.Number) {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, protocol.ValidatePage(a.Limit, a.Cursor)
}
