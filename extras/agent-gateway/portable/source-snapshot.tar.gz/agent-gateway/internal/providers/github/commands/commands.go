package commands

import (
	"agent-gateway/internal/cli"
	"agent-gateway/internal/providers/github/contract"
)

// Commands returns the explicitly supported command definitions.
func Commands() []cli.Command {
	return []cli.Command{
		cli.BindCommand([]string{"github", "pr", "feedback"}, contract.PRFeedback, cli.Flag{Name: "repo", Target: true}, cli.Flag{Name: "number", Kind: cli.IntegerFlag}, cli.Flag{Name: "limit", Kind: cli.IntegerFlag}, cli.Flag{Name: "cursor", Kind: cli.StringFlag}),
		cli.BindCommand([]string{"github", "pr", "list"}, contract.PRList, cli.Flag{Name: "repo", Target: true}, cli.Flag{Name: "state", Kind: cli.StringFlag}, cli.Flag{Name: "limit", Kind: cli.IntegerFlag}, cli.Flag{Name: "cursor", Kind: cli.StringFlag}),
		cli.BindCommand([]string{"github", "pr", "view"}, contract.PRView, cli.Flag{Name: "repo", Target: true}, cli.Flag{Name: "number", Kind: cli.IntegerFlag}),
		cli.BindCommand([]string{"github", "pr", "diff"}, contract.PRDiff, cli.Flag{Name: "repo", Target: true}, cli.Flag{Name: "number", Kind: cli.IntegerFlag}),
		cli.BindCommand([]string{"github", "pr", "checks"}, contract.PRChecks, cli.Flag{Name: "repo", Target: true}, cli.Flag{Name: "number", Kind: cli.IntegerFlag}, cli.Flag{Name: "limit", Kind: cli.IntegerFlag}, cli.Flag{Name: "cursor", Kind: cli.StringFlag}),
	}
}
