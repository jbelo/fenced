package contract

// PRSummary is the public pull-request summary representation.
type PRSummary struct {
	Number    int64   `json:"number"`
	Repo      string  `json:"repo"`
	Title     string  `json:"title"`
	State     string  `json:"state"`
	Draft     bool    `json:"draft"`
	Author    *string `json:"author"`
	URL       string  `json:"url"`
	UpdatedAt string  `json:"updated_at"`
}

// PRDetail adds description and branch information to a pull-request summary.
type PRDetail struct {
	PRSummary
	Body    string `json:"body"`
	Merged  bool   `json:"merged"`
	BaseRef string `json:"base_ref"`
	HeadRef string `json:"head_ref"`
	HeadSHA string `json:"head_sha"`
}

// Diff contains the requested pull-request identity and diff text.
type Diff struct {
	Number int64  `json:"number"`
	Repo   string `json:"repo"`
	Text   string `json:"diff"`
}

// Check is a normalized check-run or commit-status record.
type Check struct {
	ID          string  `json:"id"`
	Name        string  `json:"name"`
	Source      string  `json:"source"`
	Status      string  `json:"status"`
	Conclusion  *string `json:"conclusion"`
	URL         *string `json:"url"`
	StartedAt   *string `json:"started_at"`
	CompletedAt *string `json:"completed_at"`
}

// CheckPage contains checks associated with a pull request and resolved head.
type CheckPage struct {
	Number     int64   `json:"number"`
	HeadSHA    string  `json:"head_sha"`
	Items      []Check `json:"items"`
	NextCursor *string `json:"next_cursor"`
}
