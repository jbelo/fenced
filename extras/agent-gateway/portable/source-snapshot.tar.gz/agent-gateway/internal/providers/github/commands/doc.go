// Package commands declares GitHub CLI commands without importing provider clients.
package commands
