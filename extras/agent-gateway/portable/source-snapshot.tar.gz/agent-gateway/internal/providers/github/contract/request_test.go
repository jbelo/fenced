package contract

import (
	"agent-gateway/internal/protocol"
	"encoding/json"
	"testing"
)

func TestListContract(t *testing.T) {
	for _, tc := range []struct {
		args  string
		valid bool
	}{{`{}`, true}, {`{"limit":50}`, true}, {`{"limit":0}`, false}, {`{"limit":51}`, false}, {`{"host":"elsewhere"}`, false}, {`{"state":"invalid"}`, false}} {
		r, err := PRList.Decode(protocol.Request{Operation: PRList.Name, Target: json.RawMessage(`{"repo":"Company/Project"}`), Args: json.RawMessage(tc.args)})
		if (err == nil) != tc.valid {
			t.Fatalf("%s: %v", tc.args, err)
		}
		if err == nil && r.Target.Key != "company/project" {
			t.Fatal(r.Target)
		}
		if tc.args == `{}` && r.Args.(PRListArgs).Limit != 20 {
			t.Fatal("wrong default")
		}
	}
}
