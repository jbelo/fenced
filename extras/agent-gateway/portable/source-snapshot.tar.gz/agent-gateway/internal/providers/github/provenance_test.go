package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
)

type testTransport func(*http.Request) (*http.Response, error)

func (f testTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// R2: every GitHub operation rejects a PR response from another repository.
func TestRepositoryProvenance(t *testing.T) {
	for _, name := range []string{"github.pr.list", "github.pr.view", "github.pr.diff", "github.pr.checks"} {
		for _, fault := range []string{"valid", "wrong", "mixed-case"} {
			t.Run(name+"/"+fault, func(t *testing.T) {
				calls := []string{}
				c, err := newClient(fixtureContinuations(), "", testTransport(func(r *http.Request) (*http.Response, error) {
					if r.Method != "GET" || r.URL.Host != "api.github.com" || !strings.HasPrefix(r.URL.Path, "/repos/company/project/") {
						t.Fatal("request escaped authorized repository")
					}
					calls = append(calls, r.URL.Path)
					response, err := (fixtureTransport{}).RoundTrip(r)
					if err != nil {
						return nil, err
					}
					data, err := io.ReadAll(response.Body)
					if err != nil {
						t.Fatal(err)
					}
					if err = response.Body.Close(); err != nil {
						t.Fatal(err)
					}
					if fault == "wrong" {
						data = bytes.ReplaceAll(data, []byte(`"full_name":"company/project"`), []byte(`"full_name":"other/private"`))
					}
					if fault == "mixed-case" {
						data = bytes.ReplaceAll(data, []byte("company/project"), []byte("Company/Project"))
					}
					response.Body = io.NopCloser(bytes.NewReader(data))
					return response, nil
				}))
				if err != nil {
					t.Fatal(err)
				}
				target := operation.Target{Provider: "github", Kind: "repository", Key: "company/project"}
				var selected operation.Binding
				for _, b := range Operations(c) {
					if b.Name == name {
						selected = b
					}
				}
				reader, err := access.New([]access.ResourceScope{target}, []access.Operation{selected.Core()})
				if err != nil {
					t.Fatal(err)
				}
				args := map[string]any{"github.pr.list": ghapi.PRListArgs{State: "open", Limit: 20}, "github.pr.view": ghapi.PRViewArgs{Number: 1}, "github.pr.diff": ghapi.PRDiffArgs{Number: 1}, "github.pr.checks": ghapi.PRChecksArgs{Number: 1, Limit: 20}}
				permit, err := reader.Admit(context.Background())
				if err != nil {
					t.Fatal(err)
				}
				defer permit.Release()
				data, _, err := reader.Read(permit, access.Request{Operation: name, Target: target, Args: args[name]}, func(any) error { return nil })
				if fault == "wrong" {
					if access.FailureKind(err) != access.PolicyDenied || data != nil || len(calls) != 1 {
						t.Fatalf("calls=%v data=%v err=%v", calls, data, err)
					}
					return
				}
				if err != nil {
					t.Fatal(err)
				}
				encoded, err := json.Marshal(data)
				if err != nil {
					t.Fatal(err)
				}
				if strings.Contains(string(encoded), "Identity") {
					t.Fatal("internal identity published")
				}
				want := 1
				if name == "github.pr.diff" {
					want = 2
				}
				if name == "github.pr.checks" {
					want = 3
					if !strings.Contains(calls[1], "/commits/0123456789012345678901234567890123456789/check-runs") {
						t.Fatalf("head not used: %v", calls)
					}
				}
				if len(calls) != want {
					t.Fatalf("calls=%v", calls)
				}
			})
		}
	}
}

type wrongEvidence struct{ Reader }

func (w wrongEvidence) DiffPR(ctx context.Context, b *access.Budget, repo string, n int64) (DiffResult, error) {
	v, err := w.Reader.DiffPR(ctx, b, repo, n)
	v.Identity.Repository = "other/private"
	return v, err
}

func (w wrongEvidence) PRChecks(ctx context.Context, b *access.Budget, repo string, a ghapi.PRChecksArgs) (ChecksResult, error) {
	v, err := w.Reader.PRChecks(ctx, b, repo, a)
	v.Identity.Repository = "other/private"
	return v, err
}

func TestBindingRejectsWrongLookupIdentity(t *testing.T) {
	for _, b := range Operations(wrongEvidence{Reader: FixtureReader()}) {
		if b.Name != "github.pr.diff" && b.Name != "github.pr.checks" {
			continue
		}
		args := `{"number":1}`
		r, err := b.Decode(protocol.Request{Operation: b.Name, Target: json.RawMessage(`{"repo":"company/project"}`), Args: json.RawMessage(args)})
		if err != nil {
			t.Fatal(err)
		}
		reader, err := access.New([]access.ResourceScope{r.Target}, []access.Operation{b.Core()})
		if err != nil {
			t.Fatal(err)
		}
		p, err := reader.Admit(context.Background())
		if err != nil {
			t.Fatal(err)
		}
		data, _, err := reader.Read(p, r, func(any) error { return nil })
		p.Release()
		if access.FailureKind(err) != access.PolicyDenied || data != nil {
			t.Fatalf("%s: %v", b.Name, err)
		}
	}
}

func TestPullURLProvenance(t *testing.T) {
	for _, raw := range []string{
		"https://github.com/elsewhere/project/pull/1",
		"https://github.com/company/project/pull/11",
		"https://github.com/company/project/pull/1/extra",
		"https://github.com/company/project/pull/1?x=y",
		"https://github.com/company/project/pull/1#fragment",
		"https://github.com@evil.test/company/project/pull/1",
		"https://github.com:443/company/project/pull/1",
		"http://github.com/company/project/pull/1",
		"https://github.com/company/%70roject/pull/1",
	} {
		if validPullURL(raw, "company/project", 1) {
			t.Errorf("accepted %s", raw)
		}
	}
}
