package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/limits"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"strings"
	"testing"
	"time"
)

func feedbackRead(t *testing.T, reader *access.Reader, a ghapi.PRFeedbackArgs) ghapi.FeedbackPage {
	t.Helper()
	data, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, a, acceptPage)
	if err != nil {
		t.Fatal(err)
	}
	return data.(ghapi.FeedbackPage)
}

func feedbackClient(t *testing.T, transport testTransport) *client {
	t.Helper()
	c, err := newClient(fixtureContinuations(), "", transport)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestFeedbackGroupingAcrossPages(t *testing.T) {
	calls := 0
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		calls++
		if r.Method != "GET" || r.URL.Host != "api.github.com" || !strings.HasPrefix(r.URL.Path, "/repos/company/project/") {
			t.Fatal("escaped read boundary")
		}
		return (fixtureTransport{}).RoundTrip(r)
	})
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	for _, size := range []int{1, 2, 3, 50} {
		args := ghapi.PRFeedbackArgs{Number: 1, Limit: size}
		ids := []string{}
		var root string
		for page := 0; ; page++ {
			before := calls
			result := feedbackRead(t, reader, args)
			if calls-before > 4 || result.ItemCount() > size {
				t.Fatal("unbounded work")
			}
			for _, review := range result.Reviews {
				ids = append(ids, "review:"+review.ID)
				if review.State != "CHANGES_REQUESTED" || review.SubmittedAt == nil || review.UpdatedAt != nil {
					t.Fatal("review semantics")
				}
			}
			for _, comment := range result.DiscussionComments {
				ids = append(ids, "discussion:"+comment.ID)
			}
			for _, thread := range result.Threads {
				if thread.RootCommentID != "301" || thread.Resolved != nil || thread.Outdated != nil {
					t.Fatal("thread semantics")
				}
				root = thread.RootCommentID
				for _, comment := range thread.Comments {
					ids = append(ids, "inline:"+comment.ID)
					if comment.ReviewID == nil || *comment.ReviewID != "101" || comment.DiffHunk == nil || comment.Path != "example.go" {
						t.Fatal("lost context")
					}
					if comment.ID == "302" && (comment.InReplyToID == nil || *comment.InReplyToID != root) {
						t.Fatal("lost reply")
					}
				}
			}
			if result.NextCursor == nil {
				if result.Status != "complete" || result.Collections != (ghapi.FeedbackCollections{Reviews: "complete", DiscussionComments: "complete", Threads: "complete"}) {
					t.Fatal("false partial")
				}
				break
			}
			if result.Status != "partial" || page > 4 {
				t.Fatal("traversal failed to progress")
			}
			args.Cursor = *result.NextCursor
		}
		if strings.Join(ids, ",") != "review:101,discussion:201,inline:301,inline:302" {
			t.Fatal("missing or repeated records", ids)
		}
	}
}

func TestFeedbackEmptyAndOrphanReply(t *testing.T) {
	for _, orphan := range []bool{false, true} {
		c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
			if r.URL.Query().Get("page") == "" {
				return (fixtureTransport{}).RoundTrip(r)
			}
			rows := []feedbackRow{}
			if orphan && strings.HasSuffix(r.URL.Path, "/pulls/1/comments") {
				data, err := fixtures.ReadFile("testdata/feedback-inline.json")
				if err != nil {
					t.Fatal(err)
				}
				if err := json.Unmarshal(data, &rows); err != nil {
					t.Fatal(err)
				}
				rows = rows[1:]
			}
			return pageResponse(t, rows, ""), nil
		})
		result := feedbackRead(t, paginationReader(t, c, []access.ResourceScope{repository}), ghapi.PRFeedbackArgs{Number: 1, Limit: 50})
		if result.Status != "complete" || result.NextCursor != nil || result.Reviews == nil || result.DiscussionComments == nil || result.Threads == nil {
			t.Fatal("empty semantics")
		}
		if orphan && (len(result.Threads) != 1 || result.Threads[0].RootCommentID != "301" || result.Threads[0].Comments[0].ID != "302") {
			t.Fatal("orphan discarded")
		}
	}
}

func TestFeedbackRefreshReplayAndHead(t *testing.T) {
	head := strings.Repeat("a", 40)
	edited, newer := false, false
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		if r.URL.Query().Get("page") == "" {
			return pageResponse(t, fixturePull(t, 1, "PR", head), ""), nil
		}
		response, err := (fixtureTransport{}).RoundTrip(r)
		if err != nil {
			return nil, err
		}
		if !strings.HasSuffix(r.URL.Path, "/reviews") {
			return response, nil
		}
		var rows []feedbackRow
		if err := json.NewDecoder(response.Body).Decode(&rows); err != nil {
			t.Fatal(err)
		}
		if err := response.Body.Close(); err != nil {
			t.Fatal(err)
		}
		if edited {
			value := "Edited synthetic review"
			rows[0].Body = &value
			rows[0].State = "DISMISSED"
		}
		if newer {
			added := rows[0]
			added.ID = 102
			added.URL = strings.Replace(added.URL, "101", "102", 1)
			rows = append(rows, added)
		}
		return pageResponse(t, rows, ""), nil
	})
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	a := ghapi.PRFeedbackArgs{Number: 1, Limit: 50}
	first := feedbackRead(t, reader, a)
	edited, newer = true, true
	refreshed := feedbackRead(t, reader, a)
	if first.Reviews[0].ID != refreshed.Reviews[0].ID || refreshed.Reviews[0].State != "DISMISSED" || *first.Reviews[0].Body == *refreshed.Reviews[0].Body || len(refreshed.Reviews) != 2 {
		t.Fatal("refresh failed")
	}
	newer = false
	a.Limit = 1
	partial := feedbackRead(t, reader, a)
	a.Cursor = *partial.NextCursor
	second := feedbackRead(t, reader, a)
	replay := feedbackRead(t, reader, a)
	if second.DiscussionComments[0].ID != replay.DiscussionComments[0].ID {
		t.Fatal("replay advanced")
	}
	head = strings.Repeat("b", 40)
	data, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, a, acceptPage)
	if data != nil || access.FailureKind(err) != access.InvalidCursor {
		t.Fatal("head change released data", err)
	}
	a.Cursor = ""
	if feedbackRead(t, reader, a).HeadSHA != head {
		t.Fatal("refresh did not observe new head")
	}
}

func TestFeedbackCapBindingExpiryAndDenial(t *testing.T) {
	calls := 0
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		calls++
		if r.URL.Query().Get("page") == "" {
			return (fixtureTransport{}).RoundTrip(r)
		}
		var rows []feedbackRow
		data, err := fixtures.ReadFile("testdata/feedback-reviews.json")
		if err != nil {
			t.Fatal(err)
		}
		if err := json.Unmarshal(data, &rows); err != nil {
			t.Fatal(err)
		}
		row := rows[0]
		rows = nil
		size, _ := strconv.Atoi(r.URL.Query().Get("per_page"))
		for i := 0; i < size; i++ {
			row.ID = int64(i + 1)
			rows = append(rows, row)
		}
		u := *r.URL
		q := u.Query()
		page, _ := strconv.Atoi(q.Get("page"))
		q.Set("page", strconv.Itoa(page+1))
		u.RawQuery = q.Encode()
		return pageResponse(t, rows, u.String()), nil
	})
	now := time.Now()
	codec, err := cursor.New()
	if err != nil {
		t.Fatal(err)
	}
	c.pages, err = access.NewContinuations(codec, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	for _, size := range []int{1, 50} {
		a := ghapi.PRFeedbackArgs{Number: 1, Limit: size}
		var initial string
		for i := 0; i < limits.TraversalPages; i++ {
			p := feedbackRead(t, reader, a)
			if p.NextCursor == nil || len(p.Reviews) != size || p.Collections.Threads != "pending" {
				t.Fatal("lost partial page")
			}
			if i == limits.TraversalPages-1 && p.Status != "limited" {
				t.Fatal("cap not explicit")
			}
			a.Cursor = *p.NextCursor
			if i == 0 {
				initial = a.Cursor
			}
		}
		before := calls
		if _, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, a, acceptPage); access.FailureKind(err) != access.LimitExceeded || calls != before {
			t.Fatal("terminal fetched", err)
		}
		denied := paginationReader(t, c, nil)
		if _, err := readPage(context.Background(), t, denied, ghapi.PRFeedback.Name, a, acceptPage); access.FailureKind(err) != access.PolicyDenied || calls != before {
			t.Fatal("denial precedence", err)
		}
		a.Cursor = initial
		a.Number = 2
		if _, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, a, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls != before {
			t.Fatal("binding", err)
		}
		a.Number = 1
		now = now.Add(limits.CursorLifetime)
		if _, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, a, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls != before {
			t.Fatal("expiry", err)
		}
	}
}

func TestFeedbackRejectsMalformedProviderPages(t *testing.T) {
	for _, fault := range []string{"null", "object", "missing-id", "wrong-pr", "wrong-url", "bad-time", "bad-sha", "duplicate", "oversize", "invalid-json", "invalid-utf8", "reply-self", "bad-line"} {
		t.Run(fault, func(t *testing.T) {
			c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
				if r.URL.Query().Get("page") == "" {
					return (fixtureTransport{}).RoundTrip(r)
				}
				if !strings.HasSuffix(r.URL.Path, "/pulls/1/comments") {
					return pageResponse(t, []feedbackRow{}, ""), nil
				}
				data, err := fixtures.ReadFile("testdata/feedback-inline.json")
				if err != nil {
					t.Fatal(err)
				}
				var rows []feedbackRow
				if err := json.Unmarshal(data, &rows); err != nil {
					t.Fatal(err)
				}
				switch fault {
				case "null":
					return pageResponse(t, nil, ""), nil
				case "object":
					return pageResponse(t, map[string]any{}, ""), nil
				case "missing-id":
					rows[0].ID = 0
				case "wrong-pr":
					rows[0].PullURL = "https://api.github.com/repos/company/project/pulls/2"
				case "wrong-url":
					rows[0].URL = "https://github.com/other/project/pull/1#discussion_r301"
				case "bad-time":
					rows[0].UpdatedAt = "yesterday"
				case "bad-sha":
					bad := "unknown"
					rows[0].CommitID = &bad
				case "duplicate":
					rows[1].ID = rows[0].ID
				case "oversize":
					rows = append(rows, rows...)
				case "reply-self":
					rows[0].InReplyToID = &rows[0].ID
				case "bad-line":
					bad := int64(-1)
					rows[0].Line = &bad
				case "invalid-json", "invalid-utf8":
					raw := "not json"
					if fault == "invalid-utf8" {
						raw = "[\"" + string([]byte{255}) + "\"]"
					}
					return &http.Response{StatusCode: 200, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(raw))}, nil
				}
				return pageResponse(t, rows, ""), nil
			})
			reader := paginationReader(t, c, []access.ResourceScope{repository})
			data, err := readPage(context.Background(), t, reader, ghapi.PRFeedback.Name, ghapi.PRFeedbackArgs{Number: 1, Limit: 2}, acceptPage)
			if data != nil || err == nil || strings.Contains(err.Error(), "Synthetic") {
				t.Fatal("malformed provider output escaped", err)
			}
		})
	}
}

func TestFeedbackWrongPRIdentity(t *testing.T) {
	calls := 0
	c := feedbackClient(t, func(*http.Request) (*http.Response, error) {
		calls++
		p := fixturePull(t, 2, "PR", strings.Repeat("a", 40))
		return pageResponse(t, p, ""), nil
	})
	data, err := readPage(context.Background(), t, paginationReader(t, c, []access.ResourceScope{repository}), ghapi.PRFeedback.Name, ghapi.PRFeedbackArgs{Number: 1, Limit: 50}, acceptPage)
	if data != nil || access.FailureKind(err) != access.PolicyDenied || calls != 1 {
		t.Fatal("lookup provenance failed", err)
	}
}

// Keep protocol errors safe when a source fails after earlier sources succeeded.
func TestFeedbackSourceFailureIsNotEmptySuccess(t *testing.T) {
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		if strings.Contains(r.URL.Path, "/issues/") {
			return &http.Response{StatusCode: 403, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("synthetic-secret-body"))}, nil
		}
		return (fixtureTransport{}).RoundTrip(r)
	})
	data, err := readPage(context.Background(), t, paginationReader(t, c, []access.ResourceScope{repository}), ghapi.PRFeedback.Name, ghapi.PRFeedbackArgs{Number: 1, Limit: 50}, acceptPage)
	if data != nil || access.FailureKind(err) != access.UpstreamAuthorization || strings.Contains(err.Error(), "synthetic-secret-body") {
		t.Fatal("unsafe partial failure", err)
	}
}

func TestFeedbackUnavailableReviewMetadataAndVerbatimBody(t *testing.T) {
	body := "Synthetic Markdown\n\t`code` <tag> 🌱\n"
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		if r.URL.Query().Get("page") == "" {
			return (fixtureTransport{}).RoundTrip(r)
		}
		rows := []feedbackRow{}
		if strings.HasSuffix(r.URL.Path, "/reviews") {
			data, err := fixtures.ReadFile("testdata/feedback-reviews.json")
			if err != nil {
				t.Fatal(err)
			}
			if err := json.Unmarshal(data, &rows); err != nil {
				t.Fatal(err)
			}
			rows[0].User, rows[0].SubmittedAt, rows[0].CommitID = nil, nil, nil
			rows[0].Body = &body
		}
		return pageResponse(t, rows, ""), nil
	})
	p := feedbackRead(t, paginationReader(t, c, []access.ResourceScope{repository}), ghapi.PRFeedbackArgs{Number: 1, Limit: 50})
	review := p.Reviews[0]
	if review.Author != nil || review.SubmittedAt != nil || review.CommitID != nil || review.UpdatedAt != nil || review.Body == nil || *review.Body != body {
		t.Fatal("unknown metadata or body changed")
	}
}

func TestFeedbackEmptyIntermediatePageAndNewReplyOnRefresh(t *testing.T) {
	newer := false
	c := feedbackClient(t, func(r *http.Request) (*http.Response, error) {
		if r.URL.Query().Get("page") == "" {
			return (fixtureTransport{}).RoundTrip(r)
		}
		if strings.HasSuffix(r.URL.Path, "/reviews") && r.URL.Query().Get("page") == "1" {
			u := *r.URL
			q := u.Query()
			q.Set("page", "2")
			u.RawQuery = q.Encode()
			return pageResponse(t, []feedbackRow{}, u.String()), nil
		}
		if strings.HasSuffix(r.URL.Path, "/pulls/1/comments") {
			var rows []feedbackRow
			data, err := fixtures.ReadFile("testdata/feedback-inline.json")
			if err != nil {
				t.Fatal(err)
			}
			if err := json.Unmarshal(data, &rows); err != nil {
				t.Fatal(err)
			}
			if newer {
				row := rows[1]
				row.ID = 303
				row.URL = strings.Replace(row.URL, "302", "303", 1)
				rows = append(rows, row)
			}
			return pageResponse(t, rows, ""), nil
		}
		return pageResponse(t, []feedbackRow{}, ""), nil
	})
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	for _, want := range []int{2, 3} {
		a := ghapi.PRFeedbackArgs{Number: 1, Limit: 50}
		p := feedbackRead(t, reader, a)
		if p.ItemCount() != 0 || p.NextCursor == nil || p.Status != "partial" || p.Collections.Reviews != "partial" || p.Collections.Threads != "pending" {
			t.Fatal("empty page falsely complete")
		}
		a.Cursor = *p.NextCursor
		p = feedbackRead(t, reader, a)
		if p.Status != "complete" || len(p.Threads) != 1 || len(p.Threads[0].Comments) != want || p.Threads[0].RootCommentID != "301" {
			t.Fatal("new reply lost on refresh")
		}
		newer = true
	}
}
