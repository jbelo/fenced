// Package github implements the GitHub integration and synthetic reads.
package github
