package github

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/provider"
	"agent-gateway/internal/providers/github/contract"
	"encoding/json"
	"errors"
	"strings"
)

// Config describes operator-supplied runtime configuration.
type Config struct {
	Enabled   *bool  `json:"enabled"`
	TokenFile string `json:"token_file,omitempty"`
}

// Validate checks the configuration constraints before runtime initialization.
func (c Config) Validate(requireCredential bool) error {
	if c.Enabled == nil {
		return errors.New("missing GitHub configuration")
	}
	if c.TokenFile != "" && c.TokenFile != "/run/secrets/github_token" {
		return errors.New("invalid GitHub token path")
	}
	if requireCredential && *c.Enabled && c.TokenFile == "" {
		return errors.New("missing GitHub token path")
	}
	return nil
}

// Targets validates provider policy entries and produces canonical target identities.
func (c Config) Targets(entries []contract.RepositoryTarget) ([]operation.Target, error) {
	if entries == nil || c.Enabled == nil {
		return nil, errors.New("missing repository policy")
	}
	out := []operation.Target{}
	seen := map[operation.Target]bool{}
	for _, entry := range entries {
		target, err := contract.Target(entry.Repo)
		if err != nil || seen[target] || !*c.Enabled {
			return nil, errors.New("invalid, duplicate or disabled repository target")
		}
		seen[target] = true
		out = append(out, target)
	}
	return out, nil
}

// New returns the statically registered GitHub integration.
func New() provider.Provider { return registration{} }

type registration struct{}

func (registration) Name() string { return "github" }
func (registration) Definitions() []operation.Descriptor {
	return []operation.Descriptor{contract.PRList.Describe(), contract.PRView.Describe(), contract.PRDiff.Describe(), contract.PRChecks.Describe(), contract.PRFeedback.Describe()}
}

func (registration) Configure(raw json.RawMessage, rt provider.Runtime) (provider.Instance, error) {
	var c Config
	if protocol.DecodeStrict(raw, &c) != nil {
		return nil, errors.New("invalid GitHub configuration")
	}
	if err := c.Validate(rt.ReadSecret != nil); err != nil {
		return nil, err
	}
	instance := &configured{config: c}
	if !*c.Enabled {
		return instance, nil
	}
	token := ""
	if rt.ReadSecret != nil {
		data, err := rt.ReadSecret(c.TokenFile)
		if err != nil {
			return nil, err
		}
		token = strings.TrimSpace(string(data))
		if token == "" || strings.ContainsAny(token, "\r\n\t ") {
			return nil, errors.New("invalid GitHub credential")
		}
	}
	reader, err := newClient(rt.Continuations, token, rt.Transport)
	if err != nil {
		return nil, err
	}
	instance.bindings = Operations(reader)
	return instance, nil
}

type configured struct {
	config   Config
	bindings []operation.Binding
}

func (c *configured) Targets(raw json.RawMessage) ([]operation.Target, error) {
	var entries []contract.RepositoryTarget
	if protocol.DecodeStrict(raw, &entries) != nil {
		return nil, errors.New("invalid GitHub policy")
	}
	return c.config.Targets(entries)
}
func (c *configured) Operations() []operation.Binding { return c.bindings }

// FixtureReader runs the real adapter against the synthetic HTTP transport.
func FixtureReader() Reader {
	reader, _ := newClient(fixtureContinuations(), "", fixtureTransport{})
	return reader
}
