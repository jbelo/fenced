package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"agent-gateway/internal/upstream"
	"context"
	"encoding/json"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
)

type (
	client struct {
		http  *upstream.Client
		pages *access.Continuations
	}
	pullRequest struct {
		Number int64  `json:"number"`
		Title  string `json:"title"`
		State  string `json:"state"`
		Draft  bool   `json:"draft"`
		User   *struct {
			Login string `json:"login"`
		} `json:"user"`
		URL       string  `json:"html_url"`
		UpdatedAt string  `json:"updated_at"`
		Body      *string `json:"body"`
		Merged    bool    `json:"merged"`
		Base      struct {
			Ref  string `json:"ref"`
			Repo struct {
				FullName string `json:"full_name"`
			} `json:"repo"`
		} `json:"base"`
		Head struct {
			Ref string `json:"ref"`
			SHA string `json:"sha"`
		} `json:"head"`
	}
)

func newClient(pages *access.Continuations, token string, transport http.RoundTripper) (*client, error) {
	if pages == nil {
		return nil, protocol.Fail(protocol.InternalError)
	}
	h := http.Header{"X-Github-Api-Version": []string{"2026-03-10"}}
	if token != "" {
		h.Set("Authorization", "Bearer "+token)
	}
	c, err := upstream.New("https://api.github.com", h, transport)
	if err != nil {
		return nil, err
	}
	return &client{http: c, pages: pages}, nil
}

func (c *client) get(ctx context.Context, budget *access.Budget, path string, q url.Values, out any) error {
	body, _, err := c.http.Get(ctx, budget, path, q, "application/vnd.github+json")
	if err != nil {
		return err
	}
	if json.Unmarshal(body, out) != nil {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	return nil
}

// validPullURL checks URL provenance without treating repository spelling as identity.
func validPullURL(raw, repo string, number int64) bool {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" || u.Host != "github.com" || u.User != nil || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.RawPath != "" {
		return false
	}
	parts := strings.Split(u.Path, "/")
	return len(parts) == 5 && parts[0] == "" && sameRepository(repo, parts[1]+"/"+parts[2]) && parts[3] == "pull" && parts[4] == strconv.FormatInt(number, 10)
}

func (p pullRequest) summary(repo string) (ghapi.PRSummary, error) {
	canonical, err := ghapi.CanonicalRepository(p.Base.Repo.FullName)
	if err != nil || canonical != repo || p.Number < 1 || !validPullURL(p.URL, repo, p.Number) {
		return ghapi.PRSummary{}, protocol.Fail(protocol.PolicyDenied)
	}
	var author *string
	if p.User != nil {
		author = &p.User.Login
	}
	return ghapi.PRSummary{Number: p.Number, Repo: canonical, Title: p.Title, State: p.State, Draft: p.Draft, Author: author, URL: p.URL, UpdatedAt: p.UpdatedAt}, nil
}

func (c *client) ViewPR(ctx context.Context, budget *access.Budget, repo string, n int64) (ghapi.PRDetail, error) {
	var p pullRequest
	if err := c.get(ctx, budget, "/repos/"+repo+"/pulls/"+strconv.FormatInt(n, 10), nil, &p); err != nil {
		return ghapi.PRDetail{}, err
	}
	summary, err := p.summary(repo)
	if err != nil {
		return ghapi.PRDetail{}, err
	}
	if p.Number != n {
		return ghapi.PRDetail{}, protocol.Fail(protocol.PolicyDenied)
	}
	body := ""
	if p.Body != nil {
		body = *p.Body
	}
	return ghapi.PRDetail{PRSummary: summary, Body: body, Merged: p.Merged, BaseRef: p.Base.Ref, HeadRef: p.Head.Ref, HeadSHA: p.Head.SHA}, nil
}

func (c *client) DiffPR(ctx context.Context, budget *access.Budget, repo string, n int64) (DiffResult, error) {
	pr, err := c.ViewPR(ctx, budget, repo, n)
	if err != nil {
		return DiffResult{}, err
	}
	data, _, err := c.http.Get(ctx, budget, "/repos/"+repo+"/pulls/"+strconv.FormatInt(n, 10), nil, "application/vnd.github.diff")
	if err != nil {
		return DiffResult{}, err
	}
	if len(data) > limits.DiffBytes {
		return DiffResult{}, protocol.Fail(protocol.LimitExceeded)
	}
	return DiffResult{Diff: ghapi.Diff{Repo: pr.Repo, Number: pr.Number, Text: string(data)}, Identity: identity(pr)}, nil
}

var shaPattern = regexp.MustCompile(`^[a-fA-F0-9]{40}$`)
