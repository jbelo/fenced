package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"bytes"
	"embed"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"
)

//go:embed testdata/*
var fixtures embed.FS

type fixtureTransport struct{}

func (fixtureTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	status := http.StatusOK
	var data []byte
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if r.Method != http.MethodGet || r.URL.Host != "api.github.com" || len(parts) < 4 || parts[0] != "repos" {
		status = http.StatusNotFound
	} else {
		switch parts[3] {
		case "pulls":
			data, _ = fixtures.ReadFile("testdata/pull.json")
			var pr pullRequest
			_ = json.Unmarshal(data, &pr)
			repo := parts[1] + "/" + parts[2]
			pr.Base.Repo.FullName = repo
			if len(parts) > 4 {
				pr.Number, _ = strconv.ParseInt(parts[4], 10, 64)
			}
			pr.URL = "https://github.com/" + repo + "/pull/" + strconv.FormatInt(pr.Number, 10)
			if state := r.URL.Query().Get("state"); state != "" && state != "all" {
				pr.State = state
			}
			switch {
			case len(parts) == 6 && (parts[5] == "reviews" || parts[5] == "comments"):
				return feedbackFixture(r, parts)
			case r.Header.Get("Accept") == "application/vnd.github.diff":
				data = []byte("--- a/example\n+++ b/example\n@@ -1 +1 @@\n-old\n+new\n")
			case len(parts) == 4:
				data, _ = json.Marshal([]pullRequest{pr})
			default:
				data, _ = json.Marshal(pr)
			}
		case "issues":
			if len(parts) == 6 && parts[5] == "comments" {
				return feedbackFixture(r, parts)
			}
			status = http.StatusNotFound
		case "commits":
			switch {
			case len(parts) == 6 && parts[5] == "check-runs":
				data, _ = fixtures.ReadFile("testdata/checks.json")
			case len(parts) == 6 && parts[5] == "status":
				data = []byte(`{"statuses":[]}`)
			default:
				status = http.StatusNotFound
			}
		default:
			status = http.StatusNotFound
		}
	}
	return &http.Response{StatusCode: status, Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(data)), Request: r}, nil
}

// Fixture supplies optional mock transport to executable assembly.
func (registration) Fixture() http.RoundTripper { return fixtureTransport{} }

// FixtureReader's standalone test assembly owns its own key; runtime assembly shares one.
func fixtureContinuations() *access.Continuations {
	codec, err := cursor.New()
	if err != nil {
		panic(err)
	}
	pages, err := access.NewContinuations(codec, time.Now)
	if err != nil {
		panic(err)
	}
	return pages
}

// feedbackFixture paginates synthetic upstream rows through the real adapter.
func feedbackFixture(r *http.Request, parts []string) (*http.Response, error) {
	name := "inline"
	if parts[3] == "issues" {
		name = "discussion"
	} else if parts[5] == "reviews" {
		name = "reviews"
	}
	data, err := fixtures.ReadFile("testdata/feedback-" + name + ".json")
	if err != nil {
		return nil, err
	}
	repo, number := parts[1]+"/"+parts[2], parts[4]
	data = bytes.ReplaceAll(data, []byte("company/project"), []byte(repo))
	data = bytes.ReplaceAll(data, []byte("/pull/1#"), []byte("/pull/"+number+"#"))
	data = bytes.ReplaceAll(data, []byte("/pulls/1\""), []byte("/pulls/"+number+"\""))
	data = bytes.ReplaceAll(data, []byte("/issues/1\""), []byte("/issues/"+number+"\""))
	var rows []json.RawMessage
	if err := json.Unmarshal(data, &rows); err != nil {
		return nil, err
	}
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	size, _ := strconv.Atoi(r.URL.Query().Get("per_page"))
	start := min(max(page-1, 0)*size, len(rows))
	end := min(start+size, len(rows))
	headers := make(http.Header)
	if end < len(rows) {
		u := *r.URL
		q := u.Query()
		q.Set("page", strconv.Itoa(page+1))
		u.RawQuery = q.Encode()
		headers.Set("Link", "<"+u.String()+">; rel=\"next\"")
	}
	data, err = json.Marshal(rows[start:end])
	if err != nil {
		return nil, err
	}
	return &http.Response{StatusCode: http.StatusOK, Header: headers, Body: io.NopCloser(bytes.NewReader(data)), Request: r}, nil
}
