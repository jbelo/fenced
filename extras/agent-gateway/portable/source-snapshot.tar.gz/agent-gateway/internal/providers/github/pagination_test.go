package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"testing"
	"time"
)

var repository = access.ResourceScope{Provider: "github", Kind: "repository", Key: "company/project"}

func pageResponse(t *testing.T, value any, next string) *http.Response {
	t.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	h := make(http.Header)
	if next != "" {
		h.Set("Link", "<"+next+">; rel=\"next\"")
	}
	return &http.Response{StatusCode: 200, Header: h, Body: io.NopCloser(strings.NewReader(string(data)))}
}

func fixturePull(t *testing.T, number int64, title, head string) pullRequest {
	t.Helper()
	data, err := fixtures.ReadFile("testdata/pull.json")
	if err != nil {
		t.Fatal(err)
	}
	var p pullRequest
	if err := json.Unmarshal(data, &p); err != nil {
		t.Fatal(err)
	}
	p.Number = number
	p.Title = title
	p.Base.Repo.FullName = repository.Key
	p.URL = "https://github.com/" + repository.Key + "/pull/" + strconv.FormatInt(number, 10)
	p.Head.SHA = head
	return p
}

func paginationReader(t *testing.T, c *client, policy []access.ResourceScope) *access.Reader {
	t.Helper()
	ops := []access.Operation{}
	for _, b := range Operations(c) {
		ops = append(ops, b.Core())
	}
	r, err := access.New(policy, ops)
	if err != nil {
		t.Fatal(err)
	}
	return r
}

func readPage(ctx context.Context, t *testing.T, r *access.Reader, name string, args any, fit func(any) error) (any, error) {
	t.Helper()
	p, err := r.Admit(ctx)
	if err != nil {
		return nil, err
	}
	defer p.Release()
	data, _, err := r.Read(p, access.Request{Operation: name, Target: repository, Args: args}, fit)
	return data, err
}
func acceptPage(any) error { return nil }

func TestListTraversalThroughRead(t *testing.T) {
	now := time.Date(2026, 10, 27, 9, 0, 0, 0, time.UTC)
	codec, err := cursor.New()
	if err != nil {
		t.Fatal(err)
	}
	pages, err := access.NewContinuations(codec, func() time.Time { return now })
	if err != nil {
		t.Fatal(err)
	}
	calls := 0
	title := "before"
	c, err := newClient(pages, "", testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.URL.Path != "/repos/company/project/pulls" {
			t.Fatal("followed provider path", r.URL.Path)
		}
		page, _ := strconv.Atoi(r.URL.Query().Get("page"))
		next := ""
		if page < 3 {
			u := *r.URL
			q := u.Query()
			q.Set("page", strconv.Itoa(page+1))
			u.RawQuery = q.Encode()
			next = u.String()
		}
		response := pageResponse(t, []pullRequest{fixturePull(t, int64(page), title, strings.Repeat("a", 40))}, next)
		if page == 1 {
			header, err := fixtures.ReadFile("testdata/pagination-link.txt")
			if err != nil {
				t.Fatal(err)
			}
			response.Header.Set("Link", strings.TrimSpace(string(header)))
		}
		return response, nil
	}))
	if err != nil {
		t.Fatal(err)
	}
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	args := ghapi.PRListArgs{State: "open", Limit: 1}
	data, err := readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage)
	if err != nil {
		t.Fatal(err)
	}
	first := data.(protocol.Page[ghapi.PRSummary])
	if first.NextCursor == nil {
		t.Fatal("missing next")
	}
	args.Cursor = *first.NextCursor
	data, err = readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage)
	if err != nil {
		t.Fatal(err)
	}
	second := data.(protocol.Page[ghapi.PRSummary])
	title = "after"
	data, err = readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage)
	if err != nil {
		t.Fatal(err)
	}
	replay := data.(protocol.Page[ghapi.PRSummary])
	if replay.Items[0].Number != second.Items[0].Number || replay.Items[0].Title != "after" {
		t.Fatal("cached or advanced replay")
	}
	before := calls
	changed := args
	changed.Limit = 2
	if _, err := readPage(context.Background(), t, reader, "github.pr.list", changed, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls != before {
		t.Fatal("argument binding", err)
	}
	changedPolicy := paginationReader(t, c, []access.ResourceScope{repository, {Provider: "github", Kind: "repository", Key: "other/repo"}})
	if _, err := readPage(context.Background(), t, changedPolicy, "github.pr.list", args, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls != before {
		t.Fatal("policy binding", err)
	}
	args.Cursor = *replay.NextCursor
	data, err = readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage)
	if err != nil || data.(protocol.Page[ghapi.PRSummary]).NextCursor != nil {
		t.Fatal("exhaustion", err)
	}
	args.Cursor = *first.NextCursor
	data, err = readPage(context.Background(), t, reader, "github.pr.list", args, func(any) error { return access.Fail(access.LimitExceeded) })
	if data != nil || access.FailureKind(err) != access.LimitExceeded {
		t.Fatal("fit released page", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	data, err = readPage(ctx, t, reader, "github.pr.list", args, func(any) error { cancel(); return nil })
	if data != nil || access.FailureKind(err) != access.Timeout {
		t.Fatal("deadline released page", err)
	}
	now = now.Add(limits.CursorLifetime)
	before = calls
	if _, err := readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls != before {
		t.Fatal("expiry", err)
	}
}

func TestListCapAndAuthorizationBeforeTerminal(t *testing.T) {
	calls := 0
	c, err := newClient(fixtureContinuations(), "", testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		page, _ := strconv.Atoi(r.URL.Query().Get("page"))
		rows := []pullRequest{}
		for i := 0; i < 50; i++ {
			rows = append(rows, fixturePull(t, int64((page-1)*50+i+1), "PR", strings.Repeat("a", 40)))
		}
		u := *r.URL
		q := u.Query()
		q.Set("page", strconv.Itoa(page+1))
		u.RawQuery = q.Encode()
		return pageResponse(t, rows, u.String()), nil
	}))
	if err != nil {
		t.Fatal(err)
	}
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	args := ghapi.PRListArgs{State: "open", Limit: 50}
	for range 10 {
		before := calls
		data, err := readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage)
		if err != nil {
			t.Fatal(err)
		}
		page := data.(protocol.Page[ghapi.PRSummary])
		if len(page.Items) != 50 || page.NextCursor == nil || calls-before != 1 {
			t.Fatal("lost cap page or fetch bound")
		}
		args.Cursor = *page.NextCursor
	}
	before := calls
	if _, err := readPage(context.Background(), t, reader, "github.pr.list", args, acceptPage); access.FailureKind(err) != access.LimitExceeded || calls != before {
		t.Fatal("terminal fetched", err)
	}
	denied := paginationReader(t, c, nil)
	for _, token := range []string{args.Cursor, "malformed"} {
		a := args
		a.Cursor = token
		if _, err := readPage(context.Background(), t, denied, "github.pr.list", a, acceptPage); access.FailureKind(err) != access.PolicyDenied || calls != before {
			t.Fatal("cursor oracle before authorization", err)
		}
	}
}

func TestChecksPartialSourceAndHeadInvalidation(t *testing.T) {
	head := strings.Repeat("a", 40)
	calls := 0
	c, err := newClient(fixtureContinuations(), "", testTransport(func(r *http.Request) (*http.Response, error) {
		calls++
		switch {
		case strings.Contains(r.URL.Path, "/pulls/"):
			return pageResponse(t, fixturePull(t, 1, "PR", head), ""), nil
		case strings.HasSuffix(r.URL.Path, "/check-runs"):
			return pageResponse(t, map[string]any{"check_runs": []any{map[string]any{"id": 1, "name": "run", "status": "completed"}}}, ""), nil
		default:
			page := r.URL.Query().Get("page")
			ids := []int{2, 3}
			next := ""
			if page == "1" {
				u := *r.URL
				q := u.Query()
				q.Set("page", "2")
				u.RawQuery = q.Encode()
				next = u.String()
			} else {
				ids = []int{4}
			}
			rows := []any{}
			for _, id := range ids {
				rows = append(rows, map[string]any{"id": id, "context": "status", "state": "success"})
			}
			return pageResponse(t, map[string]any{"statuses": rows}, next), nil
		}
	}))
	if err != nil {
		t.Fatal(err)
	}
	reader := paginationReader(t, c, []access.ResourceScope{repository})
	args := ghapi.PRChecksArgs{Number: 1, Limit: 2}
	ids := []string{}
	var first string
	for i := 0; i < 3; i++ {
		before := calls
		data, err := readPage(context.Background(), t, reader, "github.pr.checks", args, acceptPage)
		if err != nil {
			t.Fatal(err)
		}
		page := data.(ghapi.CheckPage)
		for _, item := range page.Items {
			ids = append(ids, item.ID)
		}
		if calls-before > 3 {
			t.Fatal("checks fetch bound")
		}
		if i < 2 {
			if page.NextCursor == nil {
				t.Fatal("lost continuation")
			}
			args.Cursor = *page.NextCursor
			if i == 0 {
				first = args.Cursor
			}
		} else if page.NextCursor != nil {
			t.Fatal("false continuation")
		}
	}
	if strings.Join(ids, ",") != "1,2,3,4" {
		t.Fatal(ids)
	}
	head = strings.Repeat("b", 40)
	args.Cursor = first
	before := calls
	if _, err := readPage(context.Background(), t, reader, "github.pr.checks", args, acceptPage); access.FailureKind(err) != access.InvalidCursor || calls-before != 1 {
		t.Fatal("head invalidation", err)
	}
}

func TestPaginationLinkValidation(t *testing.T) {
	q := url.Values{"page": {"1"}, "per_page": {"2"}, "state": {"open"}}
	for _, link := range []string{
		"https://api.github.com/repositories/1300192/issues?page=2", "https://api.github.com/repositories/not-a-number/pulls?page=2", "https://api.github.com/repositories/0/pulls?page=2", "http://api.github.com/repos/company/project/pulls?page=2", "https://evil.example/repos/company/project/pulls?page=2",
		"https://api.github.com/repos/other/repo/pulls?page=2", "https://api.github.com/repos/company/project/pulls?page=3",
		"https://api.github.com/repos/company/project/pulls?page=2&state=closed", "https://api.github.com/repos/company/project/pulls?page=2&page=3",
		"https://api.github.com/repos/company/project/pulls?page=2&token=secret",
	} {
		if _, err := nextPage([]string{"<" + link + ">; rel=\"next\""}, "/repos/company/project/pulls", q); err == nil {
			t.Fatal("unsafe next accepted", link)
		}
	}
}

func TestListRejectsProviderPageBeyondRequestedLimit(t *testing.T) {
	c, err := newClient(fixtureContinuations(), "", testTransport(func(*http.Request) (*http.Response, error) {
		return pageResponse(t, []pullRequest{fixturePull(t, 1, "one", strings.Repeat("a", 40)), fixturePull(t, 2, "two", strings.Repeat("a", 40))}, ""), nil
	}))
	if err != nil {
		t.Fatal(err)
	}
	r := paginationReader(t, c, []access.ResourceScope{repository})
	data, err := readPage(context.Background(), t, r, "github.pr.list", ghapi.PRListArgs{State: "open", Limit: 1}, acceptPage)
	if data != nil || access.FailureKind(err) != access.LimitExceeded {
		t.Fatal("released oversized page", err)
	}
}

func TestRepositoryIDLinkForms(t *testing.T) {
	for _, suffix := range []string{"pulls", "commits/" + strings.Repeat("a", 40) + "/check-runs", "commits/" + strings.Repeat("a", 40) + "/status"} {
		requested := "/repos/company/project/" + suffix
		for _, path := range []string{"/repositories/1300192/" + suffix, "/repos/Company/Project/" + suffix} {
			header := "<https://api.github.com" + path + "?page=2>; rel=\"next\""
			page, err := nextPage([]string{header}, requested, url.Values{"page": {"1"}})
			if err != nil || page != 2 {
				t.Fatal(path, page, err)
			}
		}
	}
}
