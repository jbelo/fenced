package contract

import (
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
)

// PRFeedbackArgs selects a PR and a bounded feedback traversal.
type PRFeedbackArgs struct {
	Number int64  `json:"number"`
	Limit  int    `json:"limit"`
	Cursor string `json:"cursor,omitempty"`
}

// PRFeedback is the additive read-only feedback contract.
var PRFeedback = operation.Definition[PRFeedbackArgs]{Name: "github.pr.feedback", ScopeKind: "repository", Target: repositoryTarget, NormalizeTarget: normalizeTarget, NormalizeArgs: normalizePRFeedback, Audit: auditTarget, Arguments: func(raw json.RawMessage) (PRFeedbackArgs, error) {
	a := PRFeedbackArgs{Limit: limits.DefaultPageItems}
	if protocol.DecodeStrict(raw, &a) != nil {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return normalizePRFeedback(a)
}}

func normalizePRFeedback(a PRFeedbackArgs) (PRFeedbackArgs, error) {
	if !protocol.ValidID(a.Number) {
		return a, protocol.Fail(protocol.InvalidInput)
	}
	return a, protocol.ValidatePage(a.Limit, a.Cursor)
}

// FeedbackEntry contains common feedback fields; null means unavailable.
type FeedbackEntry struct {
	ID     string  `json:"id"`
	Author *string `json:"author"`
	Body   *string `json:"body"`
	URL    string  `json:"url"`
}

// Review is a review submission, separate from its individual comments.
type Review struct {
	FeedbackEntry
	State       string  `json:"state"`
	SubmittedAt *string `json:"submitted_at"`
	UpdatedAt   *string `json:"updated_at"`
	CommitID    *string `json:"commit_id"`
}

// DiscussionComment is a general PR discussion comment.
type DiscussionComment struct {
	FeedbackEntry
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

// InlineComment preserves review association, reply linkage and diff context.
type InlineComment struct {
	DiscussionComment
	ReviewID          *string `json:"review_id"`
	InReplyToID       *string `json:"in_reply_to_id"`
	Path              string  `json:"path"`
	DiffHunk          *string `json:"diff_hunk"`
	CommitID          string  `json:"commit_id"`
	OriginalCommitID  string  `json:"original_commit_id"`
	Line              *int64  `json:"line"`
	OriginalLine      *int64  `json:"original_line"`
	StartLine         *int64  `json:"start_line"`
	OriginalStartLine *int64  `json:"original_start_line"`
	Side              *string `json:"side"`
	StartSide         *string `json:"start_side"`
	SubjectType       *string `json:"subject_type"`
}

// ReviewThread is a page fragment, joined across pages by RootCommentID.
type ReviewThread struct {
	RootCommentID string          `json:"root_comment_id"`
	Resolved      *bool           `json:"resolved"`
	Outdated      *bool           `json:"outdated"`
	Comments      []InlineComment `json:"comments"`
}

// FeedbackCollections records cumulative source exhaustion for this traversal.
type FeedbackCollections struct {
	Reviews            string `json:"reviews"`
	DiscussionComments string `json:"discussion_comments"`
	Threads            string `json:"threads"`
}

// FeedbackPage contains bounded observations, never an atomic snapshot.
type FeedbackPage struct {
	Repo               string              `json:"repo"`
	Number             int64               `json:"number"`
	HeadSHA            string              `json:"head_sha"`
	Reviews            []Review            `json:"reviews"`
	DiscussionComments []DiscussionComment `json:"discussion_comments"`
	Threads            []ReviewThread      `json:"threads"`
	Collections        FeedbackCollections `json:"collections"`
	Status             string              `json:"status"`
	NextCursor         *string             `json:"next_cursor"`
}

// ItemCount includes every reply, not just the number of thread fragments.
func (p FeedbackPage) ItemCount() int {
	count := len(p.Reviews) + len(p.DiscussionComments)
	for _, thread := range p.Threads {
		count += len(thread.Comments)
	}
	return count
}
