package github

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"context"
	"encoding/json"
	"net/url"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

// FeedbackResult retains lookup evidence separately from the public page.
type FeedbackResult struct {
	ghapi.FeedbackPage
	Identity PRIdentity
}

func feedbackBinding(reader Reader) operation.Binding {
	return operation.Bind(ghapi.PRFeedback, operation.Handler[ghapi.PRFeedbackArgs, FeedbackResult]{
		Execute: func(ctx context.Context, b *access.Budget, target operation.Target, a ghapi.PRFeedbackArgs) (FeedbackResult, error) {
			return reader.PRFeedback(ctx, b, target.Key, a)
		},
		Validate: func(target operation.Target, a ghapi.PRFeedbackArgs, v FeedbackResult) error {
			if !sameRepository(target.Key, v.Identity.Repository) || v.Identity.Number != a.Number || v.Repo != v.Identity.Repository || v.Number != v.Identity.Number || v.HeadSHA != v.Identity.HeadSHA || !shaPattern.MatchString(v.HeadSHA) {
				return protocol.Fail(protocol.PolicyDenied)
			}
			return nil
		},
		Measure: func(a ghapi.PRFeedbackArgs, v FeedbackResult) operation.Bounds {
			return operation.Bounds{Items: v.ItemCount(), ItemLimit: a.Limit}
		},
		View: func(v FeedbackResult) any { return v.FeedbackPage },
	})
}

// feedbackRow is private provider data, projected explicitly into public views.
type feedbackRow struct {
	ID   int64 `json:"id"`
	User *struct {
		Login string `json:"login"`
	} `json:"user"`
	Body              *string `json:"body"`
	URL               string  `json:"html_url"`
	PullURL           string  `json:"pull_request_url"`
	IssueURL          string  `json:"issue_url"`
	State             string  `json:"state"`
	SubmittedAt       *string `json:"submitted_at"`
	CreatedAt         string  `json:"created_at"`
	UpdatedAt         string  `json:"updated_at"`
	ReviewID          *int64  `json:"pull_request_review_id"`
	InReplyToID       *int64  `json:"in_reply_to_id"`
	Path              string  `json:"path"`
	DiffHunk          *string `json:"diff_hunk"`
	CommitID          *string `json:"commit_id"`
	OriginalCommitID  string  `json:"original_commit_id"`
	Line              *int64  `json:"line"`
	OriginalLine      *int64  `json:"original_line"`
	StartLine         *int64  `json:"start_line"`
	OriginalStartLine *int64  `json:"original_start_line"`
	Side              *string `json:"side"`
	StartSide         *string `json:"start_side"`
	SubjectType       *string `json:"subject_type"`
}

func (c *client) PRFeedback(ctx context.Context, budget *access.Budget, repo string, a ghapi.PRFeedbackArgs) (FeedbackResult, error) {
	out := FeedbackResult{FeedbackPage: ghapi.FeedbackPage{Reviews: []ghapi.Review{}, DiscussionComments: []ghapi.DiscussionComment{}, Threads: []ghapi.ReviewThread{}}}
	token := a.Cursor
	a.Cursor = ""
	state, pos, err := c.resumeSources(budget, ghapi.PRFeedback.Name, repo, token, a, 2)
	if err != nil {
		return out, err
	}
	pr, err := c.ViewPR(ctx, budget, repo, a.Number)
	if err != nil {
		return out, err
	}
	if !shaPattern.MatchString(pr.HeadSHA) {
		return out, protocol.Fail(protocol.UpstreamUnavailable)
	}
	if token != "" && pos.Head != pr.HeadSHA {
		return out, protocol.Fail(protocol.InvalidCursor)
	}
	pos.Head = pr.HeadSHA
	out.Identity = identity(pr)
	out.Repo, out.Number, out.HeadSHA = pr.Repo, pr.Number, pr.HeadSHA
	sources := [3]string{"pending", "pending", "pending"}
	for i := 0; i < pos.Source; i++ {
		sources[i] = "complete"
	}
	for pos.Source < 3 {
		source := pos.Source
		sources[source] = "partial"
		var rows []feedbackRow
		path := "/repos/" + repo + "/pulls/" + strconv.FormatInt(a.Number, 10)
		switch source {
		case 0:
			path += "/reviews"
		case 1:
			path = "/repos/" + repo + "/issues/" + strconv.FormatInt(a.Number, 10) + "/comments"
		case 2:
			path += "/comments"
		}
		q := url.Values{"page": {strconv.Itoa(pos.Page)}, "per_page": {strconv.Itoa(a.Limit)}}
		if source == 2 {
			q.Set("sort", "created")
			q.Set("direction", "asc")
		}
		next, err := c.feedbackRows(ctx, budget, path, q, &rows)
		if err != nil {
			return out, err
		}
		if rows == nil {
			return out, protocol.Fail(protocol.UpstreamUnavailable)
		}
		if len(rows) > a.Limit {
			return out, protocol.Fail(protocol.LimitExceeded)
		}
		offset := min(pos.Offset, len(rows))
		count := min(len(rows)-offset, a.Limit-out.ItemCount(), limits.TraversalItems-state.Items-out.ItemCount())
		// Validate the entire returned page, including a prefix skipped on replay.
		seen := map[int64]bool{}
		for _, row := range rows {
			if err := row.validate(repo, a.Number, source); err != nil {
				return out, err
			}
			if seen[row.ID] {
				return out, protocol.Fail(protocol.UpstreamUnavailable)
			}
			seen[row.ID] = true
		}
		for _, row := range rows[offset : offset+count] {
			out.appendRow(row, source)
		}
		offset += count
		if offset < len(rows) {
			pos.Offset = offset
			break
		}
		if next != 0 {
			pos.Page, pos.Offset = next, 0
			break
		}
		sources[source] = "complete"
		pos.Source++
		pos.Page, pos.Offset = 1, 0
		// Continue through empty sources even at capacity, retaining the first
		// nonempty unconsumed page as an offset if necessary (max four fetches).
	}
	more := pos.Source < 3
	out.Collections = ghapi.FeedbackCollections{Reviews: sources[0], DiscussionComments: sources[1], Threads: sources[2]}
	out.Status = "complete"
	if more {
		out.Status = "partial"
		if state.Pages+1 >= limits.TraversalPages || state.Items+out.ItemCount() >= limits.TraversalItems {
			out.Status = "limited"
		}
	}
	out.NextCursor, err = c.next(state, out.ItemCount(), pos, more)
	return out, err
}

func (r feedbackRow) entry() ghapi.FeedbackEntry {
	var author *string
	if r.User != nil {
		author = &r.User.Login
	}
	return ghapi.FeedbackEntry{ID: strconv.FormatInt(r.ID, 10), Author: author, Body: r.Body, URL: r.URL}
}

func stringID(id *int64) *string {
	if id == nil {
		return nil
	}
	value := strconv.FormatInt(*id, 10)
	return &value
}

func (out *FeedbackResult) appendRow(r feedbackRow, source int) {
	if source == 0 {
		out.Reviews = append(out.Reviews, ghapi.Review{FeedbackEntry: r.entry(), State: r.State, SubmittedAt: r.SubmittedAt, CommitID: r.CommitID})
		return
	}
	comment := ghapi.DiscussionComment{FeedbackEntry: r.entry(), CreatedAt: r.CreatedAt, UpdatedAt: r.UpdatedAt}
	if source == 1 {
		out.DiscussionComments = append(out.DiscussionComments, comment)
		return
	}
	inline := ghapi.InlineComment{DiscussionComment: comment, ReviewID: stringID(r.ReviewID), InReplyToID: stringID(r.InReplyToID), Path: r.Path, DiffHunk: r.DiffHunk, CommitID: *r.CommitID, OriginalCommitID: r.OriginalCommitID, Line: r.Line, OriginalLine: r.OriginalLine, StartLine: r.StartLine, OriginalStartLine: r.OriginalStartLine, Side: r.Side, StartSide: r.StartSide, SubjectType: r.SubjectType}
	root := inline.ID
	if inline.InReplyToID != nil {
		root = *inline.InReplyToID
	}
	for i := range out.Threads {
		if out.Threads[i].RootCommentID == root {
			out.Threads[i].Comments = append(out.Threads[i].Comments, inline)
			return
		}
	}
	out.Threads = append(out.Threads, ghapi.ReviewThread{RootCommentID: root, Comments: []ghapi.InlineComment{inline}})
}

func (r feedbackRow) validate(repo string, number int64, source int) error {
	if !protocol.ValidID(r.ID) || (r.User != nil && r.User.Login == "") {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	if !feedbackHTMLURL(r.URL, repo, number, source) {
		return protocol.Fail(protocol.PolicyDenied)
	}
	kind, resourceURL := "pulls", r.PullURL
	if source == 1 {
		kind, resourceURL = "issues", r.IssueURL
	}
	if !feedbackAPIURL(resourceURL, repo, kind, number) {
		return protocol.Fail(protocol.PolicyDenied)
	}
	if source == 0 {
		if r.State == "" || (r.CommitID != nil && !shaPattern.MatchString(*r.CommitID)) || (r.SubmittedAt != nil && !feedbackTime(*r.SubmittedAt)) {
			return protocol.Fail(protocol.UpstreamUnavailable)
		}
		return nil
	}
	if !feedbackTime(r.CreatedAt) || !feedbackTime(r.UpdatedAt) {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	if source == 1 {
		return nil
	}
	if r.Path == "" || r.CommitID == nil || !shaPattern.MatchString(*r.CommitID) || !shaPattern.MatchString(r.OriginalCommitID) {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	for _, id := range []*int64{r.ReviewID, r.InReplyToID, r.Line, r.OriginalLine, r.StartLine, r.OriginalStartLine} {
		if id != nil && !protocol.ValidID(*id) {
			return protocol.Fail(protocol.UpstreamUnavailable)
		}
	}
	if r.InReplyToID != nil && *r.InReplyToID == r.ID {
		return protocol.Fail(protocol.UpstreamUnavailable)
	}
	for _, side := range []*string{r.Side, r.StartSide} {
		if side != nil && *side != "LEFT" && *side != "RIGHT" {
			return protocol.Fail(protocol.UpstreamUnavailable)
		}
	}
	return nil
}

func feedbackTime(value string) bool {
	t, err := time.Parse(time.RFC3339, value)
	_, offset := t.Zone()
	return err == nil && offset == 0
}

func feedbackAPIURL(raw, repo, kind string, number int64) bool {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" || u.Host != "api.github.com" || u.User != nil || u.RawPath != "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" {
		return false
	}
	parts := strings.Split(u.Path, "/")
	return len(parts) == 6 && parts[0] == "" && parts[1] == "repos" && sameRepository(repo, parts[2]+"/"+parts[3]) && parts[4] == kind && parts[5] == strconv.FormatInt(number, 10)
}

func feedbackHTMLURL(raw, repo string, number int64, source int) bool {
	u, err := url.Parse(raw)
	if err != nil || u.Fragment == "" {
		return false
	}
	u.Fragment, u.RawFragment = "", ""
	// GitHub issue-comment links may use either PR or issue routes.
	if source == 1 {
		u.Path = strings.Replace(u.Path, "/issues/", "/pull/", 1)
	}
	return validPullURL(u.String(), repo, number)
}

func (c *client) feedbackRows(ctx context.Context, budget *access.Budget, path string, q url.Values, rows *[]feedbackRow) (int, error) {
	body, headers, err := c.http.Get(ctx, budget, path, q, "application/vnd.github+json")
	if err != nil {
		return 0, err
	}
	next, err := nextPage(headers.Values("Link"), path, q)
	if err != nil {
		return 0, err
	}
	if !utf8.Valid(body) || json.Unmarshal(body, rows) != nil {
		return 0, protocol.Fail(protocol.UpstreamUnavailable)
	}
	return next, nil
}
