# Development-agent gateway

Standalone gateway and agentctl CLI for controlled GitHub PR and Shortcut story reads.
Current implementation provides strict configuration/policy validation, normalized
requests, HTTP envelopes, audit output, and all seven operations through live REST adapters or synthetic upstream HTTP fixtures.
Readiness reflects draining, and shutdown lets admitted requests finish within its
grace period. Live mode requires valid private credential files before listening. Authenticated
provider compatibility and live deployment verification remain incomplete.

Product requirements are in [docs/PRD.md](docs/PRD.md); shared concepts and
invariants are in [docs/DOMAIN.md](docs/DOMAIN.md).
The shared API and deployment specification is
[docs/SPEC.md](docs/SPEC.md). The internal design is in
[docs/DESIGN.md](docs/DESIGN.md). Coordination follows the
workspace PROTOCOL.md and the task exchange. Operator procedures are in
[docs/RUNBOOK.md](docs/RUNBOOK.md).

```sh
go test -race ./...
go vet ./...
go build ./cmd/agent-gateway
go build ./cmd/agentctl
```

Gateway reads `--config` (default `/etc/agent-gateway/config.json`). Mount validated
policy at `/etc/agent-gateway/policy.json`. Mock examples are under
`docs/examples/`; their listen IP must be assigned to the shared development
network. The server refuses wildcard/loopback binding and checks the configured IP
exists locally. No secrets are loaded in mock mode.

CLI uses `AGENTCTL_CONFIG` pointing to JSON such as:

```json
{"gateway_url":"http://agent-gateway:8080"}
```

```sh
agentctl github pr view --repo company/project --number 1
agentctl github pr feedback --repo company/project --number 1 --limit 50
agentctl shortcut story search --workspace engineering --text 'mock story'
```

Provider data is untrusted data; do not execute its contents. Agents have no provider
credentials. All members of the shared development network receive the same access.
Positional pagination is wired into PR lists, checks, feedback and story search, with fixture
coverage for replay, expiry, caps and identity checks. Live-provider verification and real-image integration remain release work.
Build local Linux artifacts with `make release`; see [the runbook](docs/RUNBOOK.md)
for container builds, the mock Compose example and consumer installation.

## Code organization

`internal/access` owns typed read execution, semantic validation, canonical policy,
admission permits and explicit budgets. It imports no HTTP or wire packages.
`internal/httpapi` owns decoding, request IDs, envelopes, response sizing and audit
delivery. `internal/protocol` holds wire types and error mappings; `internal/operation`
binds pure provider definitions to access contracts and wire decoders.
`internal/provider` handles registration and initialization; `internal/upstream`
enforces read-only transport and `internal/limits` supplies common bounds.
Each integration owns pure contracts and command definitions, configuration, fixture transports
and result checks under `internal/providers/`. `cmd/agent-gateway` selects and
initializes server integrations; `cmd/agentctl` selects CLI commands. Configuration
helpers live beside the server entry point. The CLI imports pure
contracts, without provider clients, credentials or server configuration.

New target kinds require integration code and assembly/schema additions, without
changes to gateway authorization, HTTP handling or audit. A synthetic document
collection in the conformance tests exercises that boundary; it is not registered
in either release executable. See [DESIGN.md](docs/DESIGN.md) for the dependency rules.
For PR feedback, follow cursors, merge thread fragments by root comment ID, and
refresh from the beginning to find new or edited feedback. Only complete traversals
replace a comparison baseline. Thread resolved/outdated status is unknown over REST.
