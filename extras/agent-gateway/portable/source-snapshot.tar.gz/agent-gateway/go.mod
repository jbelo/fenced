module agent-gateway

go 1.27
