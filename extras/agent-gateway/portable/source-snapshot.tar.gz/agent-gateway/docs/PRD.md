# Development-agent gateway

## Purpose and users

Development agents need GitHub and Shortcut context to understand tasks, inspect
changes and check results. The gateway gives them a small set of read operations
while keeping provider credentials under the developer's control. Its users are
the agent doing development work and the developer operating that environment.

## Workflows

An agent uses `agentctl` to:

- Find GitHub.com pull requests, read their descriptions, inspect diffs and check results.
- Collect PR reviews, discussion comments and inline replies; refresh to discover
  new or changed feedback, with explicit completeness and unavailable fields.
- Retrieve a known Shortcut story by its identifier using `get`.
- Discover relevant stories using `search` with plain words and supported filters.

Search currently accepts letters, numbers and spaces. Terms such as `agent-gateway`,
`foo.go` and `C++` are rejected; broader literal search is outside the current scope.
Results are predictable JSON. Pagination and errors make clear when an agent needs
another page, a narrower request, or help with a disallowed target or provider failure.

The developer selects allowed repositories and workspaces, configures credentials,
and can try all seven operations with mock data before enabling live access. The
product includes `agentctl`, a buildable container image, example policy and Compose
deployment, agent usage instructions suitable for a skill, and an operator runbook
for setup, troubleshooting and credential replacement without rebuilding the image.

## Scope and constraints

Access is shared by all containers on an operator-controlled development network,
including agent-controlled services. The gateway isolates provider credentials and
restricts available operations and targets. It does not provide individual agent
identity or attribution. Removing one agent's access cannot individually revoke
activity it delegated to other containers that retain access.

The seven operations are PR list, view, diff, checks and feedback, plus story get and search.
They must remain read-only even when an upstream token permits writes. Direct API
requests receive the same validation and target restrictions as CLI requests.
Provider content is untrusted data; credentials must not appear in images, responses
or logs. Agents cannot change gateway policy or code, and invalid configuration
must fail closed.

**Extensibility.** The gateway must support adding services and read operations
beyond GitHub and Shortcut without redesigning its core access model. New
integrations must preserve credential isolation, explicit target restrictions, and
read-only access. GitHub and Shortcut remain the initial release scope; adding
other integrations is future work.

The gateway is a standalone service, with fenced as its first consuming harness.
Agents retain their existing network restrictions. The host administrator and
operator are trusted; a compromised gateway can expose its provider credentials.
Writes, arbitrary provider forwarding, command execution, browser sessions, MCP,
write approvals and dashboard integration are outside this release.

## Success criteria

All seven workflows return documented results without exposing upstream credentials
to agents. Operators can deploy the service in Linux containers, including Docker
Desktop on macOS, understand failures, and rotate or revoke credentials. Audit
records explain operations and outcomes without exposing sensitive content.

Verification demonstrates read-only behavior, target restrictions, credential and
configuration isolation, bounded results, and integration with fenced without
expanding agent network access. A synthetic integration must run end to end without changes to unrelated
integrations, demonstrating the extension boundary. Mock-backed demonstrations are required; privately
credentialed live checks are optional. The [technical specification](SPEC.md) defines
API behavior, limits, deployment requirements and detailed verification criteria.

The [domain model](DOMAIN.md) defines resource scopes, operations and provenance;
the [design](DESIGN.md) explains how the gateway implements those concepts.
