# Gateway operator runbook

The [specification](SPEC.md) defines supported behavior, configuration and deployment
requirements. These procedures are for the trusted operator controlling the gateway,
its host files and container networks.

## Build and deliver the mock package

This checkout supports mock and live startup. The instructions below first prepare
mock delivery; live startup requires private credential files and validated policy.
Authenticated provider compatibility and live deployment checks remain outstanding;
a healthy container alone does not establish either.

From the repository root, with Go 1.27 or newer and Python 3:

```sh
make check
make release
(cd dist && shasum -a 256 -c SHA256SUMS)
```

The output contains Linux amd64/arm64 gateway, CLI and readiness-probe binaries,
a self-contained `skills/agent-gateway` directory, SHA256SUMS and source-manifest.json.
The manifest records the Git commit, dirty state, actual source-file hashes and Go
version, so uncommitted builds cannot be mistaken for that commit's content. Keep
these records with the delivered artifacts. Generated dist/ files are excluded
from Git. Build outputs are local; nothing is published by these targets.

Supply a verified Go 1.27+ build image that contains
`/etc/ssl/certs/ca-certificates.crt`. Use a digest-pinned reference for release:

```sh
make image GO_IMAGE='your-verified-go-image@sha256:your-verified-digest'
docker image inspect agent-gateway:mock-local --format '{{.Id}}'
```

Replace the illustrative reference; no particular base image is certified by this
checkout. The Dockerfile cross-compiles for BuildKit's target architecture. For a
multi-architecture registry release, use an operator-approved buildx builder and
registry, build linux/amd64 and linux/arm64, and record the resulting manifest digest.
Do not substitute a local image ID for a published multi-architecture digest.
The final image contains binaries and CA roots, runs as 10001:10001, and has no shell.
Its readiness probe reads the fixed mounted configuration and calls only /readyz;
it ignores proxy environment variables and does not contact providers.

## Run the mock example

[compose.mock.yaml](../deploy/compose.mock.yaml) uses the existing external Docker
network go-agent-internal-net. It creates no network and publishes no host ports.
Before starting, confirm the operator-provisioned subnet contains 172.30.0.10 and
that address is reserved for this gateway. If different, change both the Compose
ipv4_address and [mock configuration](examples/mock-config.json) listen_address.
The AGENT_NETWORK environment variable can select a separately provisioned test
network; do not modify Fenced's address plan from this work item.

Make the example config/policy readable by UID 10001 and their directories
traversable; they contain no secrets. The mounts are read-only and missing host
files cause startup failure rather than being created as directories. Mock mode
mounts no credentials and has no external-egress attachment.

```sh
docker compose -p agent-gateway-mock -f deploy/compose.mock.yaml config --quiet
docker compose -p agent-gateway-mock -f deploy/compose.mock.yaml up -d
docker compose -p agent-gateway-mock -f deploy/compose.mock.yaml ps
docker compose -p agent-gateway-mock -f deploy/compose.mock.yaml logs --tail 30
```

If Compose is installed as a standalone executable, use docker-compose instead.
The Docker healthcheck verifies readiness every ten seconds. Run the seven commands
in the delivered skill from an authorized member container, using company/project
and engineering as configured in the examples. Check target denial too. Stop with
`docker compose -p agent-gateway-mock -f deploy/compose.mock.yaml down`; the external network is retained.
These commands are operator procedures, not actions performed by the build scripts.

For this project name and the default agent network, run
`python3 scripts/verify-mock-container.py` on a Docker-enabled host after startup.
It inspects runtime restrictions, runs temporary client containers for all seven reads
and denial cases, then stops and restarts only this mock gateway to check idle
SIGTERM handling. It leaves the gateway running and writes dist/mock/verification.json.
This interrupts mock service briefly; it does not verify active-request shutdown,
Fenced image installation, live providers or isolation on a second attachment.


Install the matching verified agentctl binary at /usr/local/bin/agentctl in the
consumer image. Install the entire skills/agent-gateway directory in that harness's
skill location. Supply the read-only [CLI configuration](../deploy/agentctl.json)
and set AGENTCTL_CONFIG to its path. Fenced owns installation in its images and
real-image verification; this package does not modify Fenced files.

For a native executable smoke test against an in-process mock gateway, reserve local
port 8080, then run from the repository root:

```sh
go build -trimpath -buildvcs=false -o /tmp/agentctl-native ./cmd/agentctl
GATEWAY_PACKAGED_CLI=/tmp/agentctl-native go test ./cmd/agent-gateway -run '^TestPackagedCLI$' -count=1
```

This checks all seven commands and denial over HTTP with a built CLI, including proxy
bypass. It does not test container entrypoint, mounts, networks, UID, image health or
OS-signal shutdown. Before handoff, record which of those actual-image checks passed.
Use the isolated dummy-credential check below before provisioning live credentials.
Only report live readiness after authenticated provider and deployment verification.

## Prepare and check a deployment

Start from the [configuration and policy examples](examples/). Select mock or live
mode, the allowed targets, and a fixed gateway address on the shared development
network. Match that address to `listen_address`. Install the architecture-matched
image and CLI using the supplied digest/checksums.

Keep configuration and policy under operator control. In live mode, provision only
the required provider tokens as private host files, staged into the dedicated Docker credential volume at the
configured `/run/secrets` paths. Keep sources operator-owned; runtime-stage assigns
Linux volume ownership and runtime-check verifies access as container UID 10001. Never put token contents in shell arguments,
images, source files, shared agent homes or diagnostic output.

A classic GitHub token accessing private-repository checks requires `repo` scope,
which also carries write privileges. Use an approved token and grant the least
provider access compatible with the selected operations. Use a Shortcut v3 token
and configure its expected workspace UUID. The gateway's read-only restrictions
apply regardless of the token's upstream privileges.

Attach the gateway to the shared development network and, for live access, its
external network. Do not attach agents or their development services to that external
network. Configure the gateway listener only on its shared-network address and
publish no host port. Keep the shared agent proxy policy unchanged. Mock mode does
not require provider tokens or an external attachment.

Check `/healthz` and `/readyz` from the shared network. Readiness confirms local
configuration and secret loading, not provider acceptance of a token. Exercise the
seven operations with mock data. A privately credentialed live smoke test is optional;
use an allowed target and keep tokens out of test output.

## Live access input checklist

Before provisioning, select the allowed `owner/repo` names explicitly, one PR for
view/diff/checks, and repositories with enough PRs to test pagination. The gateway
has one GitHub credential file, so that credential must cover every allowed
repository. The policy can be narrower than the credential's provider access.

For the current static-token deployment, a classic GitHub PAT accessing private
repositories needs `repo` scope, including for check runs. This scope carries write
privileges; the gateway enforces read-only operations independently. Ensure the
account can read the selected repositories and that the organization permits and,
where required, authorizes the token. Do not assume a fine-grained PAT will cover
checks: the current [check-run documentation](https://docs.github.com/en/rest/checks/runs#list-check-runs-for-a-git-reference)
lists GitHub App tokens for granular access, requiring Checks read. An App token
would also need [Pull requests read](https://docs.github.com/en/rest/pulls/pulls#get-a-pull-request)
and [Commit statuses read](https://docs.github.com/en/rest/commits/statuses#get-the-combined-status-for-a-specific-reference).
App-token issuance and automatic refresh are not implemented; selecting that route
requires an operator-managed replacement process before expiry.

For Shortcut, provide the workspace URL/slug, a chosen agent-facing alias, its
expected workspace UUID, a known story ID, and a plain-word search for testing.
Provision one v3 API token for each configured workspace. Shortcut documents these
tokens as granting complete account access, not a read-only scope. Use an account
with only the intended workspace access. Obtain the UUID from the authenticated
`GET /api/v3/member` response's `workspace2.id` using trusted host-side tooling and
confirm the workspace with the operator. Retain only the necessary workspace
metadata, not the full response or token. See [Shortcut v3 documentation](https://developer.shortcut.com/api/rest/v3).

## Private credential storage and runtime management

Host source credentials stay in an operator-owned private runtime directory, outside
checkouts, agent homes and build contexts. Source token files use mode 0400 and the
host operator's UID. **Do not chown macOS source files to 10001.** Colima VirtioFS
cannot reliably expose such files to the VM; host metadata checks alone are insufficient.

Gateway credentials are stored in a dedicated Docker named volume. The maintained
helper sends bytes over subprocess stdin to a trusted, network-disabled helper
container; token values never enter command arguments, environment variables or
output. Inside the Linux volume it assigns directory ownership 10001:10001/mode
0700 and token ownership 10001:10001/mode 0400. The gateway mounts that volume
read-only at `/run/secrets`. No credential bind mounts or host ownership translation
are involved. Docker administrators remain trusted. Host source files are retained
for repeatable staging; protect them with the same care as the volume.

Set these non-secret parameters for the Make targets, or use equivalent Python flags:

| Parameter | Meaning |
|---|---|
| `RUNTIME_DIR` / `--directory` | Absolute private host directory with config/ and secrets/ |
| `GATEWAY_SECRETS_VOLUME` / `--secrets-volume` | Dedicated Docker volume name |
| `CREDENTIAL_HELPER_IMAGE` / `--helper-image` | Trusted local image with /bin/sh and standard Linux file tools; use a pinned reference |

The helper resolves the image to a local image ID and never pulls it implicitly.
New volumes are labeled `agent-gateway.credentials=true`; unlabeled existing volumes
are refused. Helpers have no network, a read-only root, no-new-privileges, no Docker
socket, and disabled container logging. Writer helpers have only CHOWN, DAC_OVERRIDE
and FOWNER capabilities; access checks run as UID/GID 10001 with all capabilities
dropped. Do not attach the credential volume to agents or unrelated services.

| Make target | Python action | Purpose and additional inputs |
|---|---|---|
| runtime-init | init | Hidden token prompts, workspace verification, new files and volume staging; REPOS, AGENT_IP, SHORTCUT_ALIAS, SHORTCUT_SLUG |
| runtime-configure | configure | Replace supplied non-secret CONFIG_FILE and/or POLICY_FILE JSON; credentials unchanged |
| runtime-stage | stage | Stage all configured private source tokens into the volume; also resumes after partial initialization |
| runtime-rotate | rotate | Hidden replacement prompt; PROVIDER, and Shortcut alias/slug where applicable; replace source and selected volume token |
| runtime-check | check | Validate host configuration/source metadata and actual Linux-volume access as gateway UID |

Example initialization from a trusted host terminal (replace example settings):

```sh
export RUNTIME_DIR="$HOME/.config/agent-gateway-live"
export GATEWAY_SECRETS_VOLUME=agent-gateway-credentials
export CREDENTIAL_HELPER_IMAGE='your-trusted-local-image@sha256:verified-digest'
make runtime-init REPOS=company/project AGENT_IP=172.30.0.10 \
  SHORTCUT_ALIAS=engineering SHORTCUT_SLUG=company
make runtime-check
```

The runtime destination must be new, with an existing parent. Init verifies the
Shortcut slug/UUID through direct HTTPS, then asks for confirmation before creating
files. It does not authenticate GitHub. Initial staging failures leave private
source files available; correct the Docker problem and rerun runtime-stage rather
than initialization. No host sudo/chown step is required. All runtime actions run
as the host operator with Docker access, including rotation.

```sh
make runtime-configure POLICY_FILE=/absolute/path/to/desired-policy.json
make runtime-rotate PROVIDER=github
make runtime-rotate PROVIDER=shortcut SHORTCUT_ALIAS=engineering SHORTCUT_SLUG=company
make runtime-stage
make runtime-check
```

Configure accepts complete JSON files so multiple workspace mappings and disabled
providers remain supported. Add a workspace's configuration before rotating its
credential into place. Shortcut rotation verifies the new token against both the
expected slug and configured UUID. Host/source and volume updates are atomic per
file, not a multi-file transaction; serialize management operations. If staging or
rotation fails partway, do not recreate the gateway: rerun runtime-stage and check.
The running gateway keeps its previously loaded tokens until recreation. The helper
never deletes unused credentials; for a reduced policy/provider set, select a new
volume and stage only the configured files, then retire the old volume explicitly
once no container uses it. This also avoids mixing credentials from deployments.

Check rejects missing/extra volume files, symlinks, bad Linux ownership/mode and
invalid sizes; it opens and reads files as UID 10001, discarding all bytes. It reads
only metadata for host source tokens. It verifies neither provider permissions nor
readiness of the deployed gateway. After successful preflight, Fenced's trusted host
deployment tooling explicitly recreates the gateway and verifies real allowed reads.
Provider revocation remains separate; no runtime action starts/restarts containers.

### Migrating the earlier Colima bind-mount setup

Fenced coordinates this with the operator. Restore ownership of the existing source
files to the host operator, preserving mode 0400 (run in the operator's terminal):

```sh
sudo chown "$(id -u):$(id -g)" \
  "$RUNTIME_DIR/secrets/github_token" \
  "$RUNTIME_DIR/secrets/shortcut_YOUR_ALIAS"
chmod 0400 "$RUNTIME_DIR/secrets/github_token" "$RUNTIME_DIR/secrets/shortcut_YOUR_ALIAS"
make runtime-stage
make runtime-check
```

Replace YOUR_ALIAS with the configured alias, include each configured token, and
keep the outer runtime directory private. No token values are printed. Only after
both commands pass should Fenced change the deployment to the named-volume Compose
file and perform exclusive mock-to-live cutover. The old host bind-mount check and
host chown-to-10001 recipe are superseded.

## Prepare the live deployment

The [live Compose file](../deploy/compose.live.yaml) uses an existing agent network
and creates a separate bridge for gateway-only direct egress. It requires Compose
2.33.1 or newer for `gw_priority`, which selects the external attachment as the
outbound route. It publishes no ports and grants no provider access to agents.
All proxy settings and agent attachments remain unchanged.

Fenced's trusted host-side deployment tooling or the operator supplies all runtime
settings; agent containers cannot change them. The image contains no repository
allowlist, workspace mapping or deployment address. No image rebuild is required
when these settings change; recreate the container to load them.

Use absolute operator-private directories outside the checkout for configuration
and private credential sources. Copy [the configuration template](../deploy/config.live.template.json)
to `config.json` and [the deny-all policy](../deploy/policy.live.json) to `policy.json`
in the configuration directory. Replace the invalid listen-address placeholder with
the reserved agent IPv4 and port 8080. Enable only the required providers:

- GitHub: set `enabled` to true and `token_file` to `/run/secrets/github_token`.
  Add exact `{"repo":"owner/name"}` entries to policy's `github` array.
- Shortcut: set `enabled` to true and populate `workspaces` with each chosen `alias`,
  verified `workspace_id` UUID, and `token_file` `/run/secrets/shortcut_<alias>`.
  Add permitted `{"workspace":"alias"}` entries to policy's `shortcut` array.

The templates disable providers and allow no targets by default. The
[generic live example](examples/live-config.json) shows the mapping structure;
its sample UUID and address must be replaced. Multiple Shortcut workspaces are
supported without changing Compose. Disabled integrations require no token file.

Place only enabled gateway credential sources in the operator-private secrets/
directory, owned by the operator with mode 0400. Stage them into the dedicated Docker
volume using runtime-stage; do not mount host sources or a general credential store.
Configuration/policy must also be readable by UID 10001 and not agent-writable.
Do not mount either directory into agents or include it in image build inputs.

Before adding real tokens, build a separate candidate tag and run the disposable
startup verifier with a trusted shell-equipped helper image:

```sh
python3 scripts/verify-live-startup.py --image agent-gateway:live-candidate --helper-image YOUR_VERIFIED_HELPER_IMAGE
```

It creates temporary configuration bind mounts under ignored `dist/live`, synthetic host tokens,
a dedicated Docker credential volume,
a private internal Docker network, and containers. It checks healthy live startup,
clean idle shutdown, missing credentials, unsafe permissions, empty/invalid tokens,
invalid policy and credential-free logs. It removes its temporary resources and
writes `dist/live/startup-verification.json`. It does not join the agent network or
call real providers. The helper runs as root solely to prepare Linux volume file ownership;
the gateway runs as 10001:10001. Do not pass real credential files to this verifier.

For later operator cutover, set `GATEWAY_IMAGE` to the verified candidate image ID,
`GATEWAY_RUNTIME_DIR` to the configuration directory and `GATEWAY_SECRETS_VOLUME`
to the volume verified by runtime-stage/check, and `GATEWAY_AGENT_IP` to the reserved internal
address matching `listen_address`. `AGENT_NETWORK` selects the existing harness
network (default `go-agent-internal-net`).
These variables contain paths/identifiers only, never tokens. Validate without
starting anything:

```sh
docker compose -p agent-gateway-live -f deploy/compose.live.yaml config --quiet
```

Only after credential provisioning and an arranged cutover, stop the mock project
using its recorded Compose override, then start the live project with `up -d`.
Never run both projects with the same IP or `agent-gateway` alias. Recheck readiness,
internal-only listening, credential isolation and all seven real workflows; starting
successfully does not verify token permissions. Use operator-selected allowed PR
and story IDs. Preserve sanitized evidence and cursor-length measurements, not bodies or
credential values. If cutover fails, stop the live project before explicitly
restoring the mock; clearly label the service as mock again.

The existing Fenced CLI/configuration can be reused because the API and endpoint
are unchanged. Coordinate removal of its installed mock-only notice when live
cutover actually occurs. AMD64 runtime, active-request shutdown and external-network
isolation still need their own evidence.

## Replace credentials or policy

1. Use runtime-configure for desired JSON or runtime-rotate for a new token; rotate
   does not revoke the old provider credential. Use runtime-stage to reconcile all
   private sources after an interrupted update, then runtime-check.
2. Recreate the gateway explicitly to reload policy and credentials. Configuration
   binds may reference old inodes after replacement; source changes alone never
   constitute activation. No image rebuild is needed.
3. Confirm the old container and its requests have stopped, then verify readiness
   and an approved provider read. Restart invalidates cursors. Only report the change
   effective after successful verification. Do not silently fall back to old files.
4. Revoke the old token at its provider after verifying the replacement, where
   operational policy permits. For urgent revocation, revoke upstream and stop the
   gateway immediately, accepting downtime. Retire unused volumes explicitly.

## Remove agent access

Stop the agent container to terminate its connections and remove its shared-network
membership. This removes direct access only. Identify services, forwarding processes
and jobs it created in other member containers; stop or disconnect those containers
and terminate delegated activity before declaring full revocation. Verify that
removed containers cannot reconnect without restored membership. Data already
returned to an agent cannot be recovered by revocation.

## Diagnose failures

Use request IDs and sanitized audit records to correlate requests. Do not collect
provider bodies, raw search text, authorization headers or token files in diagnostics.

| Symptom | Check |
|---|---|
| Startup or readiness failure | Configuration/policy syntax, enabled mappings, local listen IP, secret presence and permissions |
| `policy_denied` | Repository or workspace allowlist and returned target validation |
| `upstream_authentication` / `upstream_authorization` | Token validity, provider permissions and Shortcut workspace UUID |
| `rate_limited` | Retry guidance, current request concurrency and provider limits; avoid immediate retry loops |
| `limit_exceeded` | Narrow the query or result set; increasing container memory does not change API limits |
| `invalid_cursor` | Restart, policy changes, expiry, mismatched arguments or changed PR head; begin a new traversal |
| `timeout` / `upstream_unavailable` | Provider availability and gateway DNS/TLS/connectivity |
| CLI `transport_error` | Gateway endpoint, shared-network reachability and response validity |
| CLI `configuration_error` | `AGENTCTL_CONFIG`, file readability and configured gateway URL |

Logs go to stdout/stderr; configure retention through the deployment environment.


## PR feedback capability

The additive command is `agentctl github pr feedback --repo owner/repo --number N
--limit 50`. Upgrade gateway and CLI together; older gateways return
unsupported_operation. The installable usage skill explains continuation, thread
fragments and refresh. Existing configuration and repository allowlists apply.
Fine-grained GitHub tokens need Pull requests: read for the PR lookup, reviews,
inline comments and general PR discussion comments. No new credentials are held by
agents and no GraphQL requests are made. Live permission verification belongs to
the operator/consumer deployment; a mock success does not establish it.

For consumer verification, collect all feedback pages on the selected PR, check
review/comment separation and reply grouping, then refresh without a cursor.
Report completeness, exact gateway/CLI identities and limitations without feedback
bodies. Thread resolved/outdated flags remain unknown. Gateway tests do not prove
installation, network isolation or real-provider compatibility.
