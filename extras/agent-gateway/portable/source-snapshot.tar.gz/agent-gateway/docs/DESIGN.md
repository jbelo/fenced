# Gateway design

This document describes the internal design for the gateway and `agentctl`. The
[PRD](PRD.md) explains the product; [DOMAIN](DOMAIN.md) defines shared concepts and
invariants; the [SPEC](SPEC.md) defines observable behavior,
security invariants and limits. This document explains how to implement those
requirements with explicit responsibilities and a small amount of shared machinery.
The [runbook](RUNBOOK.md) covers operating the service.

## Architecture

Use ports and adapters around a domain and application package, `access`. Adapters
depend inward on its contracts. Read execution depends on no wire, HTTP, file,
logging or concrete integration packages. The body below specifies the target
design; the implementation map at the end identifies what exists.

Use two Go executables: a single-process gateway and a thin CLI. Keep policy and
configuration immutable for the lifetime of a gateway process. Keep positional
cursors encrypted and authenticated under an in-memory startup key; restarting
invalidates them. Do not cache pages or maintain a traversal store. There is no
database, background job system, runtime plugin loader or service discovery mechanism.

All operations pass through one read use case. Integrations supply typed reads
and provider-specific interpretation; they do not implement their own HTTP routes,
authorization middleware, public cursors or response envelopes. Adding a service
should mostly add code beside existing integrations, rather than branches throughout
the server.

```mermaid
flowchart LR
    CLI[agentctl] --> HTTP[HTTP adapter]
    Tests[Typed read tests] --> Read
    HTTP -->|"Read(req, fits) returns result, record, error"| Read
    subgraph Access["access: domain and application"]
        Read[Read use case] --> Rules[Policy, validation and budgets]
        Read --> Operations[Operation port]
        Read --> Cursor[Cursor codec port]
        Read --> Clock[Clock port]
    end
    Integrations[Provider adapters] -. implement .-> Operations
    Codec[AEAD cursor codec] -. implements .-> Cursor
    Time[System clock adapter] -. implements .-> Clock
    Integrations --> Transport[Bounded HTTPS]
    HTTP --> Audit[Audit sink adapter]
```

Arrows show calls or implementation relationships, not returned data. HTTP depends
on access; access does not import HTTP or call the audit sink. The response-fit
callback is part of the access-owned Read contract, supplied by the boundary.

A port is a contract owned by the component that uses it; a typed function can
serve as a port without an interface or a separate package.

| Port | Direction and type owner | Responsibility |
|---|---|---|
| Admission | Inbound, `access` | Admit immediately or reject; issue a bounded permit shared by every inbound adapter. |
| Read | Inbound, `access` | Consume a valid permit and typed request; verify, run the boundary-supplied response-fit check and return the outcome and access record. |
| Operation execution | Outbound, `access` | Execute an authorized read with an explicit budget; verify semantics/provenance and measure results. |
| Cursor codec | Outbound, `access` | Seal and open bounded positional continuations; access enforces binding, expiry and traversal caps. |
| Clock | Outbound, `access` | Supply time for expiry and deadline decisions. |
| Audit sink | Outbound, request boundary | Write the completed access record and report sink failure; execution returns the record rather than writing logs. |

Provider adapters implement operation execution; a small AEAD adapter implements
the cursor codec. The request boundary generates request IDs and writes audit JSON.
Cursor nonces and the runtime key belong to the codec; no storage adapter is needed.


Shared-network membership provides access. Policy restricts targets, not individual
callers. Neither the read use case nor the cursor codec introduces per-agent identities.
Application request restrictions still apply despite the gateway's unrestricted
network egress.

## The read boundary

Separate read execution from its HTTP representation. The `access.Read`
entry point accepts an operation, canonical `ResourceScope` and typed arguments,
and returns a result and safe access record. It owns semantic argument validation,
policy, execution budgets, result verification and traversal rules. It does not
import HTTP, JSON, concrete integrations, configuration files or logging formats.

The `httpapi` boundary owns strict wire decoding, request IDs, response envelopes,
public error mapping, encoded response limits and records for requests rejected
before execution. It calls `access.Admit` before allocating a complete body and
reads input under the returned permit’s deadline. Request IDs originate here; execution receives correlation metadata
only when needed. A clock is injected where deadlines or expiry need deterministic
tests, without introducing an ID-generation port into read execution.

Pure per-operation semantic validators are registered with the read boundary and
reused by CLI/wire decoding. Checking a Go argument type is insufficient: direct
callers must also satisfy limits, identifiers, filters and scope-kind rules. Declared
scope kinds are required in definitions, wire descriptors and access operations.
Registration rejects missing declarations and configured bindings that change them.
Decoded and normalized scopes are checked against the declaration before execution;
policy loading also rejects undeclared scope kinds.

An `AuthorizedRead` represents successful validation and policy for one execution.
Private fields and controlled construction help prevent accidental misuse, but zero
values must still be rejected. It is not a security boundary against trusted compiled
integration code. `Budget` names execution accounting, avoiding confusion with the
resource scope. Connections remain integration-owned configuration rather than a
new shared abstraction.

`Read` takes a mandatory boundary-supplied `fits(result) error` callback. After
verifying a result and sealing any continuation, it invokes the callback synchronously.
The HTTP callback encodes the complete envelope with its request ID, checks its byte
bound and retains those exact bytes for delivery. It does not write or mutate the
result. Callback failure or cancellation discards the candidate response; a nil
callback fails closed. On success the boundary delivers the retained bytes.

There is no traversal reservation, commit or abandonment. An undelivered continuation
holds no server resources, and retrying an input cursor simply re-evaluates its position.
Keep admission cleanup and cancellation guarantees independent of cursor handling.

Admission belongs to `access`, not HTTP. `Admit` uses the single concurrency limit,
never queues, and returns a permit bound to that access instance and request deadline.
The adapter immediately defers its idempotent release, including on decoding failure
and panic. `Read` rejects absent, foreign, expired, released or previously used permits
and claims each permit once; direct typed callers follow the same Admit/Read path.
The slot remains held through response delivery and audit, until boundary release.
Deadline expiry cancels the attempt but does not free a slot while work is still
running. This avoids admitting replacement work on top of an uncooperative callback.
Nested execution shares the same budget and does not acquire another permit.

## Package responsibilities

Keep related behavior in ordinary files. These boundaries do not require a package
or interface per operation.

| Package | Responsibility |
|---|---|
| `internal/access` | Resource scopes, typed semantic contracts, authorization, shared admission, read execution, budgets, provenance obligations, internal outcomes and traversal rules. |
| `internal/httpapi` | HTTP routes, strict decoding, request IDs, envelopes, public failure mapping, encoded bounds, admission-permit use and audit delivery. |
| `internal/protocol` | Wire DTOs, strict JSON, public error catalogue and execution-kind/HTTP/CLI status mappings. |
| `internal/operation` | Pure binding glue between wire definitions, shared semantic validators and access execution contracts; not imported by access. |
| `internal/provider` | Static lifecycle registration and generic configuration/policy dispatch. |
| `internal/providers/<provider>/contract` | Pure arguments, views, canonicalization and semantic validators implementing access contracts; wire decoders compose those validators. |
| `internal/providers/<provider>` | Connection configuration, credential interpretation, clients, provenance verification and provider traversal. |
| `internal/providers/<provider>/commands` | Pure CLI command declarations. |
| `internal/cli` | Command parsing, bounded gateway transport, output and exit codes; no policy or provider clients. |
| `internal/upstream` | Fixed-origin, bounded, direct HTTPS; charges the explicit access-owned budget. |
| `internal/limits` | Fixed bounds shared by validation, execution and transport. |
| `internal/runtimefile` | Bounded file access and secret-file type/permission checks; no credential interpretation. |
| `cmd/*` | Explicit assembly, runtime choices and executable lifecycle. |

`access` owns the contracts implemented by integrations without importing their
packages. Per-integration pure contracts can depend on both access types and wire
helpers; access never depends back on them. Type erasure stays at registration.
Assembly supplies one explicit provider list and dispatches named raw configuration
and policy sections through the registry. Each integration strictly decodes its
sections. There is no hidden registration through package initialization.

CLI assembly selects pure command packages without importing provider clients,
secret loading or server configuration. Shared CLI parsing switches on flag types,
never provider names or domain fields. Executable-specific helpers live beside
`main.go`, without another application wrapper.

Execution receives `context.Context` for cancellation and an explicit `*Budget` for
accounting. Adapters pass both to upstream transport. Budget is mandatory and is not
retrieved from a context value; nil budgets fail closed. Typed signatures expose the
dependency, while runtime checks handle invalid values. Provider paths, continuation
interpretation and result models remain integration responsibilities.

Prefer concrete structs and typed functions; introduce interfaces at substitution
points. Do not introduce a dependency-injection framework, generic repository layer
or externally supported adapter SDK.

## Typed operations, one execution path

Each operation has its own argument type and result type. For example, PR viewing
accepts a number, while PR listing accepts state, limit and cursor. Avoid one
`Arguments` struct whose valid fields depend on operation names or suffixes. Decode
into the appropriate type, distinguish missing values from explicit zero values,
apply defaults and return a normalized request. These functions have no policy,
credentials, network or filesystem dependency and can be shared with the CLI.

Build an immutable registry explicitly at startup. Each entry binds an operation
identifier to its semantic argument validator, scope kind, executor and result
validator. Wire decoders are registered separately at the inbound boundary. Check
for duplicate identifiers and missing bindings during construction. Known operations
for disabled integrations retain their specified denial behavior; unknown operations
remain unsupported. Registration is trusted Go code shipped with the executable.

The typed binding helper accepts a named `Handler[A, R]` with
`Execute`, `Validate`, `Measure` and a declared `MaxBytes`. An optional `View`
projection removes internal provenance metadata after validation, before publication. It hides the type erasure
needed by the dispatch table; providers depend on access contracts, not the inbound adapter.
Execution receives `AuthorizedRead[A]` and an explicit budget; result validation
receives the canonical scope and typed arguments;
results remain typed until publication. Bindings require result validation and limit
measurement callbacks. The read use case invokes them and enforces the reported bounds.
Integration code cannot publish directly through the HTTP response writer.

CLI command definitions declare their command path, flags, target fields and pure
operation decoder. Shared code builds a request from explicitly supplied flags,
then invokes that decoder. Defaults and validation therefore have the same meaning
for CLI and direct HTTP callers. Command construction rejects duplicates, ambiguous
paths and incomplete bindings. The CLI carries no target policy.

### Resource scopes and policy

A canonical resource scope has three identity components:

```go
type ResourceScope struct {
    Provider string // integration namespace, "github"
    Kind     string // "repository"
    Key      string // "company/project"
}
```

Authorization looks up the complete identity in an immutable
`map[ResourceScope]struct{}` and
denies missing or unknown identities. The same key in another provider or resource
kind grants no access. A new kind requires no change to the authorization logic
in `access`.

Integrations normalize both incoming targets and their configured policy entries
with the same functions. Server assembly converts the existing provider-specific
policy sections into this canonical allowlist. Public request targets such as
`{"repo":"company/project"}` and the policy file format remain unchanged. New
integrations may extend the assembly/configuration schema explicitly.

Each contract also supplies a safe audit representation derived only from the
canonical identity. The read use case records it only after authorization. This preserves
the specified repository/workspace audit shapes without domain branches in audit
code, and lets another integration use its own target shape. Arguments and raw
request targets are not audit input.

The inbound adapter first creates the request ID, establishes the deadline,
checks the route and media type, calls `access.Admit` without queuing, reads
bounded input and decodes it. Malformed requests produce a boundary rejection and
access record without invoking read execution. Direct typed entry points must also
use `access.Admit` and supply its permit to `Read`; no admission policy is
reimplemented by another adapter.

The read use case then:

1. Resolves the registered operation, checks the argument type and semantic rules,
   normalizes the resource scope and authorizes it before provider contact.
2. Constructs the authorized read and verifies any cursor binding and expiry.
3. Performs required current identity checks, then executes or reuses a page using
   the explicit execution budget and cancellation context.
4. Verifies provenance, result semantics and traversal counters, then seals any
   next position within the cursor byte bound. No result state is retained.
5. Calls the boundary-supplied fit check and rechecks cancellation. `Read` returns
   the final outcome and access record.
6. The boundary delivers the retained success bytes or an encoded failure, writes
   one completed access record and releases its permit.

Read determines the execution outcome, including response-fit and cancellation
failures, and returns it with safe access metadata. The boundary maps that outcome
to public response and audit codes without changing the execution decision. It
produces records itself only for requests rejected before Read. Delivery failures
are reported separately; they do not rewrite a completed execution outcome. Fixed limits come from `limits`; there are no
operator-adjustable options that weaken SPEC guarantees.

The gateway owns this ordering. An operation cannot send a response directly or
skip shared enforcement. Its registered result validator supplies provider-specific knowledge,
but the read use case always invokes it. Integration checks supplement canonical-target
authorization; they cannot substitute for it. Extension code is trusted application
code, not sandboxed code: these boundaries prevent accidental bypasses rather than
containing a malicious implementation.

Each operation declares a tested provenance basis, as defined in DOMAIN. Carry
verified identities with internal results when they are needed for a shared check,
even when they have no public JSON field. Do not impose one `Resource string` field
on lists or on integrations whose configured aliases differ from external identities.
Use typed provider-specific verification where it expresses the relationship clearly.

| Operation | Provenance basis |
|---|---|
| PR list | Repository identity from every returned PR, checked against the authorized repository. |
| PR view | Repository and PR number from the returned PR, checked against scope and selection. |
| PR diff | Verified PR lookup plus a diff endpoint constructed from authorized repository and number; raw diff text has no identity. |
| PR checks | Verified repository, PR number and head SHA, followed by checks endpoints constructed for that repository and SHA. |
| PR feedback | Verified PR repository, number and observed head; fixed PR-scoped REST collections with per-record resource and GitHub link checks. |
| Story get | Verified configured workspace UUID for the connection, plus returned story ID and URL checks. The configured alias is a presentation value. |
| Story search | Verified workspace UUID and per-record identity/URL checks, plus local filtering; an alias copied onto a result is not evidence. |

The shared read path requires verification before releasing results, including re-evaluation of cursor positions.
Adapters supply external facts and enforce provider-specific relationships; a generic
identity struct cannot prove correct endpoint construction. Wrong-identity fixtures
and request-construction tests establish that obligation for each operation.

## Providers and bounded work

A provider is the extension point for server assembly. Its `Name` supplies the
namespace, `Definitions` supplies pure operation descriptors, and `Configure`
strictly decodes configuration and creates one initialized `Instance`. The instance
converts its policy section through `Targets` and supplies execution bindings through
`Operations`. The registry rejects missing or unknown sections, duplicate operations,
undeclared executors and targets outside the provider namespace. It checks namespace
membership again when decoding requests. Disabled providers keep their pure schemas
but have no executors; the read use case handles their denial once.

`Runtime` supplies the selected HTTP round tripper and secret-file reader. Mock
assembly provides a fixture transport and no secret reader. Providers load and
validate credentials once during configuration, then retain them only in their
clients. Configuration and policy loading are separate stages; parsing policy never
reinitializes clients. The CLI selects pure command definitions separately, without
importing server providers or constructing runtime instances.

Each integration owns its fixed origin, supported paths, credential header, upstream
response structs and translation into gateway types. Provider JSON never becomes the
public response directly. Provider configuration owns credential paths and mappings,
validates its own fields and initializes its adapter. Common file code enforces
bounds, regular-file type and private permissions; the provider interprets the bytes
as its credential format. Load credentials once during initialization and pass them
only to the relevant adapter/client. The CLI, cursor payloads and audit events have no
credential fields. Mock mode injects synthetic upstream HTTP responses from provider-owned `testdata`
fixtures. Request construction, JSON translation, identity checks and transport limits
run through the same adapters as live requests; there is no separate DTO-returning
mock reader. Fixture selection happens during construction, never in read methods. Fixture
transport factories are an optional capability consumed by executable assembly,
not part of the required Provider lifecycle interface. Mock startup requires a
non-nil fixture transport and fails before provider configuration if unavailable;
it must never fall back to direct network transport. Live runtime selection does
not call fixture factories. Provider-owned fixtures remain beside adapter test data.
Live startup loads and validates all enabled credentials and policy before listening;
there is no separate release switch. The image is independent of deployment targets:
trusted operator or harness deployment tooling supplies mounted configuration,
exact-target policy and a dedicated Docker credential volume. Host source files
remain operator-owned; trusted host tooling stages them through stdin into a
network-disabled helper, assigns Linux ownership, and checks access as the gateway
UID. The gateway mounts the volume read-only and loads tokens only at startup.
Rotation atomically replaces each volume file; recreation activates it. Agent containers cannot
change these inputs. Readiness establishes local initialization,
not upstream token validity. Deployment evidence must distinguish those claims.

GitHub validates PR URLs by fixed origin, exact route/number and canonical repository
identity; provider capitalization does not change the authorized repository. Shortcut
reads both UUID and URL slug from the member response. Only after matching the UUID
to configuration does it use that slug for story URL validation. The public workspace
alias remains operator-defined and need not match the slug.

The shared transport exposes reads, not an arbitrary HTTP method parameter. It
validates the configured trusted origin, verifies TLS, ignores proxy environment
variables and rejects redirects. An adapter selects endpoints with read semantics and constructs paths and query
parameters from authorized typed values. Restricting the method to GET alone does
not establish read-only behavior. Provider continuation URLs are parsed and checked against the
expected operation path. GitHub also accepts its numeric repository path form
with the same endpoint suffix and owner/repository case differences. It extracts
only the next sequential page number; requests still use the configured repository.
Only validated continuation values survive into state.
Never follow a provider-supplied URL directly.

The execution budget owns the deadline and remaining provider-fetch allowance. Transport
charges every fetch before sending it, including identity checks, and uses the
shorter of the provider timeout and remaining request deadline. Read decompressed
bodies through a byte limit before decoding. There are no implicit retries or
unbounded goroutine fan-outs. Cancellation propagates through reads and decoding;
check the deadline again before publishing a successful result.

Feedback walks reviews, discussion comments and inline comments in order, fetching
at most one page per source plus one verified PR lookup. The private cursor retains
source/page/offset/head only. Returned arrays remain distinct; inline comments are
grouped into page fragments by root-comment ID, with null thread flags. Each reply
counts toward the item limit. Collection progress and overall partial/complete/limited
status are projected into the page. Refresh comparison belongs to the consumer;
the gateway holds no previous observations. See SPEC for the complete contract.

Adapters own the traversal details that differ between providers. Initially, checks
walk check runs before statuses, fetching at most one page per source per request
and retaining only source/page/offset positions in cursors. Shortcut verifies workspace identity, then scans at
most four full-result search pages, applying the specified local filters and retaining
the next position rather than unused candidates. These selected algorithms and their observable requirements are
in SPEC. They do not belong in the cursor codec.

All provider output remains bounded before serialization. Bound item counts, strings,
buffers and decoded bodies; do not treat a size check after an unconstrained
`json.Marshal` as memory protection. Stage the final envelope before writing HTTP
headers so oversize output produces a complete error, never a truncated success.
An encoding failure is an internal error; exceeding a documented limit is a limit
error. Numeric limits have one source in code and conformance tests against SPEC.

## Positional pagination

The positional rules in SPEC define observable behavior. Use a small codec
implemented with standard-library AES-GCM, a fresh random 256-bit startup key and
fresh cryptographically random nonces. The key is never persisted or logged. A token
contains a format version, nonce and authenticated ciphertext, encoded with URL-safe
base64. Authenticate the format/version context, reject malformed or oversized input
before allocation, and enforce the 2,048-byte output bound. No custom cryptography,
compression, database, cached pages or fallback handle table is required.

Seal a compact position with an operation/target/normalized-argument binding digest,
policy revision, fixed expiry, counters and provider continuation data. Generate binding
digests from unambiguous canonical encodings; exclude the caller's cursor field.
Store only validated continuation values, source/page offsets and required identity
bindings such as the PR head SHA. Do not seal arbitrary forwarding URLs or credentials.
For Shortcut path/URL continuations, validate the operation path and extract only
one nonempty opaque continuation parameter; ignore all other echoed/default query
parameters and rebuild requests from the bound typed arguments. Duplicate next
parameters and malformed query encoding fail closed.
Do not copy the full URL or repeated search query into the cursor. Fixture tests must
record the supported provider forms; live format compatibility remains to be verified.
A terminal position needs no provider continuation payload. Keep its bindings compact
using fixed-size digests so it fits even when the provider continuation does not.

The startup key supports the current single-instance deployment; replicas would need
shared keys or sticky routing. Policy-revision binding is defense in depth with the
current immutable configuration; it does not require reload machinery.

Access checks authorization, token binding, expiry and logical counters before using
a position. The adapter repeats required PR-head or workspace checks and re-fetches
the position. It returns fresh verified data and the next position. A retry starts
from the same input counters; it does not advance shared state. Concurrent calls need
no per-position lock and may reflect different upstream data. Every attempt still
spends its own fetch, deadline and response budgets.

Keep at most one partial page position per source. To resume it, fetch the same
provider page/token and skip the recorded offset, rather than saving unused records.
For unchanged provider results this preserves ordering and avoids silent loss.
Upstream changes can cause duplicates or omissions, as with ordinary pagination.
Count newly examined search candidates, including filtered ones, against the remaining
allowance; do not count the skipped prefix again. Enforce per-request work limits
also on re-fetches. Never fetch arbitrarily many pages to reconstruct a position.

Return the page reaching a logical cap. If more remains, seal a terminal position;
its use fails with limit_exceeded after binding/expiry/authorization checks and before
provider contact. If a nonterminal token cannot fit the byte limit, replace it with
a compact terminal position and return the verified page through the normal fit and
deadline checks. Reuse the same terminal-error path as traversal caps; do not retain
the oversized provider payload or add a stateful fallback. No new wire or audit field
is required.
Provider continuation size must be verified with fixtures and operator-supplied live
evidence before claiming complete provider compatibility.

`access.CursorCodec` seals/opens typed `CursorState`; the adapter owns its private
JSON serialization. `access.Continuations.Resume` validates binding, expiry and
counters, rejecting terminal positions before provider contact. `Next` accounts for
a verified page and seals a compact terminal position at caps or encoding overflow.
Executable assembly creates one codec/clock per process and shares Continuations
through provider.Runtime. Read authorizes before invoking adapters and gives the
request budget the immutable policy fingerprint. Providers bind that fingerprint,
operation, canonical target and normalized arguments (without cursor), then Resume.
They verify provenance/PR-head identity before returning results; Read enforces the
requested result limit and final fit/deadline checks. The codec grants no access and
never fetches pages. Standalone fixture readers use isolated fixture runtimes.

Inject a clock for expiry tests and controllable codec inputs for deterministic tests;
production always uses secure randomness. Tampering, key replacement, policy changes,
argument changes and expired positions fail closed. This design intentionally gives
up identical page replay in exchange for no retained traversal state.

## Startup, failures and the CLI

Assembly retains strict decoding of the entire configuration, including unknown
provider fields, missing required sections, duplicate targets and invalid mappings.
Provider-specific validators do not replace the common strict decoder. Startup
validates configuration, policy, enabled integrations, credentials and the
assigned listener address before accepting requests. Construct private immutable
runtime objects rather than exposing mutable server fields. Readiness reflects local
initialization and draining, without calling providers. Shutdown stops admission and
drains requests within the specified grace period. Draining closes shared admission
without canceling admitted reads; new reads receive the existing admission rejection
(`rate_limited`). Readiness returns 503 and liveness stays 200. The executable waits
for HTTP shutdown to finish before exiting, forcing closure at the grace deadline.
Credential and policy replacement
uses process replacement as described in the runbook.

Use one public error catalogue for code, safe message, HTTP status and CLI exit code.
At the read boundary, internal failure kinds map to this catalogue; execution
does not depend on public error codes or transport statuses.
Internal errors may carry sanitized upstream status and retry information, but never
serialize arbitrary provider error text. The audit record is constructed from known
fields; it must not log request bodies, queries, tokens or raw errors. Produce one access record per request, including boundary rejections; do not record
the same attempt again when execution returns. Durable exactly-once delivery is not
promised. Keep audit writing behind one sink with explicit failure handling; do not add an unbounded
logging queue or silently swallow writer errors.

The CLI parses registered flags and applies the integration's pure schema, then sends
one request. The gateway repeats validation and alone decides target authorization.
The client uses the specified direct transport and response bounds, validates the
envelope and status, tolerates compatible added response fields and prints JSON.
Local failures use the same public error vocabulary without inventing a server
request ID. Neither the CLI nor the transport silently retries.

## Extending and verifying the design

To add an integration, add its pure contract, configuration and initialization,
operation/result bindings, command definitions and tests. Extend explicit server
and client assembly, configuration/schema documentation and deployment credentials
where necessary. Unrelated adapters should not change. Shared abstractions may evolve deliberately
for a new capability while preserving the access model and compatibility within
the current API version;
registration does not permit caller-defined endpoints or expand release scope.

Keep a synthetic document-collection integration in tests, outside release assembly.
It has its own arguments, results, configuration, canonical target kind and CLI
command. Run it from configuration through CLI and HTTP to demonstrate that the
boundary supports a domain unrelated to the initial providers. Check namespace
isolation, canonicalization, denial before execution, mandatory result validation,
safe errors and shared limits. This complements tests of the real integrations.

Tests should follow the boundaries: pure validation tests; read-use-case tests with fake
operations; adapter tests with recorded synthetic provider responses and a controlled
round tripper; cursor codec/expiry tests with a fake clock and concurrent callers; and CLI tests
against a controlled gateway. Shared conformance tests exercise authorization before
execution, read-only transport, output identity, safe errors, resource limits and
credential non-disclosure for every integration. Fixture-backed adapters pass through the same pipeline and transport controls as
live adapters. Cursor conformance additionally requires two-page traversal, replay,
expiry, cap and token-size tests against the cursor codec.

Retain real container/network verification for deployment isolation. In-process
HTTP tests demonstrate application behavior, but cannot prove that agents cannot
reach the listener's external attachment, provider credentials or direct internet.

Production dependency tests must enforce these boundaries: read execution has no wire or
infrastructure imports; integrations do not import the HTTP adapter; CLI and pure
contracts do not import runtime clients or secret loading; integrations do not
import unrelated integrations. Test assemblies may combine
integrations. Changes to these rules require a deliberate design update rather than
permanent exceptions hidden in tests. Migration checkpoints belong outside this design.


## Implementation map

This table maps the target design to the code; it does not change the responsibilities
above. Built means the stated capability exists, not that the release is complete.

| Concept or boundary | Current implementation | Status |
|---|---|---|
| Resource scope and target policy | `access.ResourceScope` and `access.Policy`; immutable map in `access.Reader`. `operation.Target` is a contract alias. | Built |
| Provider lifecycle and fixture-backed adapters | Provider has no fixture requirement; executable runtime selection consumes optional fixtureFactory capability | Built |
| Typed read independent of wire format | `access.Reader.Read` accepts typed arguments, revalidates semantics and policy; `httpapi.Pipeline` owns decoding/envelopes | Built |
| Authorized read and scope kind | `access.AuthorizedRead` guards execution; required ScopeKind metadata is checked at registration, policy conversion and request normalization | Built |
| Explicit execution budget | `access.Budget` passed through execution, readers and upstream transport | Built |
| Provenance | Operation bindings verify returned PR identity and configured-versus-observed workspace UUIDs; View projections strip internal evidence. All seven operations have wrong-identity fixtures. | Built including PR-head/workspace checks on nonterminal cursor reuse; fixture-verified |
| Failure mapping | `access.Failure` kinds mapped by protocol; binding glue translates adapter errors | Built |
| Positional traversal and cursor codec | `access.Continuations` owns binding/expiry/caps; `cursor.Codec` implements AES-GCM; provider adapters own validated page/token/offset positions | Built and wired through runtime assembly; live-provider verification remains open |
| Admission and publication | `access.Reader.Admit`, single-use permits and `Read` fit callback; HTTP retains encoded bytes through delivery | Built including cursor-bearing responses |
| Clock | `access.NewContinuations` accepts a clock function; tests advance a fake clock | Built; assembly supplies time.Now and tests use a fake clock |
| Access records and request IDs | access returns safe execution metadata; httpapi creates IDs, maps outcomes and writes audit | Built |
| Mock delivery | Dockerfile, mock Compose example, Linux build/checksum manifest script, readiness probe and distributable agent-gateway skill | ARM64 mock image and Fenced consumer verified; live Compose and dummy startup verifier prepared, authenticated live verification pending |
| Readiness during draining | access.Drain stops admission; readyz returns 503 while healthz stays 200. Shutdown waits for drain completion. | Built; deployed signal/network verification remains |
| Production dependency tests | `internal/archtest` checks production imports, excluding test assemblies | Built |

Migration evidence and test checkpoints belong in progress records. The table must
be updated when implementation changes, without treating a design statement as proof
that the corresponding behavior exists.
