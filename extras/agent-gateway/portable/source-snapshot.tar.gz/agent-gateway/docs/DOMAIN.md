# Controlled reads: domain model

The gateway mediates access to external information. It lets consumers perform
explicitly supported reads on operator-approved resource scopes while keeping
provider credentials private. Pull requests, stories and other service objects
remain integration-specific views.

The [PRD](PRD.md) defines purpose and scope, this document defines the shared
vocabulary and invariants, the [SPEC](SPEC.md) defines observable behavior, and
[DESIGN](DESIGN.md) assigns implementation responsibilities. These concepts do not
require a separate type or package for every name.

## Participants and access

A consumer is any container on the operator-controlled development network,
including an agent, a harness or an agent-controlled service. Consumer input is
untrusted. All members have equal access; the gateway provides no individual agent
identity or operation grants. The operator controls network membership, allowed
resource scopes, credentials and deployment. Removing one member does not revoke
work delegated to other members that retain access. [SPEC §1](SPEC.md#1-scope-trust-model-and-security-invariants)
defines the full trust model.

External services supply identity information and content. The gateway verifies
service identity through its transport and checks returned resource identities
where available. Provider content remains untrusted data, including text that
looks like instructions. Consumer guidance explains this; v1 adds no content-trust
field to the wire format.

## Vocabulary

| Concept | Meaning |
|---|---|
| Integration | A supported service and its declared read operations, shipped as trusted application code. |
| Connection | A configured access context: integration, expected external identity where applicable, and credential reference. One connection may serve several resource scopes. |
| Resource scope | The canonical authorization boundary, such as a repository, workspace or collection. Its identity combines integration, kind and key. The API calls its external representation a `target`. |
| Resource | An item selected within a scope by arguments, such as a PR number or story ID. Item selection does not introduce separate authorization grants in v1. |
| Operation | A named read with a supported scope kind, typed arguments, result semantics, bounds and validation obligations. |
| Policy revision | The identity of the effective policy snapshot to which traversal state is bound. Replacing policy invalidates that state; this is not a Git revision. |
| Outcome | Success or a failure category, such as denial, not found, upstream failure, timeout or limit exhaustion. HTTP statuses and CLI exit codes are representations of outcomes. |
| Access policy | The operator-approved set of resource scopes. Missing scopes are denied; upstream credential privileges never widen this set. |
| Read request | An operation, resource scope and selection or filter arguments. |
| Authorized read | A request whose arguments and scope have passed validation and policy for this execution. It is internal, not a bearer token or reusable access grant. |
| Provenance | The basis for concluding that a result belongs to the authorized scope and selected resource: verified identity, request construction and response identity where available. |
| View | The normalized, bounded public representation of a result. Raw provider models do not pass through directly. |
| Traversal | A bounded sequence of pages over a read. A cursor identifies a position; it does not grant access. |
| Execution budget | The permitted time, provider fetches, memory and output for a request or traversal. This is distinct from a resource scope. |
| Credential | A secret held for a connection. Domain reasoning uses its reference and expected identity, never its secret value. |
| Access record | Safe metadata about a request: operation, authorized scope, outcome, timing and upstream status. |

Connection identity stays within integrations until a concrete case requires shared
representation. Scope keys must distinguish external contexts that can collide;
credential paths are not identities, and credential rotation does not by itself
create a new resource scope. In mock mode, connections use synthetic upstream
fixtures without loading live credentials. The same operation and validation rules
apply; this is a runtime substitution, not a second access model.

## Rules that every read follows

**R1 — Validate and authorize before provider contact.** Validation and default-deny authorization precede all provider contact, including
identity lookups. Only registered operations execute. Callers cannot choose provider
origins, arbitrary paths, credentials or commands. Typed requests still require
semantic validation; a valid Go type alone does not establish valid arguments.

**R2 — Establish provenance before publication.** Every operation has a declared, tested provenance basis. Copying requested scope
fields into a result does not prove where the data came from. Response identities
are checked against the expected identities where present; fixed endpoints built
from authorized values and verified lookups establish the remaining relationship.
The form of that evidence can differ between integrations and operations.

**R3 — Restrict reads and protect credentials.** Read-only behavior has two parts: trusted operation code selects endpoints with
read semantics, and transport restricts requests to allowed methods and origins.
GET alone does not establish that an endpoint is read-only. Credentials remain in
configured clients and never appear in views, errors, cursors or access records.

**R4 — Bound work and preserve traversal meaning.** Reads have bounded work and results. Incomplete results must not appear complete.
Traversal reuse preserves its binding and repeats authorization and required
identity checks. Exact limits, cursor behavior and failure categories belong in
SPEC. Provider changes do not silently change the public view contract.

**R5 — Record requests and fail safely.** Each request produces a safe access record, including malformed or rejected input.
The request boundary covers failures before read execution. Sink failures require
explicit handling; durable, exactly-once delivery is not promised. Failures expose
only the public error vocabulary, not provider diagnostics or secrets.

**R6 — Extend without weakening the model.** New integrations preserve these rules without changing unrelated integrations.
Shared abstractions may evolve deliberately when a new capability requires it.
This model neither introduces dynamic plugins nor expands the initial release scope.

## Provenance in practice

For `github.pr.checks`, policy first permits the repository. The adapter verifies
the repository and PR number returned by the PR lookup, takes its head SHA, and
constructs checks requests for that repository and SHA. The read verifies identity,
result semantics and bounds before publishing a view. A number copied from the
original request is not independent identity evidence.

The [DESIGN provenance table](DESIGN.md#typed-operations-one-execution-path)
records the basis for each operation, including responses without embedded identity.


## PR feedback observations

Review submissions, discussion comments and inline comments are distinct feedback
categories. Inline replies retain their parent comment and review association.
A thread fragment groups comments by root ID for one page; it is not a complete
thread or a durable GitHub thread identity. Missing provider metadata is explicitly
unknown. A complete traversal is a bounded collection of observations, not an atomic
snapshot. Refresh compares stable IDs and record content in the consumer, never
through a gateway-owned review workflow or write operation.
