# Pagination and error examples

These examples illustrate the agreed cursor behavior in [SPEC](../SPEC.md#cursor-reuse-and-traversal-caps).
The [JSON fixtures](pagination.json) are exercised by continuation/CLI conformance
tests. These are not captured live-provider output. REST traversal is wired and covered
separately by provider fixture tests.
All cursor strings below are illustrative placeholders, not usable tokens. Clients
must treat real cursors as opaque and cannot identify a terminal cursor by its text.
The example repository is assumed to be allowed by policy.

HTTP requests below use `POST /v1/read` with `Content-Type: application/json`.
Responses use JSON and `X-Request-ID` matching the envelope's `request_id`.
For HTTP cases, agentctl prints the same envelope on stdout; the stated exit code
is its corresponding outcome. CLI-local failures have no HTTP response or status.

For enumeration, use `limit: 50` to reach up to 500 items within ten pages. The
default 20 reaches at most 200; the examples use 1 to keep the payloads readable.
Filtered searches may return fewer items. PR checks cannot be narrowed; report
partial results on limit_exceeded. Do not combine different head SHAs or infer an
“all green” snapshot from changing check pages, even for an unchanged head.

## 1. First page with a continuation

Start a new traversal without a cursor. This successful page is not proof of
exhaustion; pass next_cursor unchanged with the same operation, target and arguments.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1
  }
}
```

Response — HTTP 200, CLI exit 0:

```json
{
  "version": "v1",
  "request_id": "example-01",
  "data": {
    "items": [
      {
        "number": 123,
        "repo": "company/project",
        "title": "Add gateway health check",
        "state": "open",
        "draft": false,
        "author": "example-author",
        "url": "https://github.com/company/project/pull/123",
        "updated_at": "2026-10-27T09:23:00Z"
      }
    ],
    "next_cursor": "EXAMPLE_POSITION_2"
  }
}
```

## 2. Last page

For this two-page example, the provider is exhausted on the second page. Only null
next_cursor signals exhaustion. This does not imply a consistent snapshot across pages.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1,
    "cursor": "EXAMPLE_POSITION_2"
  }
}
```

Response — HTTP 200, CLI exit 0:

```json
{
  "version": "v1",
  "request_id": "example-02",
  "data": {
    "items": [
      {
        "number": 122,
        "repo": "company/project",
        "title": "Document gateway setup",
        "state": "open",
        "draft": false,
        "author": "example-author",
        "url": "https://github.com/company/project/pull/122",
        "updated_at": "2026-10-27T09:22:00Z"
      }
    ],
    "next_cursor": null
  }
}
```

## 3. Capped page with a terminal cursor

Independent traversal: nine successful pages have already returned one PR each.
This request returns the tenth page. More results exist, so next_cursor is non-null.
The same terminal behavior applies at 500 returned items or 500 search candidates.
A candidate-capped search may return an empty items array; retain it as a valid page.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1,
    "cursor": "EXAMPLE_POSITION_10"
  }
}
```

Response — HTTP 200, CLI exit 0:

```json
{
  "version": "v1",
  "request_id": "example-03",
  "data": {
    "items": [
      {
        "number": 114,
        "repo": "company/project",
        "title": "Improve request validation",
        "state": "open",
        "draft": false,
        "author": "example-author",
        "url": "https://github.com/company/project/pull/114",
        "updated_at": "2026-10-27T09:14:00Z"
      }
    ],
    "next_cursor": "EXAMPLE_TERMINAL"
  }
}
```

## 4. Using the terminal cursor

Continue with the cursor from case 3. Binding, expiry and authorization are checked;
no provider fetch occurs. Keep the pages already received and report the traversal
as incomplete. Narrow the request where useful, or stop with partial results.
The envelope does not reveal whether the cause was a cap or continuation size.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1,
    "cursor": "EXAMPLE_TERMINAL"
  }
}
```

Response — HTTP 413, CLI exit 9:

```json
{
  "version": "v1",
  "request_id": "example-04",
  "error": {
    "code": "limit_exceeded",
    "message": "limit_exceeded",
    "retry_after_seconds": null
  }
}
```

## 5. Oversized provider continuation

Independent first-page request: the page is verified and fits, but its nonterminal
cursor would exceed 2,048 encoded bytes. Return the page with a compact terminal
cursor instead. Using it has exactly the request/response shape in case 4.
Do not discard the page or label it complete. Narrowing cannot guarantee recovery
from a provider continuation-size problem.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1
  }
}
```

Response — HTTP 200, CLI exit 0:

```json
{
  "version": "v1",
  "request_id": "example-05",
  "data": {
    "items": [
      {
        "number": 123,
        "repo": "company/project",
        "title": "Add gateway health check",
        "state": "open",
        "draft": false,
        "author": "example-author",
        "url": "https://github.com/company/project/pull/123",
        "updated_at": "2026-10-27T09:23:00Z"
      }
    ],
    "next_cursor": "EXAMPLE_TERMINAL"
  }
}
```

## 6. Expired cursor

Independent branch of case 1: at or after ten minutes from the first successful
page, attempt its continuation. Restart without a cursor if more results are needed;
remove duplicate PRs by number. Retries do not extend the original expiry.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 1,
    "cursor": "EXAMPLE_POSITION_2"
  }
}
```

Response — HTTP 400, CLI exit 2:

```json
{
  "version": "v1",
  "request_id": "example-06",
  "error": {
    "code": "invalid_cursor",
    "message": "invalid_cursor",
    "retry_after_seconds": null
  }
}
```

## 7. Arguments do not match

Independent branch of case 1 before expiry: the cursor was issued with limit 1,
but this request uses limit 2. The same error applies to other mismatched bound
arguments. Restore the original arguments or start a new traversal without a cursor.
The error envelope does not distinguish argument mismatch from expiry.

Request:

```json
{
  "operation": "github.pr.list",
  "target": {
    "repo": "company/project"
  },
  "args": {
    "state": "open",
    "limit": 2,
    "cursor": "EXAMPLE_POSITION_2"
  }
}
```

Response — HTTP 400, CLI exit 2:

```json
{
  "version": "v1",
  "request_id": "example-07",
  "error": {
    "code": "invalid_cursor",
    "message": "invalid_cursor",
    "retry_after_seconds": null
  }
}
```

## 8. CLI-local transport failure (exit 11)

Invocation, with a valid operator configuration pointing to an unreachable gateway:

```sh
AGENTCTL_CONFIG=/etc/agentctl/config.json agentctl github pr list --repo company/project --state open --limit 1
```

The intended HTTP body is the first-page request in case 1. In this connection-failure
example no request reaches the gateway. There is no HTTP response or X-Request-ID.
Stdout envelope, CLI exit 11:

```json
{
  "version": "v1",
  "request_id": null,
  "error": {
    "code": "transport_error",
    "message": "transport_error",
    "retry_after_seconds": null
  }
}
```

Check gateway availability and connectivity before retrying. This error also covers
CLI timeouts or unusable responses; in those cases the gateway may have processed the
request. Retrying a cursor re-evaluates its position and may return changed data.

## 9. CLI-local configuration failure (exit 12)

Invocation with a missing configuration file:

```sh
AGENTCTL_CONFIG=/missing/agentctl.json agentctl github pr list --repo company/project --state open --limit 1
```

The intended operation is the first-page request in case 1, but no HTTP request is
sent. There is no HTTP response or X-Request-ID. Stdout envelope, CLI exit 12:

```json
{
  "version": "v1",
  "request_id": null,
  "error": {
    "code": "configuration_error",
    "message": "configuration_error",
    "retry_after_seconds": null
  }
}
```

Repair the configuration before retrying. CLI-local errors have null request_id and
retry_after_seconds, and omit data. Gateway errors likewise omit data; successful
envelopes omit error. Parse error.code rather than relying on message text.
