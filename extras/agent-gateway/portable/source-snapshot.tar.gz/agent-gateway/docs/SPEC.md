# Development-agent gateway specification

The gateway gives development agents a small read-only interface to GitHub.com and
Shortcut while keeping provider credentials outside their environment. This
specification describes the service, `agentctl`, and deployment in a container-based
agent environment, including fenced. The [PRD](PRD.md) explains the product's purpose,
user workflows and success criteria. The [domain model](DOMAIN.md) defines the
shared vocabulary; [DESIGN](DESIGN.md) describes internal responsibilities.
A request `target` identifies a resource scope; `args` select resources and filters
within it. These terms do not rename any wire fields.

## 1. Scope, trust model and security invariants

Access belongs to every container attached to the operator-controlled shared
network, including agent-controlled development services. All members can use the
registered operations; there are no per-agent identities, credentials or operation grants.
The gateway isolates upstream credentials and accepts no caller changes to policy
or network membership. Agents must retain their existing network restrictions.

The operator selects the GitHub repositories and Shortcut workspaces that may be
read. Targets are denied by default, with exact allowlists and no implicit wildcards.
Each request is validated and checked against those allowlists before any provider
adapter is called. Before release, verify that results belong to the authorized target and selected
resource. Check returned identity where present; for responses without embedded
identity, use the operation’s declared provenance basis, including verified lookups
and endpoints constructed from authorized values. Copying request fields into a
result is not identity evidence. These rules apply equally to CLI and direct HTTP requests. Missing or
invalid policy prevents startup.

The gateway performs validation, target authorization and audit. Provider adapters
expose explicitly registered typed read operations. The trusted startup configuration selects
the backend; callers cannot select it or supply provider URLs, paths, headers,
GraphQL, executable names, commands or passthrough flags. The initial GitHub and Shortcut adapters use
fixed REST endpoints and issue only the GET requests described below. Writes,
generic forwarding, executable requests, browser sessions, MCP and raw provider
query languages are outside v1.

Provider content is untrusted data. It never changes policy or causes execution.
The gateway must enforce read-only behavior even with write-capable upstream tokens.

The host and Docker administrators are trusted and can read gateway secrets. Every
shared-network member has identical access, so audit cannot reliably identify an
individual agent; source addresses are not identities. A compromised member can
use allowed operations, delegate work to another member and observe plaintext
internal traffic (the internal service uses HTTP without TLS). An unauthorized
network attachment defeats this access boundary.
A compromised gateway can expose the full upstream token privileges and use its
unrestricted outbound access to exfiltrate credentials.

## 2. API and CLI behavior

### Requests and validation

Only `POST /v1/read` accepts operation requests. Bodies are JSON objects with exactly
`operation`, `target` and `args`:

```json
{
  "operation": "github.pr.view",
  "target": {"repo": "company/project"},
  "args": {"number": 123}
}
```

Reject unknown routes or methods without calling an adapter. Reject unknown fields,
duplicate JSON keys, malformed UTF-8 and non-JSON bodies. Request strings reject
NUL and control characters; response content may contain JSON-escaped newlines and
tabs. Numeric IDs are positive integers no greater than 2^53−1. Fields explicitly
specified as string IDs retain that type.

GitHub targets contain only `repo`, written as `owner/name`. URLs, escaped separators,
dot segments and wildcards are invalid. Compare canonical repository names in
lowercase. GitHub.com is the only supported GitHub service: the gateway fixes its
API origin and rejects a request `host` field as unknown. Shortcut targets contain
an operator-defined `workspace` alias whose verified provider identity comes from
trusted configuration.

### Operations

The supported set consists of the seven operations below.

All listed result fields are required unless stated otherwise. Nullable fields are
present with `null`, rather than omitted. Times are UTC RFC3339 strings. URLs are
informational strings and are never fetched automatically by the CLI. Results are
normalized and contain no provider credentials or opaque provider response bodies.

| Operation | Target | Arguments | Result |
|---|---|---|---|
| `github.pr.list` | `repo` | `state`: open/closed/all, default open; `limit`: 1–50, default 20; optional `cursor` | `items`: PR summaries; `next_cursor`: string or null |
| `github.pr.view` | `repo` | `number` | PR detail |
| `github.pr.diff` | `repo` | `number` | `number`, `repo`, `diff`: UTF-8 unified diff string |
| `github.pr.checks` | `repo` | `number`; `limit`: 1–50, default 20; optional `cursor` | `number`, `head_sha`, `items`: check records; `next_cursor`: string or null |
| `github.pr.feedback` | `repo` | `number`; `limit`: 1–50, default 20; optional `cursor` | Feedback page described below |
| `shortcut.story.get` | `workspace` | `id` | Story detail |
| `shortcut.story.search` | `workspace` | `text`: 1–256 UTF-8 bytes, plain words; optional `type`: feature/bug/chore; `archived`: boolean, default false; `limit`: 1–50, default 20; optional `cursor` | `items`: story summaries; `next_cursor`: string or null |

A **PR summary** contains `number`, `repo`, `title`, `state` (open/closed), `draft`
(boolean), `author` (string or null), `url` and `updated_at`. PR detail adds `body`
(string), `merged` (boolean), `base_ref`, `head_ref` and `head_sha`. Lists use GitHub's
`sort=updated` and `direction=desc`, preserving provider order and its ordering of
ties. Changes between pages can cause duplicates or omissions.

A **check record** contains `id` (string), `name`, `source` (check_run/status),
`status` (queued/in_progress/completed/unknown), `conclusion` (string or null),
`url` (string or null), `started_at` (time or null) and `completed_at` (time or null).
The traversal and status mapping are defined in section 3.

A **story summary** contains `id`, `workspace`, `title`, `type`, `state_id` (integer),
`archived` (boolean), `url` and `updated_at`. Story detail adds `description` (string),
`owner_ids` (array of string UUIDs) and `project_id` (integer or null).

### Responses and errors

Successful requests return:

```json
{"version":"v1","request_id":"...","data":{}}
```

Failures return:

```json
{"version":"v1","request_id":"...","error":{"code":"invalid_input","message":"...","retry_after_seconds":null}}
```

The server generates the request ID and also sets `X-Request-ID`. It does not reflect
unvalidated client identifiers. Error messages are sanitized, stable descriptions
without raw queries, credentials, provider bodies or internal paths. Denied targets
are rejected before their existence is checked.

| Error code | HTTP status | CLI exit code |
|---|---|---|
| `invalid_input`, `invalid_cursor`, `unsupported_operation` | 400 | 2 |
| `policy_denied` | 403 | 4 |
| `not_found` | 404 | 5 |
| `rate_limited` | 429 | 6 |
| `upstream_authentication`, `upstream_authorization`, `upstream_unavailable` | 502 | 7 |
| `timeout` | 504 | 8 |
| `limit_exceeded` | 413 | 9 |
| `internal_error` | 500 | 10 |
| `transport_error` (CLI-local) | — | 11 |
| `configuration_error` (CLI-local) | — | 12 |

`retry_after_seconds` is a nonnegative integer or null; only rate limits populate
it. Success exits 0 and exit 3 is reserved. `transport_error` covers failure to
connect, CLI timeout, unreadable/oversized responses and invalid gateway envelopes.
`configuration_error` covers missing, unreadable or invalid CLI configuration. Local
argument errors use `invalid_input` or `unsupported_operation` and exit 2. All local
errors have null `request_id` and `retry_after_seconds`; they have no HTTP status.

### Using agentctl

Commands are `agentctl github pr list|view|diff|checks|feedback` and
`agentctl shortcut story get|search`. GitHub commands accept `--repo` and the
applicable `--number`, `--state`, `--limit` and `--cursor` flags. Shortcut commands
accept `--workspace` and the applicable `--id`, `--text`, `--type`, `--archived`,
`--limit` and `--cursor` flags. No passthrough flags are available.

Output is always JSON; `--json` is accepted for compatibility. The CLI emits one
response envelope on stdout for a completed request and reserves stderr for
diagnostics. Local errors use the same envelope with a null `request_id`. There are
no automatic retries.

`AGENTCTL_CONFIG` names an operator-provided JSON file containing only `gateway_url`.
The CLI receives no upstream configuration or credentials. It connects directly to
the gateway and ignores ambient proxy variables.

### Compatibility

Within v1, existing operations, required fields, types, meanings, defaults and error
codes remain stable. Optional response fields may be added; clients ignore unknown
response fields. New operations may be added without changing existing ones; older
servers return unsupported_operation when asked to use them. Clients must not send
new request fields to an older server: unknown-field rejection remains strict.

Documented closed enum sets do not gain new values in v1. Unconstrained string fields
(such as provider conclusions) may contain new strings, which clients preserve and
display without assuming a closed set. Removing/renaming fields or operations,
changing established semantics or defaults, or expanding a closed enum requires a
new major API version. API v1 and existing CLI commands continue to follow these
rules while supported.

## 3. Result semantics, pagination and limits

### GitHub checks

Checks include check runs and the latest commit status for each context on the
selected PR head. Traverse check runs first with `filter=latest`, then combined
commit-status results. Preserve provider order within each source; no global sort
or atomic snapshot is promised. GitHub may limit check runs to the most recent
1,000 check suites, so results represent what that endpoint exposes rather than
an exhaustive history.

Check pages bind the PR head SHA. A changed head invalidates the cursor, including
on replay. Check records retain the source ordering described above; no records are
silently discarded while switching sources.

| Provider commit status | Normalized status | Normalized conclusion |
|---|---|---|
| pending | in_progress | null |
| success | completed | success |
| error or failure | completed | failure |

For commit statuses, use `created_at` as the start time, `updated_at` as completion
time for completed entries, and `target_url` as the URL. Unknown check-run statuses
normalize to `unknown`; preserve the nullable conclusion.

### GitHub PR feedback

`github.pr.feedback` collects reviews, general discussion comments and inline
threads/replies. `agentctl github pr feedback --repo company/project --number 123
--limit 50` returns one page. Follow `next_cursor` with the same arguments to finish.
The CLI does not aggregate or poll automatically.

All page fields are required:

| Field | Meaning |
|---|---|
| `repo`, `number`, `head_sha` | Verified PR identity and head observed before this request's collection fetches |
| `reviews` | Review submissions, separate from their individual comments |
| `discussion_comments` | General PR discussion comments |
| `threads` | Inline thread fragments, potentially continued on other pages |
| `collections` | `reviews`, `discussion_comments`, `threads`: each `pending`, `partial` or `complete`, cumulative along this cursor chain |
| `status` | `partial`, `complete` or `limited` for the whole traversal |
| `next_cursor` | String for continuation (including a terminal cap cursor), or null on provider exhaustion |

Arrays are always present, including empty arrays. Every review/comment has `id`
(decimal string), `author` (login or null), `body` (verbatim Markdown or null when
unavailable), and `url` (GitHub link). IDs are scoped by repository, PR and category.
Unknown values are null, never inferred empty strings or false values.

Reviews add `state` (unconstrained provider string), `submitted_at` (UTC RFC3339 or
null), `updated_at` (null: unavailable from REST), and `commit_id` (SHA or null).
Discussion comments add `created_at` and `updated_at` (UTC RFC3339).

Each thread fragment contains `root_comment_id` (decimal string), `resolved` and
`outdated` (both null: unknown in this REST implementation), and `comments`.
Each inline comment has the discussion-comment fields plus:

- `review_id` and `in_reply_to_id`: decimal strings or null.
- `path`: file path; `diff_hunk`: string or null.
- `commit_id`, `original_commit_id`: commit SHAs; these may differ from the PR head.
- `line`, `original_line`, `start_line`, `original_start_line`: positive integers
  or null, preserving available current/original file coordinates.
- `side`, `start_side`: LEFT/RIGHT or null; `subject_type`: provider string or null.

Group fragments by `root_comment_id` across pages and deduplicate comments by ID.
The root ID is a top-level comment ID, not a GitHub GraphQL thread ID. Replies use
`in_reply_to_id` as their root ID; roots use their own ID. Preserve an absent root
reference: it may have been deleted, be on another page or be omitted by mutation.
A fragment does not assert thread completeness. Never infer resolved/outdated from
nullable lines or from a commit differing from the head.

Traversal visits review submissions first (provider chronological order), then
issue comments (ascending ID), then inline comments (created ascending). Replies
share the inline-comment pagination; there is no unbounded nested fetch. Each
review/comment, including each reply, consumes one item of the requested limit.
The adapter fetches at most one provider page per source per request plus the PR
lookup (at most four fetches). Source transitions may re-fetch an unconsumed or
partially consumed page; offsets preserve unchanged results without caching bodies.

A collection is pending until visited, partial while more records may remain, and
complete once its endpoint is exhausted. An empty intermediate page may have a
cursor. Overall complete means every collection was exhausted along this traversal,
not that the final page itself contains all feedback or that pages are a snapshot.
At the 10-page/500-item cap with more data, return status limited and a terminal
cursor. Its use returns limit_exceeded before provider contact. Feedback has no
narrowing filter; report the limitation rather than repeatedly restarting to evade
bounds. A source error fails the request; it never becomes an empty collection.
Previously successful pages remain partial observations if a later request fails.

Every continuation re-observes the PR head and rejects a change with invalid_cursor.
The head can still change after the lookup; no end-of-request or atomic-snapshot
claim is made. Feedback can change even when the head is stable, causing duplicates
or omissions in positional pagination.

To refresh, start without a cursor and compare complete chains by stable IDs and
full normalized records. This detects newer reviews, edits, state changes and new
replies to old threads. A review timestamp is not an edit watermark. Replace the
client baseline only after completing a successful chain; partial/limited chains
must not erase older observations. Missing records alone do not establish deletion.
No automatic polling, delta/since endpoint, persistent checkpoint or notification
is provided. Deleted feedback and private drafts invisible to the credential are
not promised. Unknown thread flags cannot be tracked as resolved/unresolved changes.

### Shortcut search

Search accepts Unicode letters and numbers plus ASCII spaces, trims and collapses
spaces, and rejects other syntax with `invalid_input`. Callers cannot submit
operators, quotes, escapes, wildcards, boolean expressions or punctuation. This
rejects common development terms such as `agent-gateway`, `foo.go` and `C++`.
Use story get when the story identifier is already known.

Results follow provider text-search semantics across titles, descriptions and
comments, in relevance order. There is no substring, exact-phrase or timestamp-order
guarantee. Check returned records locally: `archived` must exactly match the requested
boolean and `type` must match when supplied. Return only results from the verified
workspace-bound
token; mismatched workspace URLs or identifiers fail closed.

Search pages may be short or empty with a next_cursor when candidates remain;
empty pages still count toward the page cap. Return a null next_cursor only on
provider exhaustion. Search scans at most 500 candidates per traversal, including
rejected records; the common cap rules below define the terminal response.
Provider maximum-search-results errors map to limit_exceeded.

### Required resource limits

The v1 limits below apply to all requests and are fixed rather than configurable.

| Resource | Limit |
|---|---|
| Request body | 16 KiB |
| Gateway response | 1 MiB |
| Diff text | 512 KiB |
| Provider response per fetch | 4 MiB |
| Provider fetches per gateway request | 5 |
| Gateway request deadline | 15 seconds |
| Individual provider call timeout | At most 10 seconds |
| Concurrent gateway requests | 8 globally |
| Traversal | 10 response pages / 500 items; search also limits scanned candidates |
| Cursor lifetime / maximum encoded length | 10 minutes / 2,048 bytes |

Enforce byte limits while streaming, including decompressed content, before allocating
entire provider bodies. Never silently truncate results. Capacity overflow returns
`rate_limited` immediately; there is no unbounded queue.

### Cursor reuse and traversal caps

[Request and response examples](examples/pagination.md) illustrate continuation,
exhaustion, terminal cursors, invalid cursors and CLI-local errors.

These rules define the positional cursor model. Each page contains at
most the requested limit. Cursors are opaque, authenticated and confidential, at
most 2,048 bytes, and expose neither provider URLs nor search text. Bind them to
the policy revision, operation, canonical target, normalized arguments (including
limit), traversal counters and position. Recheck authorization on every use. Policy
changes or service restart invalidate cursors; expired, malformed, tampered or
mismatched cursors return invalid_cursor.

A traversal expires 10 minutes after its first successful page. Subsequent pages
and retries retain the original expiry. Initial requests without a cursor start
independent traversals. There is no cross-request cache of result pages or allocation
of a server-side slot for a cursor.

A cursor identifies a position, not a mutable iterator or a cached response. Reusing
it re-evaluates that position and may return different data or a different next_cursor
if upstream results change. Concurrent uses have the same independent-read semantics;
identical replay and an atomic provider snapshot are not promised. The request ID
and audit event are new on every attempt. Each attempt consumes normal concurrency,
deadline, fetch and byte budgets. Logical counters start from those sealed in the
input cursor; retries do not mutate a shared traversal counter.

Before returning results, check and feedback continuations still require a matching current PR
head, and Shortcut still verifies workspace identity. Normal authorization and identity failures take
precedence over releasing any data. Provider positions and offsets preserve remaining
records when results are unchanged; upstream changes can cause duplicates or omissions.

When enumerating, use `limit: 50`: ten full pages at the default limit of 20 return
only 200 items; a limit of 50 can reach the 500-item cap. Filtered search pages may
return fewer items. PR checks have no narrowing filter: report partial results on
limit_exceeded. Never combine check pages from different head SHAs or infer an
“all green” snapshot from a moving set, even when the head is unchanged.

Return a page that reaches a traversal cap: at most 10 pages, 500 returned items,
and for search 500 scanned candidates, including rejected candidates. Never scan or
return beyond the remaining allowance. If the provider is exhausted, return null
next_cursor. If more results remain, return a non-null terminal cursor; using that
cursor returns limit_exceeded with no data, instructing the caller to narrow the
request. Validate the cursor binding, expiry and authorization first. A terminal
cursor need not fetch provider data because it cannot release a result.

If the remaining candidate allowance stops a search partway through a provider page,
return matching items considered so far, possibly an empty page, with a terminal
cursor when candidates remain. An offset records partially consumed provider pages
for nonterminal continuations. Re-fetching an already consumed prefix spends request
fetch/byte budgets but does not consume logical candidates a second time.

If a nonterminal continuation exceeds the 2,048-byte encoded bound, return the
verified page with a compact terminal cursor instead. As at a traversal cap, using
that cursor returns limit_exceeded after binding, expiry and authorization checks,
without provider contact. The terminal cursor retains those bindings but omits the
provider continuation payload. It must fit the same byte bound. Never truncate a
provider token or claim exhaustion. The page and its terminal cursor still undergo
normal response-size and deadline checks. There is no stateful fallback. Request/provider body bounds and concurrency still bound transient memory.

## 4. Configuration and deployment interface

### Configuration and secrets

The [configuration schema](schemas/config.schema.json) and
[policy schema](schemas/policy.schema.json) describe the JSON files. Examples are in
[examples/](examples/), with mock and live configurations and a target policy:

```json
{
  "version": 1,
  "github": [{"repo": "company/project"}],
  "shortcut": [{"workspace": "engineering"}]
}
```

Configuration version 1 requires an explicit `mode` (mock/live), agent-interface
`listen_address`, `policy_file` and enabled-provider definitions. Reject unknown
fields, invalid targets, duplicate targets and invalid bounds. Runtime validation
also rejects wildcard or loopback listen addresses, dot-segment repository names,
normalized duplicate repositories or workspace aliases, and policy targets without
an enabled provider mapping. An enabled Shortcut provider needs at least one mapping;
a disabled provider cannot have allowed policy targets.

Shortcut mappings contain `alias`, `workspace_id` (UUID) and `token_file`. Live
GitHub requires `token_file`; live Shortcut requires one for every configured
workspace. Enabled live providers require readable, nonempty secret files. Mock
mode loads no upstream tokens and needs no upstream access.

Mount configuration and policy read-only under `/etc/agent-gateway`. Mount secrets
only into the gateway under `/run/secrets`: `github_token` and
`shortcut_<alias>` for the enabled providers. Token files use mode 0400 and are
readable only by the gateway UID; parent directories must be traversable by that UID.
These ownership requirements apply inside Linux container storage. The supplied
live deployment stages operator-owned private host sources into a dedicated Docker
named volume and mounts it read-only in the gateway. Do not rely on macOS UID
translation through a credential bind mount. Host tooling verifies actual access as
the gateway UID without displaying credential contents. The operator runbook covers
staging, rotation and migration from earlier bind-mount deployments.

### Deployment interface

The service endpoint is `http://agent-gateway:8080`. In fenced, its shared
development network is `go-agent-internal-net`.

Ship a versioned Linux OCI image for amd64 and arm64, CLI binaries for both
architectures, a Compose example, an operator runbook and a distributable agent
usage skill. Releases identify the image digest and CLI checksums. Local mock
examples may use a locally built tagged image.

The operator deploys the gateway and controls its network attachments. In fenced,
the shared network has a provisioned subnet and fixed gateway IP. Agent containers
have the verified CLI installed at `/usr/local/bin/agentctl`, the usage skill, and
the gateway endpoint configuration. Connections to the gateway DNS name and port
bypass the general proxy without expanding provider access. Host-only provisioning
instructions stay in the operator runbook.

The gateway joins the existing shared development network as `agent-gateway` and a
separate external network that gives it unrestricted direct internet access.
External-network membership is limited to operator-approved gateway
infrastructure; agents and development services do not join it. Fenced's shared
agent proxy allowlist stays unchanged. A mock deployment may omit the external network.

Bind the gateway listener only to its fixed shared-network IPv4 address. Startup
requires that address to exist locally. The external attachment must not expose the
listener, and no host port is published. The gateway cannot route, forward or proxy
agent traffic. Network egress is not an independent enforcement layer for provider
API restrictions: those remain application responsibilities. Exposure beyond the
shared network requires revisiting the access design.

| Runtime setting | Requirement |
|---|---|
| Command | `/usr/local/bin/agent-gateway --config /etc/agent-gateway/config.json` |
| UID / GID | 10001 / 10001 |
| Listener | Shared-network IPv4 only, port 8080 |
| Filesystem and privileges | Read-only root, all capabilities dropped, no-new-privileges, no privileged mode; no required persistent writable storage |
| Agent isolation | No gateway workspace/shared home, Docker socket or SSH access |
| Health | `GET /healthz` for process liveness; `GET /readyz` for validated configuration and loaded secrets; 200 or 503, no sensitive details or provider calls |
| Shutdown | SIGTERM stops new work, drains in-flight requests for at most 20 seconds, then exits; container stop grace is 25 seconds |

Health endpoints are reachable only through the same shared network and disclose no
caller or provider data. Readiness does not prove a live token has not expired;
provider failures remain explicit.

Container resource settings of 256 MiB memory, 1 CPU and 128 PIDs are starting
values for the deployment example, not normative service limits. Size them using
measurements from the actual image; the request and cursor limits in section 3
remain required at every supported deployment size.

### Credential replacement, revocation and audit

Credential and policy replacement must work without an image rebuild. There is no
hot reload in v1: replacement becomes effective only after restart with the new
files and after old requests have drained or terminated. Policy changes invalidate
all cursors. Upstream token revocation is performed at the provider. The
[operator runbook](RUNBOOK.md) describes file replacement and container recreation.

Direct access removal takes effect after the agent's connections are terminated and
its network membership is removed. Full revocation additionally requires terminating
its delegated activity and access through other member containers. Removing one
container does not revoke access belonging to another member. Already returned data
cannot be revoked, and the gateway cannot attribute or revoke delegation individually.

Emit one structured audit event per request with `request_id`, `operation` (or null),
normalized authorized `target` (or null), outcome code, `elapsed_ms` and
`upstream_status` (or null). Write logs to stdout/stderr; the operator controls
retention. Do not log raw input, search text, provider bodies, authorization headers
or secrets, including malformed input.


## 5. Provider adapter requirements

### Adding services and operations

Isolate provider-specific request construction, credential handling and response
translation behind adapters. Each new operation must declare its identifier, input
and output schemas, target and authorization rules, provenance basis, credential
requirements, and applicable limits. Integrations must use shared request validation, policy enforcement,
error handling, audit and resource-limit enforcement, with provider-specific checks
where necessary.

Adding an integration may introduce target types and extend operation registration,
policy and configuration schemas, credential configuration, and CLI commands, but
must not require changes to unrelated provider adapters. Additions must remain
backward compatible within the current API version, following section 2.

Integrations are shipped through normal software releases. Provider origins and
supported request paths are defined by trusted implementation code; callers cannot
register integrations, supply arbitrary endpoints, or bypass shared controls.
A generic plugin framework, dynamic loading and an adapter SDK are not required.

### Shared transport requirements

The initial integrations use direct REST adapters: GitHub's API at `https://api.github.com` and Shortcut REST
v3 at `https://api.app.shortcut.com`. Provider TLS verifies the origin hostname and
trusted public CAs. Do not intercept TLS or disable verification. The gateway ignores
`HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY` and `NO_PROXY`, including lowercase variants,
and connects directly.

Provider origins and request paths are constructed inside the gateway. Reject
redirects in v1. Continuation URLs must match the provider origin and expected
operation path, contain no userinfo, fragment or nondefault port, and contain only
allowed continuation parameters. Validate the parameters and reconstruct the next
request internally. Malformed continuation produces `upstream_unavailable`.

### GitHub

Send `X-GitHub-Api-Version: 2026-03-10` and `Accept: application/vnd.github+json`;
use `application/vnd.github.diff` for diffs. Read PRs from
`/repos/{owner}/{repo}/pulls` and `/repos/{owner}/{repo}/pulls/{number}`. Resolve
the PR head before reading `/repos/{owner}/{repo}/commits/{sha}/check-runs` and
`/repos/{owner}/{repo}/commits/{sha}/status`.

Feedback uses GET `/repos/{owner}/{repo}/pulls/{number}/reviews`,
`/repos/{owner}/{repo}/issues/{number}/comments`, and
`/repos/{owner}/{repo}/pulls/{number}/comments`, following a verified PR lookup.
Returned resource links must identify that PR/repository. Continuations are validated
and rebuilt using the authorized paths. Fine-grained tokens need Pull requests:
read; that permission also permits the issue-comment read used for PR discussion.
No GraphQL or transport-policy extension is used.

Classic PAT access to private-repository checks requires `repo` scope. The operator
runbook must describe the token's broad privileges, including write access; the
gateway's read-only guarantee must not depend on a read-only upstream token.

### Shortcut

Send the `Shortcut-Token` header. Before each story operation, read `/api/v3/member`
and require `workspace2.id` to match the configured workspace UUID. Missing identity
or a mismatch returns `upstream_authorization` without releasing story data. A
name or URL-slug match is insufficient. After verifying the UUID, validate story
URLs against `workspace2.url_slug` from that same response, not the operator alias. Authentication errors, rate limits, timeouts
and transport failures retain their defined error categories. This verification
counts toward the request's fetch and deadline limits.

Use `/api/v3/stories/{id}` for story retrieval and `/api/v3/search/stories` for
search. Operator workspace mappings associate the agent-facing alias with the
expected UUID and a token file. Story owner IDs are strings, reflecting provider UUIDs.

### Selected implementation design

The module boundaries and execution flow are described in
[DESIGN.md](DESIGN.md); observable requirements remain in this specification.

The following algorithms are the current design, rather than extra CLI/API guarantees.
They may be replaced if ordering, replay, authorization, expiry, fetch/memory bounds
and correct continuation of unchanged provider results remain as specified in section 3.

- Check traversal resolves the PR head on every request, tracks source/provider page,
  and fetches at most one page per source with per_page=limit. It may fill remaining
  capacity from the next source. A source/page/offset position replaces buffered
  unused records; a later request re-fetches the partial provider page.
- Shortcut search verifies workspace identity, then fetches at most four full-result
  pages with page_size=limit. It generates type:<enum> and is:archived filters from
  typed arguments and checks returned type/archive values locally. Full results
  avoid per-item retrieval; a validated provider token and candidate offset record
  where to resume without storing unused candidates.
- The positional model seals compact continuation data with authenticated
  encryption under an in-memory startup key. It retains no successful pages, buffers
  or per-cursor state; restarting replaces the key. See DESIGN for the codec boundary.

## 6. Verification requirements

Each integration must pass shared conformance tests for authorization, read-only
access, error handling, resource limits and credential non-disclosure, plus tests
of its provider-specific behavior. Each operation must include wrong-identity
fixtures proving rejection; where the result has no identity, exercise a mismatched
identity in the required lookup. Test endpoint construction as part of provenance.

The [domain rules](DOMAIN.md#rules-that-every-read-follows) organize verification:

| Rule | Required verification |
|---|---|
| R1 | Invalid arguments and denied scopes cause no provider contact, including identity lookups. |
| R2 | Wrong identities fail closed and requests use authorized endpoints. |
| R3 | Only read-semantics endpoints and allowed methods execute; credentials do not leak. |
| R4 | Resource bounds, positional replay, cap handling and invalidation match section 3. |
| R5 | Malformed and rejected requests yield safe records; sink failures are handled explicitly. |
| R6 | A synthetic integration exercises shared controls. Dependency tests reject imports of unrelated integrations or the HTTP adapter; change review verifies that unrelated integrations needed no edits. |

Tests should cite these rule identifiers where useful; this table states required
coverage, not a claim that every test has been implemented.

Automated service tests cover denial before adapter invocation, direct HTTP schema
and target checks, normalized adapter behavior, fixed-origin request construction,
read-only enforcement, TLS, safe audit output, redirect and pagination validation,
timeouts, rate limits, authentication failures, sizes and concurrency. Provide
mock fixtures for all seven supported reads. Synthetic secrets detect leaks; write-capable
provider fixtures demonstrate that read-only behavior is enforced by the gateway.

Integration tests run the actual gateway image in fenced and check CLI and skill
installation, authorized shared-network access, denial from nonmembers and listener
isolation on every attachment. Agents must be unable to read upstream secrets,
change gateway code or policy, access Docker, reach providers directly, or use the
gateway for application forwarding or network routing. Binding configuration alone
is not proof that unrestricted gateway egress leaves agent restrictions intact.

Test direct access removal separately from full revocation. Demonstrate that a
surviving delegated service retains access until removed, then verify that stopped
or disconnected containers cannot reconnect without restored membership. Also test
credential replacement and revocation, malformed policy,
missing live secrets, all seven mock operations and the real integration boundary.
A live smoke test is optional and requires private operator provisioning.

Exercise reuse of the same position with stable and changed provider results,
concurrent reuse, mismatched arguments, expired/tampered tokens, restart, policy
changes and changed PR heads. Confirm positional replay does not mutate shared state
and every attempt retains normal authorization and resource limits. Test the tenth
page and 500-item/candidate boundaries: return the capped page, then reject its
terminal continuation when more results remain. Verify null only on actual exhaustion.
Test partial-page offsets, empty filtered pages and both fitting and oversized
continuation tokens: an oversized continuation preserves the verified page with a
bounded terminal cursor, whose use fails without provider contact. Test missing or
invalid workspace identity on nonterminal continuation. For each paginated operation
(PR list, PR checks, PR feedback and story search), test its worst-case fetch path against the
five-fetch limit, including identity lookups, partial-page re-fetches and source/page
transitions. Test Shortcut continuation extraction from provider paths/URLs and
reconstruction from bound arguments, without sealing the full URL or repeated query.
Check CLI-local envelopes/codes and compatibility with unknown response fields.

## References

- [GitHub pull requests](https://docs.github.com/en/rest/pulls/pulls)
- [GitHub check runs](https://docs.github.com/en/rest/checks/runs)
- [GitHub commit statuses](https://docs.github.com/en/rest/commits/statuses)
- [GitHub API versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
- [Shortcut REST v3](https://developer.shortcut.com/api/rest/v3)
- [Shortcut search operators](https://www.shortcut.com/help/fields-and-features/search-operators/)
