#!/usr/bin/env python3
"""Operator-only interactive provisioning; never pass token values as arguments."""

import argparse
import getpass
import ipaddress
import json
import os
from pathlib import Path
import re
import ssl
import sys
import stat
import tempfile
import urllib.error
import urllib.request
import uuid
import warnings
from credential_volume import CredentialVolume, VolumeError


class ProvisionError(Exception):
    """A safe operator-facing error with no credential or provider body content."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProvisionError("Shortcut redirected the request; provisioning stopped")


def credential(prompt):
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        value = getpass.getpass(prompt).strip()
    if not value or len(value.encode()) > 8192 or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise ProvisionError("Token is empty, oversized or contains invalid characters")
    return value


def workspace(token, expected_slug, opener=None):
    if opener is None:
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), NoRedirect(),
            urllib.request.HTTPSHandler(context=ssl.create_default_context()),
        )
    request = urllib.request.Request(
        "https://api.app.shortcut.com/api/v3/member",
        headers={"Shortcut-Token": token, "Accept": "application/json"}, method="GET",
    )
    try:
        with opener.open(request, timeout=10) as response:
            if response.status != 200:
                raise ProvisionError("Shortcut did not return a successful member response")
            data = response.read((4 << 20) + 1)
        if len(data) > 4 << 20:
            raise ProvisionError("Shortcut member response exceeds the size limit")
        value = json.loads(data)["workspace2"]
        workspace_id = str(uuid.UUID(value["id"]))
        if value["url_slug"] != expected_slug:
            raise ProvisionError("Shortcut token workspace does not match the requested slug")
        return workspace_id
    except urllib.error.HTTPError as error:
        raise ProvisionError(f"Shortcut returned HTTP {error.code}; check token/workspace access") from None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, KeyError, TypeError, AttributeError):
        raise ProvisionError("Shortcut identity lookup failed or returned invalid metadata") from None


def write_new(path, value, mode):
    # Exclusive creation also rejects a pre-existing symlink. Never overwrite credentials.
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    with os.fdopen(descriptor, "w") as stream:
        stream.write(value)
        os.fchmod(stream.fileno(), mode)


def initialize(args):
    if not sys.stdin.isatty():
        raise ProvisionError("Run interactively in a trusted host terminal; token input must not be piped")
    address = ipaddress.IPv4Address(args.agent_ip)
    if address.is_unspecified or address.is_loopback or address.is_multicast or address.is_link_local:
        raise ProvisionError("Choose the reserved agent-network IPv4 address")
    for value in (args.shortcut_alias, args.shortcut_slug):
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", value):
            raise ProvisionError("Invalid workspace alias or slug")
    repos = sorted(set(repo.lower() for repo in args.repo))
    if any(not re.fullmatch(r"[a-z0-9_.-]+/[a-z0-9_.-]+", repo) or
           any(part in (".", "..") for part in repo.split("/")) for repo in repos):
        raise ProvisionError("Invalid repository name")
    directory = args.directory.expanduser().absolute()
    # This helper initializes a new directory only; rotation follows the runbook.
    if directory.exists() or directory.is_symlink():
        raise ProvisionError("Runtime already exists; use configure, rotate or check (nothing changed)")
    github = credential("GitHub token (hidden): ")
    shortcut = credential("Shortcut token (hidden): ")
    workspace_id = workspace(shortcut, args.shortcut_slug)
    print("Verified Shortcut workspace:", args.shortcut_slug, workspace_id)
    if input("Create runtime files for this workspace? [yes/no] ").strip().lower() != "yes":
        raise ProvisionError("No files created")
    directory.mkdir(mode=0o700, parents=False)
    config_dir, secrets_dir = directory / "config", directory / "secrets"
    config_dir.mkdir(mode=0o700)
    secrets_dir.mkdir(mode=0o700)
    secret_name = "shortcut_" + args.shortcut_alias
    config = {"version": 1, "mode": "live", "listen_address": str(address) + ":8080",
              "policy_file": "/etc/agent-gateway/policy.json", "providers": {
                  "github": {"enabled": True, "token_file": "/run/secrets/github_token"},
                  "shortcut": {"enabled": True, "workspaces": [{"alias": args.shortcut_alias,
                      "workspace_id": workspace_id, "token_file": "/run/secrets/" + secret_name}]}}}
    policy = {"version": 1, "github": [{"repo": repo} for repo in repos],
              "shortcut": [{"workspace": args.shortcut_alias}]}
    write_new(secrets_dir / "github_token", github, 0o400)
    write_new(secrets_dir / secret_name, shortcut, 0o400)
    write_new(config_dir / "config.json", json.dumps(config, indent=2) + "\n", 0o444)
    write_new(config_dir / "policy.json", json.dumps(policy, indent=2) + "\n", 0o444)
    stage(args)
    print("Runtime files created and staged into the Docker credential volume.")
    print("Configuration directory:", config_dir)
    print("Dedicated secret directory:", secrets_dir)
    print("No service started; GitHub permissions and live operations remain unverified.")


def read_json(path):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ProvisionError("Duplicate configuration field")
            out[key] = value
        return out
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1 << 20:
        raise ProvisionError("Configuration must be a bounded regular file, not a symlink")
    return json.loads(path.read_text(), object_pairs_hook=unique)


def runtime(directory):
    directory = directory.expanduser().absolute()
    for folder in (directory, directory / "config", directory / "secrets"):
        if folder.is_symlink() or not folder.is_dir():
            raise ProvisionError("Runtime directories must exist and must not be symlinks")
        if folder.stat().st_mode & 0o022:
            raise ProvisionError("Runtime directories must not be writable by group or others")
    return directory


def validate(config, policy):
    # Host preflight for the supported v1 layout; gateway validation remains authoritative.
    if set(config) != {"version", "mode", "listen_address", "policy_file", "providers"}:
        raise ProvisionError("Invalid configuration fields")
    if config["version"] != 1 or config["mode"] != "live" or config["policy_file"] != "/etc/agent-gateway/policy.json":
        raise ProvisionError("Invalid live configuration")
    ip, port = config["listen_address"].split(":")
    address = ipaddress.IPv4Address(ip)
    if port != "8080" or address.is_unspecified or address.is_loopback or address.is_multicast or address.is_link_local:
        raise ProvisionError("Invalid gateway listen address")
    providers = config["providers"]
    if set(providers) != {"github", "shortcut"} or set(policy) != {"version", "github", "shortcut"} or policy["version"] != 1:
        raise ProvisionError("Unsupported provider or policy layout")
    gh, sc = providers["github"], providers["shortcut"]
    if set(gh) - {"enabled", "token_file"} or set(sc) != {"enabled", "workspaces"}:
        raise ProvisionError("Invalid provider fields")
    if type(gh.get("enabled")) is not bool or type(sc["enabled"]) is not bool:
        raise ProvisionError("Provider enabled fields must be boolean")
    if gh.get("token_file", "") not in ("", "/run/secrets/github_token") or (gh["enabled"] and not gh.get("token_file")):
        raise ProvisionError("Invalid GitHub credential path")
    files = ["github_token"] if gh["enabled"] else []
    aliases = set()
    for mapping in sc["workspaces"]:
        if set(mapping) != {"alias", "workspace_id", "token_file"}:
            raise ProvisionError("Invalid workspace mapping fields")
        alias = mapping["alias"]
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", alias) or alias in aliases:
            raise ProvisionError("Invalid or duplicate workspace alias")
        uuid.UUID(mapping["workspace_id"])
        if mapping["token_file"] != "/run/secrets/shortcut_" + alias:
            raise ProvisionError("Invalid Shortcut credential path")
        aliases.add(alias)
        if sc["enabled"]:
            files.append("shortcut_" + alias)
    if sc["enabled"] and not aliases:
        raise ProvisionError("Enabled Shortcut needs a workspace mapping")
    repos = set()
    for entry in policy["github"]:
        if set(entry) != {"repo"} or not gh["enabled"]:
            raise ProvisionError("Invalid or disabled repository policy")
        repo = entry["repo"].lower()
        if not re.fullmatch(r"[a-z0-9_.-]+/[a-z0-9_.-]+", repo) or any(p in (".", "..") for p in repo.split("/")) or repo in repos:
            raise ProvisionError("Invalid or duplicate repository policy")
        repos.add(repo)
    allowed = set()
    for entry in policy["shortcut"]:
        if set(entry) != {"workspace"} or entry["workspace"] not in aliases or not sc["enabled"] or entry["workspace"] in allowed:
            raise ProvisionError("Invalid workspace policy")
        allowed.add(entry["workspace"])
    return files


def replace_file(path, value, mode, owner):
    # Write a private sibling then rename; a failed write/chown leaves the old file intact.
    descriptor, temporary = tempfile.mkstemp(prefix=".runtime-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(value)
            if (os.fstat(stream.fileno()).st_uid, os.fstat(stream.fileno()).st_gid) != owner:
                os.fchown(stream.fileno(), *owner)
            os.fchmod(stream.fileno(), mode)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def configure(args):
    directory = runtime(args.directory)
    config = read_json(directory / "config/config.json")
    policy = read_json(directory / "config/policy.json")
    # Complete replacement documents permit multiple/disabled providers without
    # introducing a second set of per-provider update flags.
    if not args.config_file and not args.policy_file:
        raise ProvisionError("Provide --config-file and/or --policy-file with desired non-secret JSON")
    if args.config_file:
        config = read_json(args.config_file)
    if args.policy_file:
        policy = read_json(args.policy_file)
    validate(config, policy)
    for name, value, selected in (("config.json", config, args.config_file), ("policy.json", policy, args.policy_file)):
        if selected:
            path = directory / "config" / name
            info = path.stat()
            replace_file(path, json.dumps(value, indent=2) + "\n", 0o444, (info.st_uid, info.st_gid))
    print("Configuration updated; credentials unchanged. Run check before explicit container recreation.")
    print("If adding a workspace, use rotate with that alias to provision its token first.")


def rotate(args):
    directory = runtime(args.directory)
    config = read_json(directory / "config/config.json")
    files = validate(config, read_json(directory / "config/policy.json"))
    if args.provider == "github":
        name, mapping = "github_token", None
    elif args.provider == "shortcut":
        mapping = next((w for w in config["providers"]["shortcut"]["workspaces"] if w["alias"] == args.shortcut_alias), None)
        if mapping is None or not args.shortcut_slug:
            raise ProvisionError("Select an existing Shortcut alias and expected slug")
        name = "shortcut_" + mapping["alias"]
    else:
        raise ProvisionError("Select provider github or shortcut")
    if name not in files:
        raise ProvisionError("Provider is disabled")
    path = directory / "secrets" / name
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ProvisionError("Credential path must be a regular file, not a symlink")
    if not sys.stdin.isatty():
        raise ProvisionError("Run rotation interactively in a trusted host terminal")
    value = credential("Replacement token (hidden): ")
    if mapping and workspace(value, args.shortcut_slug) != str(uuid.UUID(mapping["workspace_id"])):
        raise ProvisionError("Replacement token does not match configured workspace UUID; unchanged")
    replace_file(path, value, 0o400, (os.geteuid(), os.getegid()))
    volume = selected_volume(args)
    volume.ensure()
    volume.put(name, value.encode())
    volume.check(files)
    print("Credential replaced. Recreate the gateway explicitly to activate; revoke the old token at its provider after verification.")


def check(args):
    directory = runtime(args.directory)
    config = read_json(directory / "config/config.json")
    files = validate(config, read_json(directory / "config/policy.json"))
    for name in ("config.json", "policy.json"):
        mode = (directory / "config" / name).stat().st_mode
        if mode & 0o022 or not mode & 0o004:
            raise ProvisionError("Configuration must be gateway-readable and not group/other writable")
    source_files(directory, files, read=False)
    selected_volume(args).check(files)
    print("Host metadata and Docker credential access checks passed as UID 10001; no contents printed.")
    print("Live provider permissions and actual gateway startup still require deployment verification.")


def selected_volume(args):
    return CredentialVolume(args.secrets_volume, args.helper_image)


def source_files(directory, files, *, read):
    if {p.name for p in (directory / "secrets").iterdir()} != set(files):
        raise ProvisionError("Private source directory contains missing or unexpected files")
    values = {}
    for name in files:
        path = directory / "secrets" / name
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o400 or info.st_uid != os.geteuid() or not 0 < info.st_size <= 8192:
            raise ProvisionError("Source token must be operator-owned, regular, mode 0400 and bounded: " + name)
        if read:
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(descriptor, "rb") as stream:
                if (os.fstat(stream.fileno()).st_dev, os.fstat(stream.fileno()).st_ino) != (info.st_dev, info.st_ino):
                    raise ProvisionError("Source credential changed during staging")
                value = stream.read(8193)
            if not value or len(value) > 8192:
                raise ProvisionError("Source credential has invalid size")
            values[name] = value
    return values


def stage(args):
    directory = runtime(args.directory)
    files = validate(read_json(directory / "config/config.json"), read_json(directory / "config/policy.json"))
    values = source_files(directory, files, read=True)
    volume = selected_volume(args)
    volume.ensure()
    for name, value in values.items():
        volume.put(name, value)
    volume.check(files)
    print("Credentials staged and verified inside Docker; recreate the gateway explicitly to activate.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "configure", "rotate", "check", "stage"))
    parser.add_argument("--directory", type=Path, default=os.getenv("RUNTIME_DIR") or None)
    parser.add_argument("--repo", action="append", default=None)
    parser.add_argument("--shortcut-alias", default=os.getenv("SHORTCUT_ALIAS"))
    parser.add_argument("--shortcut-slug", default=os.getenv("SHORTCUT_SLUG"))
    parser.add_argument("--agent-ip", default=os.getenv("AGENT_IP"))
    parser.add_argument("--provider", default=os.getenv("PROVIDER"))
    parser.add_argument("--config-file", type=Path, default=os.getenv("CONFIG_FILE") or None)
    parser.add_argument("--policy-file", type=Path, default=os.getenv("POLICY_FILE") or None)
    parser.add_argument("--secrets-volume", default=os.getenv("GATEWAY_SECRETS_VOLUME"))
    parser.add_argument("--helper-image", default=os.getenv("CREDENTIAL_HELPER_IMAGE"))
    args = parser.parse_args()
    if not args.directory:
        raise ProvisionError("Set RUNTIME_DIR or --directory to the private runtime directory")
    if args.action == "init":
        args.repo = args.repo or os.getenv("REPOS", "").split()
        if not args.repo or not args.shortcut_alias or not args.shortcut_slug or not args.agent_ip:
            raise ProvisionError("Init requires repos, Shortcut alias/slug and agent IP")
        initialize(args)
    else:
        {"configure": configure, "rotate": rotate, "check": check, "stage": stage}[args.action](args)


if __name__ == "__main__":
    try:
        main()
    except (ProvisionError, VolumeError, OSError, ValueError, KeyError, TypeError, AttributeError, getpass.GetPassWarning, EOFError, KeyboardInterrupt) as error:
        message = str(error) if isinstance(error, (ProvisionError, VolumeError)) else "Provisioning stopped; inspect file presence/permissions before retrying"
        print(message, file=sys.stderr)
        sys.exit(1)
