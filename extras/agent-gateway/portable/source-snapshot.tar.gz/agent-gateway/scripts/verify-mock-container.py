#!/usr/bin/env python3
"""Verify this work item's running mock container; leave it running after SIGTERM test."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
CONTAINER = "agent-gateway-mock-agent-gateway-1"
NETWORK = "go-agent-internal-net"


def docker(*args, **kwargs):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=60, **kwargs)


def inspect():
    result = docker("inspect", CONTAINER, check=True)
    return json.loads(result.stdout)[0]


def ready():
    for _ in range(20):
        state = inspect()
        if state["State"].get("Health", {}).get("Status") == "healthy":
            return state
        if not state["State"]["Running"]:
            raise RuntimeError("mock gateway is not running")
        time.sleep(1)
    raise RuntimeError("mock gateway did not become healthy")


def main():
    current = ready()
    host = current["HostConfig"]
    assert current["Config"]["User"] == "10001:10001"
    assert host["ReadonlyRootfs"] and host["CapDrop"] == ["ALL"]
    assert "no-new-privileges:true" in host["SecurityOpt"] or "no-new-privileges" in host["SecurityOpt"]
    assert not host["PortBindings"] and not host["Privileged"]
    assert host["Sysctls"]["net.ipv4.ip_forward"] == "0"
    assert host["Sysctls"]["net.ipv6.conf.all.forwarding"] == "0"
    assert set(current["NetworkSettings"]["Networks"]) == {NETWORK}
    assert len(current["Mounts"]) == 2 and all(not m["RW"] for m in current["Mounts"])
    assert {m["Destination"] for m in current["Mounts"]} == {"/etc/agent-gateway/config.json", "/etc/agent-gateway/policy.json"}
    results = []
    cases = [
        (["github", "pr", "list", "--repo", "company/project", "--limit", "50"], 0),
        (["github", "pr", "view", "--repo", "company/project", "--number", "123"], 0),
        (["github", "pr", "diff", "--repo", "company/project", "--number", "123"], 0),
        (["github", "pr", "checks", "--repo", "company/project", "--number", "123", "--limit", "50"], 0),
        (["github", "pr", "feedback", "--repo", "company/project", "--number", "123", "--limit", "50"], 0),
        (["shortcut", "story", "get", "--workspace", "engineering", "--id", "456"], 0),
        (["shortcut", "story", "search", "--workspace", "engineering", "--text", "gateway", "--limit", "50"], 0),
        (["github", "pr", "view", "--repo", "forbidden/project", "--number", "1"], 4),
        (["github", "pr", "list", "--repo", "company/project", "--cursor", "invalid"], 2),
    ]
    for args, expected in cases:
        result = docker("run", "--rm", "--network", NETWORK, "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--mount", f"type=bind,src={ROOT / 'deploy/agentctl.json'},dst=/etc/agentctl/config.json,readonly", "--env", "AGENTCTL_CONFIG=/etc/agentctl/config.json", "--env", "HTTP_PROXY=http://127.0.0.1:1", "--env", "HTTPS_PROXY=http://127.0.0.1:1", "--env", "ALL_PROXY=http://127.0.0.1:1", "--entrypoint", "/usr/local/bin/agentctl", current["Image"], *args)
        assert result.returncode == expected, (args, result.returncode, result.stdout, result.stderr)
        envelope = json.loads(result.stdout)
        assert envelope["version"] == "v1" and envelope["request_id"]
        if expected == 0:
            assert "data" in envelope and "error" not in envelope
        else:
            assert envelope["error"]["code"] == {4: "policy_denied", 2: "invalid_cursor"}[expected]
        results.append({"command": " ".join(args), "exit": result.returncode})
        print("PASS", " ".join(args), flush=True)
    started = time.monotonic()
    docker("stop", "--time", "25", CONTAINER, check=True)
    elapsed = time.monotonic() - started
    stopped = inspect()
    try:
        assert stopped["State"]["ExitCode"] == 0 and not stopped["State"]["OOMKilled"]
        assert elapsed < 25
    finally:
        docker("start", CONTAINER, check=True)
    ready()
    evidence = {"image_id": current["Image"], "container": CONTAINER, "network": NETWORK, "ipv4": current["NetworkSettings"]["Networks"][NETWORK]["IPAddress"], "checks": results, "runtime_constraints": "passed", "idle_sigterm_exit": stopped["State"]["ExitCode"], "stop_seconds": elapsed, "restart_healthy": True, "limitations": "Mock ARM64 image only; no Fenced image install, live provider, active-request shutdown or second-interface isolation proof."}
    target = ROOT / "dist/mock/verification.json"
    target.write_text(json.dumps(evidence, indent=2) + "\n")
    print("PASS runtime restrictions, idle SIGTERM and healthy restart; evidence:", target)


if __name__ == "__main__":
    main()
