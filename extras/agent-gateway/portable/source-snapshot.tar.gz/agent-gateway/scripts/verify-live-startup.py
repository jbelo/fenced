#!/usr/bin/env python3
"""Verify named-volume provisioning and live startup with synthetic credentials.

Requires Docker and a locally built gateway image plus a trusted shell-equipped
helper image. Never accepts real credentials; never joins the agent network.
"""

import argparse
import ipaddress
import json
import pathlib
import subprocess
import tempfile
import time
import uuid
import importlib.util
from types import SimpleNamespace
from unittest import mock

spec = importlib.util.spec_from_file_location("provision", pathlib.Path(__file__).with_name("provision-runtime.py"))
provision = importlib.util.module_from_spec(spec)
spec.loader.exec_module(provision)


def docker(*args, check=True):
    result = subprocess.run(["docker", *args], check=False, capture_output=True, text=True)
    if check and result.returncode:
        raise RuntimeError("Docker verification failed: " + result.stderr.strip())
    return result


def inspect(name):
    return json.loads(docker("inspect", name).stdout)[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True)
    parser.add_argument("--helper-image", required=True)
    parser.add_argument("--output", default="dist/live/startup-verification.json")
    args = parser.parse_args()
    prefix = "gateway-startup-" + uuid.uuid4().hex[:10]
    network, container = prefix + "-net", prefix
    volume_name = prefix + "-credentials"
    results = []
    image = inspect(args.image)["Id"]
    helper = inspect(args.helper_image)["Id"]
    try:
        docker("network", "create", "--internal", network)
        subnet = ipaddress.ip_network(inspect(network)["IPAM"]["Config"][0]["Subnet"])
        # Docker requires an explicit subnet for a statically assigned listener IP.
        docker("network", "rm", network)
        docker("network", "create", "--internal", "--subnet", str(subnet), network)
        address = str(subnet.network_address + 10)
        staging = pathlib.Path("dist/live").resolve()
        staging.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=prefix, dir=staging) as tmp:
            root = pathlib.Path(tmp)
            root.chmod(0o755)
            secrets = root / "secrets"
            secrets.mkdir(mode=0o700)
            config_dir = root / "config"
            config_dir.mkdir()
            config = {
                "version": 1, "mode": "live", "listen_address": address + ":8080",
                "policy_file": "/etc/agent-gateway/policy.json",
                "providers": {
                    "github": {"enabled": True, "token_file": "/run/secrets/github_token"},
                    "shortcut": {"enabled": True, "workspaces": [{
                        "alias": "exoscale", "workspace_id": "11111111-1111-4111-8111-111111111111",
                        "token_file": "/run/secrets/shortcut_exoscale",
                    }]},
                },
            }
            policy = {"version": 1, "github": [{"repo": "exoscale/kms"}],
                      "shortcut": [{"workspace": "exoscale"}]}
            (config_dir / "config.json").write_text(json.dumps(config))
            (config_dir / "config.json").chmod(0o444)
            for fault in ("none", "missing-github", "missing-shortcut", "permissions", "empty", "whitespace", "policy"):
                for name, token in (("github_token", "synthetic-github"), ("shortcut_exoscale", "synthetic-shortcut")):
                    path = secrets / name
                    if path.exists():
                        path.chmod(0o600)
                    path.write_text(token)
                    path.chmod(0o400)
                if (config_dir / "policy.json").exists():
                    (config_dir / "policy.json").chmod(0o644)
                (config_dir / "policy.json").write_text(json.dumps(policy))
                (config_dir / "policy.json").chmod(0o444)
                settings = SimpleNamespace(directory=root, secrets_volume=volume_name, helper_image=helper)
                provision.stage(settings)
                provision.check(settings)
                volume = provision.selected_volume(settings)
                if fault == "none":
                    settings.provider = "github"
                    with mock.patch.object(provision.sys.stdin, "isatty", return_value=True), mock.patch.object(provision, "credential", return_value="synthetic-rotated"):
                        provision.rotate(settings)
                    if (secrets / "github_token").read_text() != "synthetic-rotated":
                        raise RuntimeError("rotation did not replace private source")
                    volume.run('test "$(cat /run/secrets/github_token)" = synthetic-rotated; test "$(cat /run/secrets/shortcut_exoscale)" = synthetic-shortcut', [])
                    for bad in ("touch /run/secrets/unexpected", "mv /run/secrets/github_token /run/secrets/saved; ln -s saved /run/secrets/github_token"):
                        volume.run(bad, [], writable=True)
                        try:
                            provision.check(settings)
                        except provision.VolumeError:
                            pass
                        else:
                            raise RuntimeError("unsafe volume contents accepted")
                        volume.run('rm -f /run/secrets/unexpected; if test -f /run/secrets/saved; then rm /run/secrets/github_token; mv /run/secrets/saved /run/secrets/github_token; fi', [], writable=True)
                    provision.check(settings)

                changes = {
                    "missing-github": "rm /run/secrets/github_token",
                    "missing-shortcut": "rm /run/secrets/shortcut_exoscale",
                    "permissions": "chmod 0444 /run/secrets/github_token",
                    "empty": ": > /run/secrets/shortcut_exoscale",
                    "whitespace": "printf 'invalid token' > /run/secrets/github_token",
                }
                if fault in changes:
                    volume.run(changes[fault], [], writable=True)
                    if fault != "whitespace":
                        try:
                            provision.check(settings)
                        except provision.VolumeError:
                            pass
                        else:
                            raise RuntimeError("volume preflight accepted " + fault)
                if fault == "policy":
                    (config_dir / "policy.json").chmod(0o644)
                    (config_dir / "policy.json").write_text("{}")
                    (config_dir / "policy.json").chmod(0o444)
                docker("run", "-d", "--name", container, "--network", network,
                       "--ip", address, "--user", "10001:10001", "--read-only",
                       "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
                       "--sysctl", "net.ipv4.ip_forward=0",
                       "--sysctl", "net.ipv6.conf.all.forwarding=0",
                       "--memory", "256m", "--cpus", "1", "--pids-limit", "128",
                       "--mount", "type=bind,src=" + str(config_dir) + ",dst=/etc/agent-gateway,readonly",
                       "--mount", "type=volume,src=" + volume_name + ",dst=/run/secrets,readonly", image)
                try:
                    deadline = time.monotonic() + 20
                    while True:
                        state = inspect(container)["State"]
                        if not state["Running"] or state.get("Health", {}).get("Status") == "healthy":
                            break
                        if time.monotonic() >= deadline:
                            raise RuntimeError("startup verification timed out: " + fault)
                        time.sleep(0.2)
                    if fault == "none":
                        if not state["Running"] or state["Health"]["Status"] != "healthy":
                            raise RuntimeError("valid synthetic credential startup failed")
                        docker("stop", "--time", "25", container)
                        if inspect(container)["State"]["ExitCode"] != 0:
                            raise RuntimeError("graceful stop failed")
                    elif state["Running"] or state["ExitCode"] == 0:
                        raise RuntimeError("bad startup configuration accepted: " + fault)
                    logs = docker("logs", container)
                    if any(value in logs.stdout + logs.stderr for value in
                           ("synthetic-github", "synthetic-shortcut", "synthetic-rotated", "invalid token")):
                        raise RuntimeError("synthetic credential appeared in logs")
                    results.append({"case": fault, "passed": True})
                    print(fault + ": passed")
                finally:
                    docker("rm", "-f", container, check=False)
    finally:
        docker("rm", "-f", container, check=False)
        docker("network", "rm", network, check=False)
        docker("volume", "rm", volume_name, check=False)
    output = pathlib.Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"image": image, "helper_image": helper, "checks": results, "volume_checks": ["maintained stage/check", "selected-provider rotation", "other credential preserved", "unexpected files rejected", "symlinks rejected"],
        "limitations": "Synthetic operator-owned sources staged through maintained runtime-stage/check into a Docker volume; no live providers, agent network or external attachment tested."}, indent=2) + "\n")


if __name__ == "__main__":
    main()
