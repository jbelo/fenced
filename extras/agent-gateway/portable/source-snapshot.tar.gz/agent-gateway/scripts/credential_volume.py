"""Private Docker credential storage; payloads travel only over subprocess stdin."""
import json
import re
import subprocess


class VolumeError(Exception):
    """Safe Docker failure without command output or credential payloads."""


class CredentialVolume:
    def __init__(self, name, helper_image):
        if not name or not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]*", name):
            raise VolumeError("Set a valid GATEWAY_SECRETS_VOLUME")
        if not helper_image:
            raise VolumeError("Set CREDENTIAL_HELPER_IMAGE to a trusted local shell-equipped image")
        self.name = name
        result = self.command("image", "inspect", helper_image)
        self.image = json.loads(result.stdout)[0]["Id"]

    @staticmethod
    def command(*args, payload=None, check=True):
        result = subprocess.run(["docker", *args], input=payload, capture_output=True)
        if check and result.returncode:
            raise VolumeError("Docker credential operation failed; inspect Docker availability, volume and helper permissions (output suppressed)")
        return result

    def ensure(self):
        if self.command("volume", "inspect", self.name, check=False).returncode:
            self.command("volume", "create", "--label", "agent-gateway.credentials=true", self.name)
        self.require()

    def require(self):
        info = json.loads(self.command("volume", "inspect", self.name).stdout)[0]
        if (info.get("Labels") or {}).get("agent-gateway.credentials") != "true":
            raise VolumeError("Refusing an unlabeled volume; select a dedicated gateway credential volume")

    def run(self, script, names, *, payload=None, writable=False):
        self.require()
        args = ["run", "--rm", "-i", "--network", "none", "--read-only", "--cap-drop", "ALL",
                "--security-opt", "no-new-privileges:true", "--log-driver", "none",
                "--user", "0:0" if writable else "10001:10001"]
        if writable:
            args += ["--cap-add", "CHOWN", "--cap-add", "DAC_OVERRIDE", "--cap-add", "FOWNER"]
        args += ["--mount", "type=volume,src=" + self.name + ",dst=/run/secrets" + ("" if writable else ",readonly"),
                 "--entrypoint", "/bin/sh", self.image, "-ec", script, "credential-volume", *names]
        return self.command(*args, payload=payload)

    def put(self, name, value):
        if not re.fullmatch(r"github_token|shortcut_[a-z0-9][a-z0-9-]*", name):
            raise VolumeError("Invalid credential filename")
        self.run('''umask 077
# Set Linux permissions in Docker storage, never on macOS shared files.
chmod 0700 /run/secrets
chown 10001:10001 /run/secrets
tmp=$(mktemp /run/secrets/.credential.XXXXXX)
trap 'rm -f "$tmp"' EXIT HUP INT TERM
cat > "$tmp"
chmod 0400 "$tmp"
chown 10001:10001 "$tmp"
mv -f "$tmp" "/run/secrets/$1"
''', [name], payload=value, writable=True)

    def check(self, names):
        if any(not re.fullmatch(r"github_token|shortcut_[a-z0-9][a-z0-9-]*", n) for n in names):
            raise VolumeError("Invalid credential filename")
        self.run('''test "$(stat -c '%u:%g:%a' /run/secrets)" = '10001:10001:700'
test "$(find /run/secrets -mindepth 1 -maxdepth 1 | wc -l)" -eq "$#"
for name do
  file="/run/secrets/$name"
  test ! -L "$file"
  test -f "$file"
  test "$(stat -c '%u:%g:%a' "$file")" = '10001:10001:400'
  size=$(stat -c '%s' "$file")
  test "$size" -gt 0
  test "$size" -le 8192
  # Open/read as the gateway UID, discard every byte, print nothing.
  cat "$file" > /dev/null
done
''', names)
