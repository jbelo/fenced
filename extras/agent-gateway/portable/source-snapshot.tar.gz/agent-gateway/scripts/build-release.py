#!/usr/bin/env python3
"""Build local Linux bundles and record exact source/artifact identities; no publishing."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"


def run(*args, **kwargs):
    return subprocess.check_output(args, cwd=ROOT, text=True, **kwargs).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    files = [ROOT / name for name in ("go.mod", "Dockerfile", "Makefile", ".dockerignore", ".gitignore", ".golangci.yml", "README.md", "docs/PRD.md", "docs/DOMAIN.md", "docs/DESIGN.md", "docs/SPEC.md", "docs/RUNBOOK.md")]
    for folder in ("cmd", "internal", "docs/examples", "docs/schemas", "deploy", "skills", "scripts"):
        files.extend(p for p in (ROOT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    manifest = {
        "git_commit": run("git", "rev-parse", "HEAD"),
        "dirty": bool(run("git", "status", "--porcelain")),
        "go_version": run("go", "version"),
        "source_files": {str(p.relative_to(ROOT)): sha(p) for p in sorted(files)},
        "mode": "mock and live runtime; authenticated provider verification pending",
    }
    (OUT / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    artifacts = [OUT / "source-manifest.json"]
    for arch in ("amd64", "arm64"):
        env = dict(os.environ, GOOS="linux", GOARCH=arch, CGO_ENABLED="0")
        for command in ("agent-gateway", "agentctl", "gateway-healthcheck"):
            target = OUT / f"{command}-linux-{arch}"
            subprocess.run(["go", "build", "-trimpath", "-buildvcs=false", "-o", str(target), f"./cmd/{command}"], cwd=ROOT, env=env, check=True)
            artifacts.append(target)
    # A self-contained skill directory is the installable artifact; no credentials.
    skill = OUT / "skills" / "agent-gateway"
    skill.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / "skills/agent-gateway/SKILL.md", skill / "SKILL.md")
    artifacts.append(skill / "SKILL.md")
    (OUT / "SHA256SUMS").write_text("".join(f"{sha(p)}  {p.relative_to(OUT)}\n" for p in sorted(artifacts)))
    print(f"Built Linux amd64/arm64 binaries and skill in {OUT}; see SHA256SUMS and source-manifest.json")


if __name__ == "__main__":
    main()
