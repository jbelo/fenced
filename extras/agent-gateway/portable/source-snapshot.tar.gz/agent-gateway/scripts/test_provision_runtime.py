"""Credential-free tests of operator provisioning boundaries."""
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
from types import SimpleNamespace
import os
import urllib.error

spec = importlib.util.spec_from_file_location("provision", Path(__file__).with_name("provision-runtime.py"))
provision = importlib.util.module_from_spec(spec)
spec.loader.exec_module(provision)


class Response(io.BytesIO):
    status = 200


class Opener:
    def __init__(self, body):
        self.body = body

    def open(self, request, timeout):
        assert request.full_url == "https://api.app.shortcut.com/api/v3/member"
        assert request.get_method() == "GET"
        assert request.get_header("Shortcut-token") == "synthetic-secret"
        assert timeout == 10
        return Response(self.body)


class ProvisionTests(unittest.TestCase):
    def test_identity(self):
        body = json.dumps({"workspace2": {"id": "11111111-1111-4111-8111-111111111111",
                                         "url_slug": "example"}}).encode()
        self.assertEqual(provision.workspace("synthetic-secret", "example", Opener(body)),
                         "11111111-1111-4111-8111-111111111111")
        with self.assertRaises(provision.ProvisionError):
            provision.workspace("synthetic-secret", "other", Opener(body))

    def test_invalid_metadata_and_bounds(self):
        for body in (b"synthetic-secret", b"{}", b"[]", b"x" * ((4 << 20) + 1)):
            with self.assertRaises(provision.ProvisionError) as error:
                provision.workspace("synthetic-secret", "example", Opener(body))
            self.assertNotIn("synthetic-secret", str(error.exception))

    def test_http_errors_do_not_disclose_body(self):
        class Failed:
            def open(self, request, timeout):
                raise urllib.error.HTTPError(request.full_url, 401, "synthetic-secret", {}, None)
        with self.assertRaises(provision.ProvisionError) as error:
            provision.workspace("synthetic-secret", "example", Failed())
        self.assertEqual(str(error.exception), "Shortcut returned HTTP 401; check token/workspace access")

    def test_redirect_refused(self):
        with self.assertRaises(provision.ProvisionError):
            provision.NoRedirect().redirect_request(None, None, 302, "", {}, "https://elsewhere.test")

    def test_exclusive_private_files(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "token"
            provision.write_new(path, "synthetic-secret", 0o400)
            self.assertEqual(path.stat().st_mode & 0o777, 0o400)
            with self.assertRaises(FileExistsError):
                provision.write_new(path, "replacement", 0o400)
            link = Path(directory) / "link"
            link.symlink_to(path)
            with self.assertRaises(FileExistsError):
                provision.write_new(link, "replacement", 0o400)
            self.assertEqual(path.read_text(), "synthetic-secret")


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "config").mkdir()
        (self.root / "secrets").mkdir()
        (self.root / "secrets").chmod(0o711)
        self.config = {"version": 1, "mode": "live", "listen_address": "172.30.0.10:8080",
                       "policy_file": "/etc/agent-gateway/policy.json", "providers": {
                           "github": {"enabled": True, "token_file": "/run/secrets/github_token"},
                           "shortcut": {"enabled": True, "workspaces": [{"alias": "team",
                               "workspace_id": "11111111-1111-4111-8111-111111111111",
                               "token_file": "/run/secrets/shortcut_team"}]}}}
        self.policy = {"version": 1, "github": [{"repo": "company/project"}], "shortcut": [{"workspace": "team"}]}
        for name, value in (("config.json", self.config), ("policy.json", self.policy)):
            provision.write_new(self.root / "config" / name, json.dumps(value), 0o444)
        for name in ("github_token", "shortcut_team"):
            provision.write_new(self.root / "secrets" / name, "old-secret", 0o400)

    def test_configure_keeps_credentials(self):
        desired = self.root / "desired.json"
        desired.write_text(json.dumps({**self.policy, "github": [{"repo": "company/other"}]}))
        args = SimpleNamespace(directory=self.root, config_file=None, policy_file=desired)
        provision.configure(args)
        provision.configure(args)  # Repeatable and does not touch secrets.
        self.assertEqual(provision.read_json(self.root / "config/policy.json")["github"], [{"repo": "company/other"}])
        self.assertEqual((self.root / "secrets/github_token").read_text(), "old-secret")

    def test_bad_policy_leaves_files_unchanged(self):
        desired = self.root / "bad.json"
        desired.write_text(json.dumps({**self.policy, "github": [{"repo": "company/*"}]}))
        before = (self.root / "config/policy.json").read_bytes()
        with self.assertRaises(provision.ProvisionError):
            provision.configure(SimpleNamespace(directory=self.root, config_file=None, policy_file=desired))
        self.assertEqual((self.root / "config/policy.json").read_bytes(), before)

    def test_failed_atomic_replacement_preserves_old_token(self):
        path = self.root / "secrets/github_token"
        with mock.patch.object(provision.os, "fchown", side_effect=PermissionError):
            with self.assertRaises(PermissionError):
                provision.replace_file(path, "new-secret", 0o400, (os.getuid() + 1, os.getgid()))
        self.assertEqual(path.read_text(), "old-secret")
        self.assertEqual(sorted(p.name for p in path.parent.iterdir()), ["github_token", "shortcut_team"])

    def test_wrong_workspace_rotation_preserves_token(self):
        args = SimpleNamespace(directory=self.root, provider="shortcut", shortcut_alias="team", shortcut_slug="company")
        with mock.patch.object(provision, "selected_volume"), mock.patch.object(provision.sys.stdin, "isatty", return_value=True), mock.patch.object(provision, "credential", return_value="new-secret"), mock.patch.object(provision, "workspace", return_value="22222222-2222-4222-8222-222222222222"):
            with self.assertRaises(provision.ProvisionError):
                provision.rotate(args)
        self.assertEqual((self.root / "secrets/shortcut_team").read_text(), "old-secret")

    def test_rotation_replaces_only_selected_provider(self):
        args = SimpleNamespace(directory=self.root, provider="github")
        with mock.patch.object(provision, "selected_volume"), mock.patch.object(provision.sys.stdin, "isatty", return_value=True), mock.patch.object(provision, "credential", return_value="new-secret"), mock.patch.object(provision.os, "fchown"):
            provision.rotate(args)
        self.assertEqual((self.root / "secrets/github_token").read_text(), "new-secret")
        self.assertEqual((self.root / "secrets/shortcut_team").read_text(), "old-secret")

    def test_check_rejects_bad_mode_without_reading_tokens(self):
        (self.root / "secrets/github_token").chmod(0o444)
        with self.assertRaises(provision.ProvisionError):
            provision.check(SimpleNamespace(directory=self.root))

    def test_check_passes_without_reading_credential_contents(self):
        original_read = Path.read_text
        def read(path, *args, **kwargs):
            if path.parent == self.root / "secrets":
                raise AssertionError("host credential contents read")
            return original_read(path, *args, **kwargs)
        with mock.patch.object(provision, "selected_volume") as volume, mock.patch.object(Path, "read_text", read):
            provision.check(SimpleNamespace(directory=self.root))
            volume.return_value.check.assert_called_once_with(["github_token", "shortcut_team"])

    def test_repeat_init_does_not_prompt_or_overwrite(self):
        args = SimpleNamespace(directory=self.root, agent_ip="172.30.0.10", repo=["company/project"], shortcut_alias="team", shortcut_slug="company")
        with mock.patch.object(provision.sys.stdin, "isatty", return_value=True), mock.patch.object(provision, "credential", side_effect=AssertionError("unexpected prompt")):
            with self.assertRaises(provision.ProvisionError):
                provision.initialize(args)
        self.assertEqual((self.root / "secrets/github_token").read_text(), "old-secret")

    def test_duplicate_fields_rejected(self):
        path = self.root / "duplicate.json"
        path.write_text('{"version":1,"version":2}')
        with self.assertRaises(provision.ProvisionError):
            provision.read_json(path)


class VolumeTransportTests(unittest.TestCase):
    def test_payload_is_stdin_and_failures_are_redacted(self):
        from credential_volume import CredentialVolume, VolumeError
        with mock.patch("credential_volume.subprocess.run") as run:
            run.return_value = SimpleNamespace(returncode=1, stdout=b"synthetic-secret", stderr=b"synthetic-secret")
            with self.assertRaises(VolumeError) as error:
                CredentialVolume.command("run", "helper", payload=b"synthetic-secret")
            self.assertNotIn("synthetic-secret", str(error.exception))
            self.assertNotIn("synthetic-secret", str(run.call_args.args))
            self.assertEqual(run.call_args.kwargs["input"], b"synthetic-secret")

    def test_unlabeled_volume_refused(self):
        from credential_volume import CredentialVolume, VolumeError
        volume = object.__new__(CredentialVolume)
        volume.name = "unrelated"
        with mock.patch.object(volume, "command", return_value=SimpleNamespace(stdout=b'[{"Labels":{}}]')):
            with self.assertRaises(VolumeError):
                volume.require()


if __name__ == "__main__":
    unittest.main()
