// Command gateway-healthcheck checks local readiness without calling providers.
package main

import (
	"agent-gateway/internal/limits"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"time"
)

func probe(ctx context.Context, address string, transport http.RoundTripper) error {
	host, port, err := net.SplitHostPort(address)
	ip := net.ParseIP(host)
	if err != nil || ip == nil || ip.To4() == nil || ip.IsUnspecified() || port != "8080" {
		return fmt.Errorf("invalid readiness address")
	}
	client := http.Client{Transport: transport, Timeout: 2 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, "http://"+address+"/readyz", nil)
	if err != nil {
		return err
	}
	response, err := client.Do(request)
	if err != nil {
		return err
	}
	defer func() { _ = response.Body.Close() }()
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("not ready")
	}
	return nil
}

func run() error {
	f, err := os.Open("/etc/agent-gateway/config.json")
	if err != nil {
		return err
	}
	defer func() { _ = f.Close() }()
	data, err := io.ReadAll(io.LimitReader(f, limits.ConfigBytes+1))
	if err != nil || len(data) > limits.ConfigBytes {
		return fmt.Errorf("unreadable health configuration")
	}
	var config struct {
		Listen string `json:"listen_address"`
	}
	if json.Unmarshal(data, &config) != nil {
		return fmt.Errorf("invalid health configuration")
	}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.Proxy = nil
	defer transport.CloseIdleConnections()
	return probe(context.Background(), config.Listen, transport)
}

func main() {
	if run() != nil {
		fmt.Fprintln(os.Stderr, "gateway readiness check failed")
		os.Exit(1)
	}
}
