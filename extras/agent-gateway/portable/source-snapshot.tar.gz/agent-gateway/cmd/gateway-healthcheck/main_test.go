package main

import (
	"context"
	"io"
	"net/http"
	"strings"
	"testing"
)

type healthTransport func(*http.Request) (*http.Response, error)

func (f healthTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func TestReadinessProbe(t *testing.T) {
	for _, status := range []int{200, 503, 302} {
		transport := healthTransport(func(r *http.Request) (*http.Response, error) {
			if r.Method != "GET" || r.URL.String() != "http://172.30.0.10:8080/readyz" {
				t.Fatal("wrong health endpoint")
			}
			return &http.Response{StatusCode: status, Header: http.Header{"Location": []string{"http://elsewhere/"}}, Body: io.NopCloser(strings.NewReader(`{"status":"ok"}`))}, nil
		})
		err := probe(context.Background(), "172.30.0.10:8080", transport)
		if (err == nil) != (status == 200) {
			t.Fatal(status, err)
		}
	}
	for _, address := range []string{"0.0.0.0:8080", "agent-gateway:8080", "172.30.0.10:9999", "bad"} {
		err := probe(context.Background(), address, healthTransport(func(*http.Request) (*http.Response, error) { t.Fatal("invalid address contacted"); return nil, nil }))
		if err == nil {
			t.Fatal("invalid address accepted")
		}
	}
}
