package main

import (
	"agent-gateway/internal/cli"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func configFile(t *testing.T) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "agentctl.json")
	if err := os.WriteFile(path, []byte(`{"gateway_url":"http://agent-gateway:8080"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestTargetAuthorizationComesFromGateway(t *testing.T) {
	calls := 0
	client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
		calls++
		if r.Method != "POST" || r.URL.String() != "http://agent-gateway:8080/v1/read" {
			t.Fatalf("unexpected request: %v", r)
		}
		body, err := io.ReadAll(r.Body)
		if err != nil {
			t.Fatal(err)
		}
		parsed, err := parseRequest(body)
		if err != nil || parsed.Target.Key != "other/project" || parsed.Args.(ghapi.PRViewArgs).Number != 123 {
			t.Fatalf("request=%+v err=%v", parsed, err)
		}
		return &http.Response{StatusCode: 403, Body: io.NopCloser(strings.NewReader(`{"version":"v1","request_id":"server-id","error":{"code":"policy_denied","message":"policy_denied","retry_after_seconds":null}}`))}, nil
	})}
	var out bytes.Buffer
	code := run([]string{"github", "pr", "view", "--repo", "Other/Project", "--number", "123"}, configFile(t), &out, client)
	if code != 4 || calls != 1 {
		t.Fatalf("exit=%d calls=%d output=%s", code, calls, out.String())
	}
	var env protocol.Envelope
	if err := json.Unmarshal(out.Bytes(), &env); err != nil {
		t.Fatal(err)
	}
	if env.RequestID == nil || *env.RequestID != "server-id" || env.Error.Code != protocol.PolicyDenied {
		t.Fatalf("unexpected envelope: %+v", env)
	}
}

func TestInvalidArgumentsNeverReachGateway(t *testing.T) {
	client := &http.Client{Transport: roundTripFunc(func(*http.Request) (*http.Response, error) {
		t.Fatal("invalid input reached gateway")
		return nil, nil
	})}
	for _, args := range [][]string{
		{"unknown"},
		{"unknown", "path"},
		{"github", "pr", "view", "--repo", "company/project", "--number", "0"},
		{"github", "pr", "list", "--repo", "company/project", "--limit", "0"},
		{"github", "pr", "view", "--repo", "company/project", "--number", "1", "--host", "github.com"},
		{"shortcut", "story", "search", "--workspace", "engineering", "--text", "owner:admin"},
	} {
		var out bytes.Buffer
		code := run(args, "", &out, client)
		var env protocol.Envelope
		if err := json.Unmarshal(out.Bytes(), &env); err != nil {
			t.Fatal(err)
		}
		if code != 2 || env.RequestID != nil || env.Error == nil || env.Error.Code != protocol.InvalidInput {
			t.Fatalf("args=%v exit=%d output=%s", args, code, out.String())
		}
	}
}

func run(args []string, path string, out io.Writer, client *http.Client) int {
	runner, err := cli.New(commands())
	if err != nil {
		panic(err)
	}
	return runner.RunWithClient(args, path, out, client)
}
