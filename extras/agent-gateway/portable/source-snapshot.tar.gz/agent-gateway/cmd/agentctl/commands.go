package main

import (
	"agent-gateway/internal/cli"
	gh "agent-gateway/internal/providers/github/commands"
	sc "agent-gateway/internal/providers/shortcut/commands"
)

// Commands returns the explicitly supported command definitions.
func commands() []cli.Command { return append(gh.Commands(), sc.Commands()...) }
