// Command agentctl runs registered read commands against the httpapi.
package main

import (
	"agent-gateway/internal/cli"
	"fmt"
	"os"
)

func main() {
	runner, err := cli.New(commands())
	if err != nil {
		fmt.Fprintln(os.Stderr, "invalid command registration")
		os.Exit(1)
	}
	os.Exit(runner.Run(os.Args[1:], os.Getenv("AGENTCTL_CONFIG"), os.Stdout))
}
