package main

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/providers/github"
	ghapi "agent-gateway/internal/providers/github/contract"
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

// Exercise the real CLI parser, HTTP boundary, provider adapter and cursors together.
func TestFeedbackCLITraversal(t *testing.T) {
	var audit bytes.Buffer
	server, err := httpapi.NewServer([]access.ResourceScope{{Provider: "github", Kind: "repository", Key: "company/project"}}, github.Operations(github.FixtureReader()), &audit)
	if err != nil {
		t.Fatal(err)
	}
	client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
		response := httptest.NewRecorder()
		server.ServeHTTP(response, r)
		return response.Result(), nil
	})}
	args := []string{"github", "pr", "feedback", "--repo", "Company/Project", "--number", "566", "--limit", "1"}
	config := configFile(t)
	count := 0
	for i := 0; i < 4; i++ {
		var out bytes.Buffer
		if code := run(args, config, &out, client); code != 0 {
			t.Fatalf("exit %d: %s", code, out.String())
		}
		var env struct {
			Data ghapi.FeedbackPage `json:"data"`
		}
		if err := json.Unmarshal(out.Bytes(), &env); err != nil {
			t.Fatal(err)
		}
		if env.Data.Number != 566 || env.Data.Repo != "company/project" {
			t.Fatal("wrong scope")
		}
		count += env.Data.ItemCount()
		if i < 3 {
			if env.Data.NextCursor == nil || env.Data.Status != "partial" {
				t.Fatal("premature exhaustion")
			}
			args = append(args[:9:9], "--cursor", *env.Data.NextCursor)
		} else if env.Data.NextCursor != nil || env.Data.Status != "complete" {
			t.Fatal("missing exhaustion")
		}
	}
	if count != 4 || bytes.Contains(audit.Bytes(), []byte("Synthetic")) {
		t.Fatal("lost feedback or logged bodies")
	}
}
