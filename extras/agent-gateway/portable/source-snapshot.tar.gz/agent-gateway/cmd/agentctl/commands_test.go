package main

import (
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
)

// ParseRequest validates a request using the explicitly assembled command catalogue.
func parseRequest(data []byte) (operation.ValidatedRequest, error) {
	decoders := map[string]func(protocol.Request) (operation.ValidatedRequest, error){}
	for _, c := range commands() {
		decoders[c.Operation] = c.Decode
	}
	return operation.ParseRequest(data, decoders)
}
