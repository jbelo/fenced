package main

import (
	"errors"
	"io"
	"net/http"
	"strings"
	"testing"
)

type failedOutput struct{}

func (failedOutput) Write([]byte) (int, error) { return 0, errors.New("output unavailable") }

type responseBody struct {
	io.Reader
	closed     bool
	closeError error
}

func (b *responseBody) Close() error { b.closed = true; return b.closeError }

func TestCLIOutputFailureIsNotSuccess(t *testing.T) {
	args := []string{"github", "pr", "view", "--repo", "company/project", "--number", "1"}
	// Local error encoding must also report that output failed.
	if code := run(args, "", failedOutput{}, nil); code != 10 {
		t.Fatalf("local output failure: exit %d", code)
	}
	body := &responseBody{Reader: strings.NewReader(`{"version":"v1","request_id":"id","data":{}}`)}
	client := &http.Client{Transport: roundTripFunc(func(*http.Request) (*http.Response, error) { return &http.Response{StatusCode: 200, Body: body}, nil })}
	if code := run(args, configFile(t), failedOutput{}, client); code != 10 {
		t.Fatalf("response output failure: exit %d", code)
	}
	if !body.closed {
		t.Fatal("response body not closed")
	}
}

func TestCLIResponseCloseFailure(t *testing.T) {
	body := &responseBody{Reader: strings.NewReader(`{"version":"v1","request_id":"id","data":{}}`), closeError: errors.New("private transport detail")}
	client := &http.Client{Transport: roundTripFunc(func(*http.Request) (*http.Response, error) { return &http.Response{StatusCode: 200, Body: body}, nil })}
	var out strings.Builder
	code := run([]string{"github", "pr", "view", "--repo", "company/project", "--number", "1"}, configFile(t), &out, client)
	if code != 11 || !body.closed || strings.Contains(out.String(), "private transport detail") {
		t.Fatalf("exit=%d closed=%v output=%s", code, body.closed, &out)
	}
}
