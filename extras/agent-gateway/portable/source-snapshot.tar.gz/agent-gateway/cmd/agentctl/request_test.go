package main

import (
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"testing"
)

func TestNormalizationDoesNotAuthorizeTargets(t *testing.T) {
	tests := []struct{ input, repo, workspace string }{
		{`{"operation":"github.pr.list","target":{"repo":"Other/Project"},"args":{}}`, "other/project", ""},
		{`{"operation":"shortcut.story.search","target":{"workspace":"not-configured"},"args":{"text":"  some   words "}}`, "", "not-configured"},
	}
	for _, tc := range tests {
		request, err := parseRequest([]byte(tc.input))
		if err != nil {
			t.Fatal(err)
		}
		if request.Target.Key != tc.repo+tc.workspace {
			t.Fatalf("unexpected normalized request: %+v", request)
		}
		if tc.repo != "" && request.Args.(ghapi.PRListArgs).State != "open" {
			t.Fatal("missing list default")
		}
		if tc.workspace != "" && request.Args.(scapi.StorySearchArgs).Text != "some words" {
			t.Fatal("search text not normalized")
		}
	}
}

func TestNormalizationStillRejectsInvalidInput(t *testing.T) {
	for _, input := range []string{
		`{"operation":"github.pr.list","target":{"repo":"other/project"},"args":{"limit":0}}`,
		`{"operation":"github.pr.list","target":{"repo":"other/project","host":"github.com"},"args":{}}`,
		`{"operation":"github.pr.view","target":{"repo":"other/project"},"args":{"number":1,"number":2}}`,
		`{"operation":"shortcut.story.get","target":{"workspace":"invalid alias"},"args":{"id":1}}`,
	} {
		if _, err := parseRequest([]byte(input)); protocol.ErrorCode(err) != protocol.InvalidInput {
			t.Errorf("%s: %v", input, err)
		}
	}
}
