package main

import (
	"agent-gateway/internal/provider"
	"agent-gateway/internal/providers/github"
	"agent-gateway/internal/providers/shortcut"
)

func providers() (*provider.Registry, error) {
	return provider.New([]provider.Provider{github.New(), shortcut.New()})
}
