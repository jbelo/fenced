package main

import (
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestProviderConfigurationRemainsStrict(t *testing.T) {
	data, err := os.ReadFile("../../docs/examples/mock-config.json")
	if err != nil {
		t.Fatal(err)
	}
	original := string(data)
	for _, tc := range []struct{ name, raw string }{
		{"unknown provider", strings.Replace(original, `"providers": {`, `"providers": {"documents": {},`, 1)},
		{"unknown GitHub field", strings.Replace(original, `"github": {`, `"github": {"unknown": true,`, 1)},
		{"unknown Shortcut field", strings.Replace(original, `"shortcut": {`, `"shortcut": {"unknown": true,`, 1)},
		{"missing enabled", strings.Replace(original, `"enabled": true,`, "", 1)},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if tc.raw == original {
				t.Fatal("fixture replacement did not apply")
			}
			path := filepath.Join(t.TempDir(), "config.json")
			if err := os.WriteFile(path, []byte(tc.raw), 0o600); err != nil {
				t.Fatal(err)
			}
			candidate, err := loadConfig(path)
			if err == nil {
				registry, registryErr := providers()
				if registryErr != nil {
					t.Fatal(registryErr)
				}
				_, err = configure(candidate, registry)
			}
			if err == nil {
				t.Fatal("invalid config accepted")
			}
		})
	}
	registry, err := providers()
	if err != nil {
		t.Fatal(err)
	}
	var c config
	if err := protocol.DecodeStrict(data, &c); err != nil {
		t.Fatal(err)
	}
	configured, err := configure(c, registry)
	if err != nil {
		t.Fatal(err)
	}
	policyJSON, err := os.ReadFile("../../docs/examples/policy.json")
	if err != nil {
		t.Fatal(err)
	}
	p, err := decodePolicy(policyJSON)
	if err != nil {
		t.Fatal(err)
	}
	p["github"] = json.RawMessage(`[{"repo":"COMPANY/PROJECT"}]`)
	targets, err := configured.Targets(p)
	if err != nil {
		t.Fatal(err)
	}
	if !httpapi.Policy(targets).Allows(operation.Target{Provider: "github", Kind: "repository", Key: "company/project"}) {
		t.Fatal("configured target not canonical")
	}
}
