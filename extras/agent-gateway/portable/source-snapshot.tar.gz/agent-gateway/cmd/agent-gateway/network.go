package main

import (
	"errors"
	"net"
)

// verifyListenAddress checks the host has the configured interface before serving.
func verifyListenAddress(address string) error {
	host, _, err := net.SplitHostPort(address)
	if err != nil {
		return errors.New("invalid listen address")
	}
	want := net.ParseIP(host)
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return errors.New("cannot inspect network interfaces")
	}
	for _, a := range addrs {
		ip, _, e := net.ParseCIDR(a.String())
		if e == nil && ip.Equal(want) {
			return nil
		}
	}
	return errors.New("configured agent address is not assigned locally")
}
