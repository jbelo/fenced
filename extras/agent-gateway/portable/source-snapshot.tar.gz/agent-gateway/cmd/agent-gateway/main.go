// Command agent-gateway serves controlled provider reads on the configured agent network.
package main

import (
	"agent-gateway/internal/httpapi"
	"context"
	"errors"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

func run() error {
	path := flag.String("config", "/etc/agent-gateway/config.json", "operator configuration file")
	flag.Parse()
	if flag.NArg() != 0 {
		return fmt.Errorf("unexpected arguments")
	}
	c, err := loadConfig(*path)
	if err != nil {
		return err
	}
	if err := verifyListenAddress(c.ListenAddress); err != nil {
		return err
	}
	registry, err := providers()
	if err != nil {
		return err
	}
	configured, err := configure(c, registry)
	if err != nil {
		return err
	}
	p, err := loadPolicy(c, configured)
	if err != nil {
		return err
	}
	operations := configured.Operations()
	handler, err := httpapi.NewServer(p, operations, os.Stdout)
	if err != nil {
		return err
	}
	srv := &http.Server{Addr: c.ListenAddress, Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 20 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16 * 1024}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()
	shutdownDone := make(chan struct{})
	go func() {
		defer close(shutdownDone)
		<-ctx.Done()
		handler.Drain()
		drain, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		if srv.Shutdown(drain) != nil {
			if err := srv.Close(); err != nil {
				log.Print("gateway forced shutdown failed")
			}
		}
	}()
	err = srv.ListenAndServe()
	if errors.Is(err, http.ErrServerClosed) {
		<-shutdownDone
		return nil
	}
	return fmt.Errorf("gateway listener failed")
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
