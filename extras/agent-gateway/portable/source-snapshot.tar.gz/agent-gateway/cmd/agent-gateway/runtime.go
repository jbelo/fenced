package main

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/cursor"
	"agent-gateway/internal/provider"
	"agent-gateway/internal/runtimefile"
	"errors"
	"net/http"
	"time"
)

// fixtureFactory is an optional assembly capability, not a provider requirement.
type fixtureFactory interface{ Fixture() http.RoundTripper }

func configure(c config, registry *provider.Registry) (*provider.Configured, error) {
	codec, err := cursor.New()
	if err != nil {
		return nil, err
	}
	pages, err := access.NewContinuations(codec, time.Now)
	if err != nil {
		return nil, err
	}
	return registry.Configure(c.Providers, func(p provider.Provider) (provider.Runtime, error) {
		rt, err := providerRuntime(c.Mode, p)
		rt.Continuations = pages
		return rt, err
	})
}

func providerRuntime(mode string, p provider.Provider) (provider.Runtime, error) {
	switch mode {
	case "live":
		return provider.Runtime{ReadSecret: runtimefile.ReadSecret}, nil
	case "mock":
		factory, ok := p.(fixtureFactory)
		if !ok {
			return provider.Runtime{}, errors.New("mock transport unavailable")
		}
		transport := factory.Fixture()
		if transport == nil {
			return provider.Runtime{}, errors.New("mock transport unavailable")
		}
		return provider.Runtime{Transport: transport}, nil
	default:
		return provider.Runtime{}, errors.New("invalid runtime mode")
	}
}
