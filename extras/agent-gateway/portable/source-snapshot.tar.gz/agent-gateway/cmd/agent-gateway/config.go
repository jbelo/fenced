package main

import (
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/limits"
	"agent-gateway/internal/protocol"
	"agent-gateway/internal/provider"
	"agent-gateway/internal/runtimefile"
	"encoding/json"
	"errors"
	"net"
)

type config struct {
	Version       int                        `json:"version"`
	Mode          string                     `json:"mode"`
	ListenAddress string                     `json:"listen_address"`
	PolicyFile    string                     `json:"policy_file"`
	Providers     map[string]json.RawMessage `json:"providers"`
}

func (c config) validate() error {
	if c.Version != 1 || (c.Mode != "mock" && c.Mode != "live") {
		return errors.New("invalid configuration version or mode")
	}
	host, port, err := net.SplitHostPort(c.ListenAddress)
	ip := net.ParseIP(host)
	if err != nil || port != "8080" || ip == nil || ip.To4() == nil || ip.IsUnspecified() || ip.IsLoopback() || ip.IsMulticast() || ip.IsLinkLocalUnicast() {
		return errors.New("invalid agent-interface listen address")
	}
	if c.PolicyFile != "/etc/agent-gateway/policy.json" || c.Providers == nil {
		return errors.New("missing providers or invalid policy path")
	}
	return nil
}

func loadConfig(path string) (config, error) {
	var c config
	data, err := runtimefile.ReadBoundedFile(path, limits.ConfigBytes)
	if err != nil {
		return c, err
	}
	if protocol.DecodeStrict(data, &c) != nil {
		return c, errors.New("invalid config JSON")
	}
	return c, c.validate()
}

func decodePolicy(data []byte) (map[string]json.RawMessage, error) {
	var sections map[string]json.RawMessage
	if protocol.DecodeStrict(data, &sections) != nil {
		return nil, errors.New("invalid policy JSON")
	}
	var version int
	if protocol.DecodeStrict(sections["version"], &version) != nil || version != 1 {
		return nil, errors.New("invalid policy version")
	}
	delete(sections, "version")
	return sections, nil
}

func loadPolicy(c config, configured *provider.Configured) (httpapi.Policy, error) {
	data, err := runtimefile.ReadBoundedFile(c.PolicyFile, limits.ConfigBytes)
	if err != nil {
		return nil, err
	}
	sections, err := decodePolicy(data)
	if err != nil {
		return nil, err
	}
	targets, err := configured.Targets(sections)
	return httpapi.Policy(targets), err
}
