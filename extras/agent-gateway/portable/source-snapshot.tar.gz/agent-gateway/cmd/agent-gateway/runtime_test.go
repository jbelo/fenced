package main

import (
	"agent-gateway/internal/access"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/provider"
	"encoding/json"
	"net/http"
	"testing"
)

type noFixtures struct{ configured bool }

func (*noFixtures) Name() string                        { return "example" }
func (*noFixtures) Definitions() []operation.Descriptor { return nil }
func (p *noFixtures) Configure(json.RawMessage, provider.Runtime) (provider.Instance, error) {
	p.configured = true
	return nil, nil
}

type optionalFixtures struct {
	noFixtures
	transport http.RoundTripper
	calls     int
}

func (p *optionalFixtures) Fixture() http.RoundTripper { p.calls++; return p.transport }

func TestRuntimeSelection(t *testing.T) {
	plain := &noFixtures{}
	live, err := providerRuntime("live", plain)
	if err != nil || live.Transport != nil || live.ReadSecret == nil {
		t.Fatal("live provider requires fixture capability", err)
	}
	registry, err := provider.New([]provider.Provider{plain})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = configure(config{Mode: "mock", Providers: map[string]json.RawMessage{"example": json.RawMessage(`{}`)}}, registry); err == nil || plain.configured {
		t.Fatal("missing mock transport did not stop startup before configuration")
	}
	factory := &optionalFixtures{}
	if _, err = providerRuntime("mock", factory); err == nil {
		t.Fatal("nil fixture transport accepted")
	}
	transport := &http.Transport{}
	factory.transport = transport
	mock, err := providerRuntime("mock", factory)
	if err != nil || mock.Transport != transport || mock.ReadSecret != nil {
		t.Fatal("incorrect mock runtime", err)
	}
	calls := factory.calls
	if _, err = providerRuntime("live", factory); err != nil || factory.calls != calls {
		t.Fatal("live mode invoked fixtures", err)
	}
	if _, err = providerRuntime("unknown", factory); err == nil {
		t.Fatal("invalid mode accepted")
	}
}

type cursorRuntimeProbe struct {
	name  string
	pages *access.Continuations
}

func (p *cursorRuntimeProbe) Name() string                      { return p.name }
func (*cursorRuntimeProbe) Definitions() []operation.Descriptor { return nil }
func (p *cursorRuntimeProbe) Configure(_ json.RawMessage, rt provider.Runtime) (provider.Instance, error) {
	p.pages = rt.Continuations
	return p, nil
}
func (*cursorRuntimeProbe) Targets(json.RawMessage) ([]operation.Target, error) { return nil, nil }
func (*cursorRuntimeProbe) Operations() []operation.Binding                     { return nil }
func TestConfigureSharesOneCursorRuntime(t *testing.T) {
	a, b := &cursorRuntimeProbe{name: "one"}, &cursorRuntimeProbe{name: "two"}
	registry, err := provider.New([]provider.Provider{a, b})
	if err != nil {
		t.Fatal(err)
	}
	c := config{Mode: "live", Providers: map[string]json.RawMessage{"one": json.RawMessage(`{}`), "two": json.RawMessage(`{}`)}}
	// These probe providers never read secrets or make network requests.
	if _, err := configure(c, registry); err != nil {
		t.Fatal(err)
	}
	if a.pages == nil || a.pages != b.pages {
		t.Fatal("providers have different cursor runtimes")
	}
	previous := a.pages
	if _, err := configure(c, registry); err != nil {
		t.Fatal(err)
	}
	if a.pages == previous || a.pages != b.pages {
		t.Fatal("runtime key not replaced on assembly")
	}
}
