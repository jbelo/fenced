package main

import (
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/protocol"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// TestPackagedCLI uses a built native CLI against the real mock HTTP pipeline.
// Opt-in because the fixed CLI protocol port must be available on the test host.
func TestPackagedCLI(t *testing.T) {
	binary := os.Getenv("GATEWAY_PACKAGED_CLI")
	if binary == "" {
		t.Skip("set GATEWAY_PACKAGED_CLI to a native agentctl binary")
	}
	c, policySections := fileFixture(t)
	registry, err := providers()
	if err != nil {
		t.Fatal(err)
	}
	configured, err := configure(c, registry)
	if err != nil {
		t.Fatal(err)
	}
	targets, err := configured.Targets(policySections)
	if err != nil {
		t.Fatal(err)
	}
	handler, err := httpapi.NewServer(targets, configured.Operations(), io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	listener, err := net.Listen("tcp", "127.0.0.1:8080")
	if err != nil {
		t.Fatal(err)
	}
	server := httptest.NewUnstartedServer(handler)
	if err := server.Listener.Close(); err != nil {
		t.Fatal(err)
	}
	server.Listener = listener
	server.Start()
	defer server.Close()
	configPath := filepath.Join(t.TempDir(), "agentctl.json")
	if err := os.WriteFile(configPath, []byte(`{"gateway_url":"http://127.0.0.1:8080"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		args string
		exit int
	}{
		{"github pr list --repo company/project --limit 50", 0},
		{"github pr view --repo company/project --number 123", 0},
		{"github pr diff --repo company/project --number 123", 0},
		{"github pr checks --repo company/project --number 123 --limit 50", 0},
		{"github pr feedback --repo company/project --number 123 --limit 50", 0},
		{"shortcut story get --workspace engineering --id 456", 0},
		{"shortcut story search --workspace engineering --text gateway --limit 50", 0},
		{"github pr view --repo forbidden/project --number 1", 4},
	} {
		command := exec.Command(binary, strings.Fields(tc.args)...) //nolint:gosec // G204: opt-in test executes the operator-selected build artifact, without a shell.
		command.Env = append(os.Environ(), "AGENTCTL_CONFIG="+configPath, "HTTP_PROXY=http://127.0.0.1:1", "HTTPS_PROXY=http://127.0.0.1:1", "ALL_PROXY=http://127.0.0.1:1")
		data, err := command.Output()
		code := 0
		if err != nil {
			var failure *exec.ExitError
			if !errors.As(err, &failure) {
				t.Fatal(err)
			}
			code = failure.ExitCode()
		}
		if code != tc.exit {
			t.Fatalf("%s: exit=%d output=%s", tc.args, code, data)
		}
		var env protocol.Envelope
		if json.Unmarshal(data, &env) != nil || env.Version != "v1" || env.RequestID == nil || (tc.exit == 0) != (env.Error == nil) {
			t.Fatalf("invalid envelope: %s", data)
		}
	}
}
