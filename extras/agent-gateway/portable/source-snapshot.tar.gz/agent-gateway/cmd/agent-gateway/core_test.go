package main

import (
	"agent-gateway/internal/httpapi"
	"agent-gateway/internal/operation"
	"agent-gateway/internal/protocol"
	ghapi "agent-gateway/internal/providers/github/contract"
	scapi "agent-gateway/internal/providers/shortcut/contract"
	"encoding/json"
	"os"
	"strings"
	"testing"
)

func fileFixture(t *testing.T) (config, map[string]json.RawMessage) {
	t.Helper()
	c, err := loadConfig("../../docs/examples/mock-config.json")
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile("../../docs/examples/policy.json")
	if err != nil {
		t.Fatal(err)
	}
	p, err := decodePolicy(data)
	if err != nil {
		t.Fatal(err)
	}
	return c, p
}

func TestStrictInput(t *testing.T) {
	for _, input := range []string{`{"version":1,"version":1}`, `{"version":1,"extra":true}`, `null`, `{"version":null}`, `{"version":1} {}`, string([]byte{'{', '"', 'x', '"', ':', '"', 255, '"', '}'})} {
		var v struct {
			Version int `json:"version"`
		}
		if protocol.DecodeStrict([]byte(input), &v) == nil {
			t.Errorf("accepted invalid JSON %q", input)
		}
	}
	var v map[string]any
	if protocol.DecodeStrict([]byte(`{"nested":{"x":1,"x":2}}`), &v) == nil {
		t.Fatal("nested duplicate accepted")
	}
}

func TestAllSupportedRequests(t *testing.T) {
	_, p := fixture(t)
	for _, input := range []string{
		`{"operation":"github.pr.list","target":{"repo":"Company/Project"},"args":{}}`,
		`{"operation":"github.pr.view","target":{"repo":"company/project"},"args":{"number":123}}`,
		`{"operation":"github.pr.diff","target":{"repo":"company/project"},"args":{"number":123}}`,
		`{"operation":"github.pr.checks","target":{"repo":"company/project"},"args":{"number":123,"limit":50}}`,
		`{"operation":"github.pr.feedback","target":{"repo":"company/project"},"args":{"number":123,"limit":50}}`,
		`{"operation":"shortcut.story.get","target":{"workspace":"engineering"},"args":{"id":456}}`,
		`{"operation":"shortcut.story.search","target":{"workspace":"engineering"},"args":{"text":"  dashboard   review ","type":"feature"}}`,
	} {
		r, err := parseRequest([]byte(input), p)
		if err != nil {
			t.Fatal(err)
		}
		if r.Target.Provider == "github" && r.Target.Key != "company/project" {
			t.Fatal("repository not canonical")
		}
		if strings.HasSuffix(r.Operation, "search") && r.Args.(scapi.StorySearchArgs).Text != "dashboard review" {
			t.Fatal("text not normalized")
		}
	}
}

func TestRequestsFailClosed(t *testing.T) {
	_, p := fixture(t)
	base := `{"operation":"github.pr.view","target":{"repo":"company/project"},"args":{"number":123}}`
	cases := []struct {
		input string
		code  protocol.Code
	}{
		{strings.Replace(base, "github.pr.view", "github.pr.merge", 1), protocol.UnsupportedOperation},
		{strings.Replace(base, "company/project", "other/project", 1), protocol.PolicyDenied},
		{strings.Replace(base, `"repo":`, `"host":"github.com","repo":`, 1), protocol.InvalidInput},
		{strings.Replace(base, `"number":123`, `"number":123,"url":"https://example.com"`, 1), protocol.InvalidInput},
		{strings.Replace(base, `"number":123`, `"number":0`, 1), protocol.InvalidInput},
		{strings.Replace(base, `"number":123`, `"number":9007199254740992`, 1), protocol.InvalidInput},
		{strings.Replace(base, `"number":123`, `"number":1.5`, 1), protocol.InvalidInput},
		{strings.Replace(base, "company/project", "../project", 1), protocol.InvalidInput},
		{strings.Replace(base, `"number":123`, `"number":123,"number":124`, 1), protocol.InvalidInput},
	}
	for _, tc := range cases {
		_, err := parseRequest([]byte(tc.input), p)
		if err == nil || protocol.ErrorCode(err) != tc.code {
			t.Errorf("%s: got %v want %s", tc.input, err, tc.code)
		}
	}
}

func TestSearchInjectionAndBounds(t *testing.T) {
	_, p := fixture(t)
	for _, text := range []string{"owner:admin", "query OR is:archived", "*", "\"quote\"", "back\\slash", " ", "line\nbreak", strings.Repeat("a", 257)} {
		b, _ := json.Marshal(map[string]any{"operation": "shortcut.story.search", "target": map[string]string{"workspace": "engineering"}, "args": map[string]any{"text": text}})
		if _, err := parseRequest(b, p); err == nil {
			t.Errorf("accepted %q", text)
		}
	}
	b := []byte(`{"operation":"github.pr.list","target":{"repo":"company/project"},"args":{"limit":0}}`)
	if _, err := parseRequest(b, p); err == nil {
		t.Fatal("explicit zero limit accepted")
	}
}

func TestConfigPolicyFailClosed(t *testing.T) {
	c, p := fileFixture(t)
	registry, err := providers()
	if err != nil {
		t.Fatal(err)
	}
	configured, err := configure(c, registry)
	if err != nil {
		t.Fatal("mock configuration touched live secrets", err)
	}
	for _, address := range []string{"0.0.0.0:8080", "127.0.0.1:8080", "172.30.0.10:8443", "999.1.1.1:8080", "[::]:8080"} {
		candidate := c
		candidate.ListenAddress = address
		if candidate.validate() == nil {
			t.Errorf("accepted %s", address)
		}
	}
	for _, raw := range []string{`[{"repo":"company/project"},{"repo":"COMPANY/PROJECT"}]`, `null`} {
		copyPolicy := map[string]json.RawMessage{}
		for k, v := range p {
			copyPolicy[k] = v
		}
		copyPolicy["github"] = json.RawMessage(raw)
		if _, err := configured.Targets(copyPolicy); err == nil {
			t.Fatal("invalid policy accepted")
		}
	}
	p["shortcut"] = json.RawMessage(`[{"workspace":"unknown"}]`)
	if _, err := configured.Targets(p); err == nil {
		t.Fatal("unmapped workspace accepted")
	}
	live := c
	live.Mode = "live"
	if _, err := configure(live, registry); err == nil {
		t.Fatal("missing live credential path accepted")
	}
}

func fixture(t *testing.T) (config, httpapi.Policy) {
	t.Helper()
	c, p := fileFixture(t)
	registry, err := providers()
	if err != nil {
		t.Fatal(err)
	}
	configured, err := configure(c, registry)
	if err != nil {
		t.Fatal(err)
	}
	targets, err := configured.Targets(p)
	if err != nil {
		t.Fatal(err)
	}
	return c, httpapi.Policy(targets)
}

func parseRequest(data []byte, p httpapi.Policy) (operation.ValidatedRequest, error) {
	r, err := operation.ParseRequest(data, map[string]func(protocol.Request) (operation.ValidatedRequest, error){
		ghapi.PRList.Name: ghapi.PRList.Decode, ghapi.PRView.Name: ghapi.PRView.Decode,
		ghapi.PRDiff.Name: ghapi.PRDiff.Decode, ghapi.PRChecks.Name: ghapi.PRChecks.Decode,
		ghapi.PRFeedback.Name: ghapi.PRFeedback.Decode,
		scapi.StoryGet.Name:   scapi.StoryGet.Decode, scapi.StorySearch.Name: scapi.StorySearch.Decode,
	})
	if err != nil {
		return r, err
	}
	if !p.Allows(r.Target) {
		return r, &protocol.RequestError{Code: protocol.PolicyDenied}
	}
	return r, nil
}
